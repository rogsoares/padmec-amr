/*
 * rockProperties.cpp
 *
 *  Created on: Oct 26, 2014
 *      Author: rogerio
 */




