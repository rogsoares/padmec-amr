/*
 *  (C) 2000 UNIVERSITY OF CHICAGO
 *      See COPYRIGHT in top-level directory.
 */



#include "header.h"


/*
 * Management of incoming messages 
 *
 */



/****************************************************************************/

/*
 * Searching
 */


/*
 * AP_search()
 *
 * search recv buffers for message matching pid,tag
 *
 * flags may be:
 *    AP_FIFO     only check the first message from each source proc
 */
 


int AP_search(int pid, int tag, int flags, Minfo *minfo)
{
  /* Important! Skip search if possible
   */

  if (AP_nunseen<=0)
    return(0);


  /* Wildcard source proc 
   */

  if (pid==MPI_ANY_SOURCE)
    if (flags & AP_FIFO)
      return( AP_search_first(tag,minfo) );
    else
      return( AP_search_dfs(tag,minfo) );


  /* Particular source proc
   */

  if (flags & AP_FIFO)
    return( AP_match(&AP_first_unseen[pid],tag,minfo) );
  else
    return( AP_search_proc(pid,tag,minfo) );

}




/*
 * search among first incoming msg of each sender
 */

int AP_search_first(int tag, Minfo *minfo)
{
  int i;
  static int pid=0;                        /* pick up where we left off */

  for (i=0; i<AP_nprocs; i++)
    {
      if (AP_match(&AP_first_unseen[pid],tag,minfo))
	return(1);

      /* Important: only increment if unsuccessful so next
       * search will pick up with the same proc
       */

      pid=(pid+1)%AP_nprocs;                  
    }

  return(0);
}  


/*
 * search for a message in dfs manner
 * (check all msgs of one sender, then all of next sender, etc.)
 */

int AP_search_dfs(int tag, Minfo *minfo)
{
  int i;
  static int pid=0;                        /* pick up where we left off */

  for (i=0; i<AP_nprocs; i++)
    {
      if (AP_search_proc(pid,tag,minfo))
	return(1);

      /* Important: only increment if unsuccessful so next
       * search will pick up with the same proc
       */

      pid=(pid+1)%AP_nprocs;
    }

  return(0);
}  


/*
 * search all messages of a particular sender
 */ 

int AP_search_proc(int pid, int tag, Minfo *minfo)
{
    return( AP_ppair_search(&AP_first_unseen[pid], tag, minfo) );
}



/*
 * search messages starting at the given Ppair
 */

int AP_ppair_search(Ppair *start, int tag, Minfo *minfo)
{
  Ppair p;

  for ( p= *start;
	p.MH;
	AP_ppair_next(&p,AP_NEXTINDIV) )
    {
      CHECK_BLOCK(p.BH);
      CHECK_MSG(p.MH);

      if (AP_match(&p,tag,minfo))
	return(1);                                      /* success */
    }

  return(0);
}     


/*
 * does the message at p match the tag?
 *
 */

int AP_match(Ppair *p, int tag, Minfo *minfo)
{
  if (!p->MH)
    return(0);

  if (p->MH->state!=MSTATE_UNSEEN)
    return(0);

  if (tag!=MPI_ANY_TAG && p->MH->tag!=tag)
    return(0);

  /* the message matches the desired tag */

  AP_mark_received(p->MH);

  minfo->msg= mh_to_buf(p->MH);
  minfo->sender= p->BH->pid;
  minfo->size= p->MH->size;
  minfo->tag= p->MH->tag;

  return(1);                                          /* success */
}


/*
 * search messages starting at the given block header (when called by
 * AP_recv_new(), the block will be at the tail of the list, so if
 * nothing matches there will not be any more blocks to search)
 *
 */


int AP_search_block(Bhead *BH, int tag, Minfo *minfo)
{		     
  Ppair p;
  Mhead *MH;

  CHECK_BLOCK(BH);

  MH= bh_first_mh(BH);
  CHECK_MSG(MH);

  AP_ppair_set(&p,BH,MH);
  
  return( AP_ppair_search(&p, tag, minfo) );
}




void AP_mark_received(Mhead *MH)
{
  CHECK_MSG(MH);

  MH->state=MSTATE_RECEIVED;

#ifdef CHECKS
  {
    Bhead *BH;
  
    BH= mh_to_bh(MH);
    CHECK_BLOCK(BH);
  }
#endif
}



/************************************************************************/

/*
 * The actual receive
 *
 */


/*@

AP_recv - Receive a message

.n SUBROUTINE AP_RECV(sender, tag, flags, ret_msg, ret_size, ret_sender,
ret_tag, return_value)
.n INTEGER sender, tag, flags, ret_msg, ret_size, ret_sender, ret_tag,
return_value
.n INCLUDE ''autopack.fh''


Parameters:

+ sender     - specifies rank of the message source (may be 'MPI_ANY_SOURCE')
. tag        - specifies tag of the message (may be 'MPI_ANY_TAG')
. flags      - flags to specify options (see below)

. ret_msg    - the received message (or in Fortran, a descriptor)
. ret_size   - size of the received message
. ret_sender - sender of the received message
- ret_tag    - tag of the received message

Return Value:

Returns nonzero if a message has been successfully received, otherwise
returns 0.  If a message has been received, the arguments 'ret_msg',
'ret_size', 'ret_sender', and 'ret_tag' pass back information about
the message.

In the Fortran binding, it is not possible to return a pointer to the
message in 'ret_msg'.  Instead, a descriptor is returned that may be
passed to 'AP_COPY_FREE()' to retrieve the message.


Description:

Receive a message with given sender and tag ('MPI_ANY_SOURCE' and
'MPI_ANY_TAG' may be used).  If such a message is available, returns
nonzero and sets '*ret_msg', '*ret_size', '*ret_sender', and '*ret_tag'.
If no message matching the criteria is found, returns zero.

Any of 'ret_size', 'ret_sender', and 'ret_tag' may be passed NULL if
the caller is not interested in the return information.

After the caller has processed the information in ret_msg, 
the function 'AP_free()' must be called to free the buffer space.
Failure to do this will result in a memory leak.


Flags may be a bitwise OR of the following
(in Fortran, use addition)\:

.fin
'AP_NOFLAGS'
.fin
Default
.fout

'AP_BLOCKING'
.fin
Block until a matching message is received (by
default, do not block).  Will always return 1 unless 'AP_DROPOUT' is
specified.
.fout

'AP_DROPOUT' 
.fin
Used in conjunction with 'AP_BLOCKING'.  If some change
in status occurs (e.g. an asynchronous reduction message is received)
before a message is available, then unblock and return 0.
.fout

'AP_FIFO'
.fin
When searching for messages, only look at first incoming
message from each source.  Default action is to search all incoming
messages from a source (then continuing to the next source if
'MPI_ANY_SOURCE' was specified).
.fout
.fout

If there are deferred sends, the library will try to process them
before each attempt to receive a new message from MPI.  This is the
case whether the call to 'AP_recv()' is blocking or non-blocking,


Efficiency notes:

The library will be most efficient when messages are received in the
same order they arrive.  If all the messages have the same tag, this
is not a concern.  However, if the incoming messages have a variety of
tags, 'MPI_ANY_TAG' will always match the first one and is the most
efficient.  If a particular tag is specified, use 'AP_FIFO' if
the circumstances permit.

The library will be more efficient when a particular source is
specified rather than 'MPI_ANY_SOURCE'.  If 'MPI_ANY_SOURCE' is
specified, sources will be checked in round-robin fashion starting
with the rank from which the last message was received.  The search
is depth-first (although 'AP_FIFO' may truncate the search).

@*/


int AP_recv(int sender, int tag, int flags,
            void **ret_msg, int *ret_size, int *ret_sender, int *ret_tag)
{
  Minfo minfo;
  Ppair *p;


  if ( !AP_search(sender, tag, flags, &minfo) &&
       !AP_recv_new(sender, tag, flags, &minfo) )
    return(0);


  AP_nunseen--;
  p= &AP_first_unseen[minfo.sender];           /* Update first unseen msg */
  if ( p->MH == buf_to_mh(minfo.msg) )
    AP_ppair_next(p,AP_NEXTINDIV);
  

  *ret_msg= minfo.msg;

  if (ret_size)
    *ret_size= minfo.size;
  if (ret_sender)
    *ret_sender= minfo.sender;
  if (ret_tag)
    *ret_tag= minfo.tag;


#ifdef INFO_ALLOC
  {
    Mhead *MH;
    Bhead *BH;
    
    MH= buf_to_mh(*ret_msg);
    CHECK_MSG(MH);
    INFO_MSG(MH,"recv message");

    BH= mh_to_bh(MH);
    CHECK_BLOCK(BH);
    INFO_BLOCK(BH,"In block");
  }
#endif

  return(1);
}



/*
 * void AP_check_recvs(int flags)
 *
 * This function will transfer messages from MPI into the library
 * internal buffers.  Messages are still not "received" until the
 * user calls AP_irecv() or AP_recv().  Potentially useful to avoid
 * overflowing MPI.
 *
 * Flags may be:
 *    AP_BLOCKING        block until at least one message is received
 *                       Default is non-blocking
 */


void AP_check_recvs(int flags)
{
  Minfo minfo;


  while (AP_recv_probe(&flags,&minfo))             /* block at most once */
    ;
}



/*
 * look for incoming message that matches the criteria,
 * returns 0/1 if one exists
 *
 */


int AP_recv_new(int sender, int tag, int flags, Minfo *minfo)
{

  /* AP_recv_probe() sets minfo->sender,tag,size,ptr  
   */

  while (AP_recv_probe(&flags, minfo))             /* block at most once */
    {
      /* 
       * Have an incoming message. 
       * What we want is in sender,tag ; what we actually got
       * is in minfo->sender,tag.
       */

      if (minfo->tag==AP_BLOCK_TAG)
	{
	  CHECK_BLOCK(minfo->ptr);

	  /* minfo contents no longer useful */

	  if ( ( (sender==MPI_ANY_SOURCE) || (sender==minfo->sender) ) &&
	       AP_search_block(minfo->ptr,tag,minfo) )       /* sets minfo */
	    return(1);
	}
      else
	{
	  CHECK_MSG(minfo->ptr);

	  if ( ( (sender==MPI_ANY_SOURCE) || (sender==minfo->sender) ) &&
	       ( (tag==MPI_ANY_TAG) || (tag==minfo->tag) ) )
	    {
	      AP_mark_received(minfo->ptr);
	      return(1);
	    }
	}
    }   

  return(0);
}  



/*
 * probes for an incoming message of any type,
 * and handles it.  returns 1 and sets minfo if
 * there was a user message received.
 * 
 * this silently intercepts out-of-band messages
 * (e.g. for reductions).  will process as many
 * as there are at the moment.
 *
 * If you choose AP_DROPOUT, an out-of-band message will
 * cause it to unblock and return 0 even if AP_BLOCKING is
 * specified.
 *
 */



int AP_recv_probe(int *flags, Minfo *minfo)
{


  while (AP_mpi_probe(*flags, minfo))              /* sets minfo */
    {

      if ( *flags & AP_DROPOUT)
	*flags &= ~AP_BLOCKING;                    /* Only block once */



      switch (minfo->tag)                           
	{
          case AP_BLOCK_TAG:                       /* Block message */
	    AP_recv_block(minfo);
            return(1);

          case AP_REDUCE_TAG:                      /* out-of-band */
	    AP_recv_reduce(minfo);
	    break;

          case AP_BCAST_TAG:                       /* out-of-band */
	    AP_recv_bcast(minfo);
            break;

          default:                                 /* Regular message */
	    AP_recv_indiv(minfo);
	    return(1);

	}

    }

  return(0);                                         /* Nothing incoming */
}





void AP_recv_indiv(Minfo *minfo)                    /* minfo INPUT/OUTPUT */
{
  Ppair p;

  minfo->msg= AP_alloc_indiv( minfo->sender, minfo->tag, minfo->size,
			       AP_RECVBLOCK, &p);
  minfo->ptr=p.MH;

  CHECK_MSG(p.MH);
  p.MH->state= MSTATE_UNSEEN;

  AP_mpi_recv(minfo->msg, minfo->size, minfo->sender, minfo->tag);
  INFO_MSG(p.MH,"Incoming indiv message");

  AP_nunseen++;
  AP_ppair_update( &AP_first_unseen[minfo->sender],
		    p.BH, p.MH );
}




void AP_recv_block(Minfo *minfo)       /* minfo is INPUT only */
{
  Bhead *BH;
  pListitem listitem;


  if (AP_list_tail(AP_recvbuffer[minfo->sender], (void **)&BH ) &&
      BH->state==BSTATE_OPEN)
    AP_close_block(BH,AP_RECVBLOCK);


  BH=AP_alloc_block(minfo->sender, minfo->size, AP_RECVBLOCK);

  /* The receive will write over this value, so save it and restore */
  listitem=BH->listitem;

  AP_mpi_recv(BH, minfo->size, minfo->sender, AP_BLOCK_TAG);
  CHECK_BLOCK(BH);

  /* initialized block header where necessary */
  BH->listitem=listitem;
  BH->pid= minfo->sender;
  /* size - is not correct but not used */
  /* packed - ok */
  BH->state=BSTATE_CLOSED;
  /* sendreq - not used */

  /* nmsgs - ok */
  BH->npending = BH->nmsgs;
  printf("%d: received block with %d\n",AP_rank,BH->nmsgs);

  /* tail - not used */

#ifdef INFO_RECVBLKS
  printf("%d: Alloc packed recv block id=%d  npending %d\n",
	 AP_mypid,BH->id,BH->npending);
#endif

  INFO_BLOCK(BH,"Incoming block");

  AP_nunseen+=BH->nmsgs;
  AP_ppair_update( &AP_first_unseen[minfo->sender],
		    BH, bh_first_mh(BH) );

  minfo->ptr=BH;
}
  

/***************************************************************************/

/*
 * Freeing receive buffers
 */



/*@

AP_free - free a message buffer

.n SUBROUTINE AP_FREE(buf)
.n INTEGER buf

Parameters:
. buf - the buffer to free (in Fortran, the descriptor)

Return Value:
None

Description:

Call this function to free message buffer space 
allocated by 'AP_recv()'.

Note that in the Fortran binding, it is not necessary to call this
after 'AP_COPY_FREE()' since that function frees that buffer before
returning.  However, this function may be of use in case the user
wants to free the message without actually accessing it.

@*/


void AP_free(void *buf)
{
  Mhead *MH;
  Bhead *BH;

  MH= buf_to_mh(buf);
  CHECK_MSG(MH);
  BH= mh_to_bh(MH);
  CHECK_BLOCK(BH);

  MH->state= MSTATE_FREED;

  if (BH->npending<=0)
    AP_mpi_abort();

  BH->npending--;

#ifdef INFO_RECVBLKS
  printf("%d: AP_free: bid %d  mid %d  state %d  npending %d\n",
	 AP_mypid,BH->id,MH->id,BH->state,BH->npending);
#endif

  if (BH->state==BSTATE_CLOSED && BH->npending==0)
    AP_free_block(BH,AP_RECVBLOCK);
}

