/*
 *  (C) 2000 UNIVERSITY OF CHICAGO
 *      See COPYRIGHT in top-level directory.
 */





/******************************************************  
 * WARNING: This file automatically generated.        *  
 *          Do not edit by hand.                      *  
 ******************************************************  
 */                                                      




extern void AP_reduce_count(int *count, int *dest) ;
extern void AP_reduce_init(void);
extern int AP_send_begin(void);
extern void AP_send_end(void);
extern void AP_reduce_nsends(int *nsends);
extern int AP_dsend_begin(void);
extern void AP_dsend_end(void);
extern void AP_recv_reduce(Minfo *minfo);
extern void AP_reduce_send(void);
extern void AP_recv_bcast(Minfo *minfo);
extern void AP_bcast_send(void);
