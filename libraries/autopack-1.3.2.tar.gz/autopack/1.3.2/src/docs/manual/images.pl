# LaTeX2HTML 99.2beta6 (1.42)
# Associate images original text with physical files.


$key = q/{figure}preform{<verbatim_mark>verbatim37#preform{{{{figure};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="411" HEIGHT="141" BORDER="0"
 SRC="|."$dir".q|img4.png"
 ALT="\begin{figure}\begin{verbatim}...
INTEGER*4 message(2)message(0)=10
mess...
...1)=20
CALL AP_BSEND(message,2*4,destination,tag)
...\end{verbatim}\end{figure}">|; 

$key = q/{figure}preform{<verbatim_mark>verbatim38#preform{{{{figure};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="578" HEIGHT="511" BORDER="0"
 SRC="|."$dir".q|img5.png"
 ALT="\begin{figure}\begin{verbatim}...
tag=AP_send_begin();for (...)
{
msg=A...
... AP_free(msg);
}AP_check_sends(AP_WAITDEFER);
...\end{verbatim}\end{figure}">|; 

$key = q/{figure}preform{<verbatim_mark>verbatim34#preform{{{{figure};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="411" HEIGHT="141" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="\begin{figure}\begin{verbatim}...
INTEGER*4 message(2)message(0)=10
mess...
...1)=20
CALL AP_BSEND(message,2*4,destination,tag)
...\end{verbatim}\end{figure}">|; 

$key = q/{figure}preform{<verbatim_mark>verbatim35#preform{{{{figure};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="597" HEIGHT="211" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="\begin{figure}\begin{verbatim}...
int *ret_msg;if (AP_recv(MPI_ANY_SOURCE...
...n'',ret_msg[0],ret_msg[1]);
AP_free(ret_msg);
}
...\end{verbatim}\end{figure}">|; 

$key = q/{figure}preform{<verbatim_mark>verbatim36#preform{{{{figure};LFS=12;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="549" HEIGHT="165" BORDER="0"
 SRC="|."$dir".q|img3.png"
 ALT="\begin{figure}\begin{verbatim}...
int *message;message= (int *)AP_alloc(d...
...message[0]=10;
message[1]=20;
AP_send(message);
...\end{verbatim}\end{figure}">|; 

1;

