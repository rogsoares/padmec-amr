/*
 *  (C) 2000 UNIVERSITY OF CHICAGO
 *      See COPYRIGHT in top-level directory.
 */





/******************************************************  
 * WARNING: This file automatically generated.        *  
 *          Do not edit by hand.                      *  
 ******************************************************  
 */                                                      




extern void *AP_alloc(int destpid, int tag, int size );
extern void AP_send(void *buf);
extern void AP_flush(void);
