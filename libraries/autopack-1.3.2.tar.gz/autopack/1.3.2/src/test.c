

func_foo_()
{
  printf("func_foo_\n");
}

func_foo__()
{
  printf("func_foo__\n");
}



main()
{
  mymacro(func_foo);
}

