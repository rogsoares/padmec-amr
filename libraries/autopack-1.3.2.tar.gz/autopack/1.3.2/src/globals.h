/*
 *  (C) 2000 UNIVERSITY OF CHICAGO
 *      See COPYRIGHT in top-level directory.
 */





#ifdef __AP_ALLOCATE__             /* alloc.c will define this */
#define EXTERN 
#else                               /* to other files will be extern */
#define EXTERN extern
#endif


/*
 * Variables private to this library
 */


EXTERN int AP_blocksize;
EXTERN int AP_packmode;

EXTERN MPI_Comm AP_comm;                /* Communicator for library */

EXTERN pList *AP_sendbuffer;            /* sendbuffer[AP_nprocs] */
EXTERN pList *AP_recvbuffer;            /* recvbuffer[AP_nprocs] */


EXTERN int *AP_waitpid;
EXTERN MPI_Request **AP_waitptr;
EXTERN MPI_Request *AP_waitreq;
EXTERN int *AP_waitindex;
EXTERN MPI_Status *AP_waitstat;




EXTERN Ppair *AP_first_empty;      /* First msg that can be sent */


EXTERN int    AP_nwait;            /* how many */
EXTERN int   *AP_nwait_proc;       /* how many per proc */
EXTERN Ppair *AP_first_wait;       /* first block/msg in WAIT state */


EXTERN int    AP_ndefer;
EXTERN int   *AP_ndefer_proc;      /* how many deferred sends */
EXTERN Ppair *AP_first_defer;      /* first block/msg in SENT state */


EXTERN int    AP_nunseen;          /* how many msgs are unseen */
EXTERN Ppair *AP_first_unseen;     /* first msg in UNSEEN state */


EXTERN int AP_max_nwait;
EXTERN int AP_max_nwait_proc;

/*
 * for reductions
 */

EXTERN int AP_count_enable;        /* tells AP_send() to increment */
EXTERN int *AP_nsends;             /* increment in AP_send() */
EXTERN int *AP_reduce_buf;         /* receive buffer for reductions */
EXTERN int *AP_bcast_buf1;         /* send buffer for bcast */
EXTERN int *AP_bcast_buf2;         /* send buffer for bcast */


#ifdef CHECKS
EXTERN int AP_nsendblocks;         /* number of allocated recv blocks */
EXTERN int AP_nrecvblocks;         /* number of allocated send blocks */
#endif


/*
 * Non-private
 *
 */

EXTERN int AP_nprocs;              /* deprecated */
EXTERN int AP_mypid;               /* deprecated */

EXTERN int AP_size;
EXTERN int AP_rank;


