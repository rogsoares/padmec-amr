/*
 *  (C) 2000 UNIVERSITY OF CHICAGO
 *      See COPYRIGHT in top-level directory.
 */





/******************************************************  
 * WARNING: This file automatically generated.        *  
 *          Do not edit by hand.                      *  
 ******************************************************  
 */                                                      




extern int AP_int_sum(int value);
extern double AP_double_sum(double value);
extern int AP_int_scan(int value);
extern float AP_float_scan(float value);
extern int AP_int_bcast(int value, int sender);
extern double AP_double_bcast(double value, int sender);
extern void AP_block_bcast(void *buf, int size, int sender);
extern double AP_double_min(double value);
extern double AP_double_max(double value);
extern void AP_bsend(void *buf, int size, int dest, int tag);
extern void AP_breceive(void *buf, int size, int *from, int tag);
