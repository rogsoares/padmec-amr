/*
 *  (C) 2000 UNIVERSITY OF CHICAGO
 *      See COPYRIGHT in top-level directory.
 */




#include "header.h"

#ifdef CHECKS

void AP_check_block(Bhead *BH)
{
  if (!BH)
    {
      fprintf(stderr,"%d: AP_check_block: null pointer\n",AP_mypid);
      AP_mpi_abort();
    }

  if (BH->startflag != BLOCK_START_FLAG)
    {
      fprintf(stderr,"%d: AP_check_block: start flag is bad\n",AP_mypid);
      AP_mpi_abort();
    }

  if (BH->endflag != BLOCK_END_FLAG)
    {
      fprintf(stderr,"%d: AP_check_block: end flag is bad\n",AP_mypid);
      AP_mpi_abort();
    }

  if (BH->state == BSTATE_DELETED)
    {
      fprintf(stderr,"%d: AP_check_block: block previously deleted\n",
	      AP_mypid);
      AP_mpi_abort();
    }

  if (BH->tail > BH->size)
    {
      fprintf(stderr,"%d: AP_check_block: tail > size\n",AP_mypid);
      AP_mpi_abort();
    }
}


void AP_check_msg(Mhead *MH)
{
  if (!MH)
    {
      fprintf(stderr,"%d: AP_check_msg: null pointer\n",AP_mypid);
      AP_mpi_abort();
    }

  if (MH->startflag != MSG_START_FLAG)
    {
      fprintf(stderr,"%d: AP_check_msg: start flag is bad\n",AP_mypid);
      AP_mpi_abort();
    }

  if (MH->endflag != MSG_END_FLAG)
    {
      fprintf(stderr,"%d: AP_check_msg: end flag is bad\n",AP_mypid);
      AP_mpi_abort();
    }
}


void AP_check_msg_state(Mhead *MH, int state)
{
  AP_check_msg(MH);

  if (MH->state != state)
    {
      fprintf(stderr,"%d: AP_check_mstate: expected state %d\n",
	      AP_mypid,state);
      AP_mpi_abort();
    }
}


void AP_check_block_state(Bhead *BH, int state)
{
  AP_check_block(BH);

  if (BH->state != state)
    {
      fprintf(stderr,"%d: AP_check_bstate: expected state %d\n",
	      AP_mypid,state);
      AP_mpi_abort();
    }
}



void AP_check_ndefer(void)
{
  int count;
  int i;

  count=0;
  for (i=0; i<AP_nprocs; i++)
    {
      if (AP_ndefer_proc[i]<0)
	{
	  fprintf(stderr,"%d: AP_ndefer_proc[%d]=%d  (negative!)\n",
		  AP_mypid,i,AP_ndefer_proc[i]);
	  AP_mpi_abort();
	}

      count+=AP_ndefer_proc[i];
    }

  if (AP_ndefer<0)
    {
      fprintf(stderr,"%d: AP_ndefer=%d  (negative!)\n",
	      AP_mypid,AP_ndefer);
      AP_mpi_abort();
    }


  if (count!=AP_ndefer)
    {
      fprintf(stderr,"%d: mismatch in AP_ndefer, AP_ndefer_proc[]\n",
	      AP_mypid);
      AP_mpi_abort();
    }
}




void AP_check_nwait(void)
{
  int count;
  int i;

  count=0;
  for (i=0; i<AP_nprocs; i++)
    {
      if (AP_nwait_proc[i]<0)
	{
	  fprintf(stderr,"%d: AP_nwait_proc[%d]=%d  (negative!)\n",
		  AP_mypid,i,AP_nwait_proc[i]);
	  AP_mpi_abort();
	}

      count+=AP_nwait_proc[i];
    }

  if (AP_nwait<0)
    {
      fprintf(stderr,"%d: AP_nwait=%d  (negative!)\n",
	      AP_mypid,AP_nwait);
      AP_mpi_abort();
    }

  if (count!=AP_nwait)
    {
      fprintf(stderr,"%d: mismatch in AP_nwait, AP_wait_proc[]\n",AP_mypid);
      AP_mpi_abort();
    }

}




void AP_info_block(Bhead *BH, char *str)
{
  printf("%d: %s:\n",AP_mypid,str);
  printf("   id %d  pid %d  size %d  packed %d  state %d\n",
	 BH->id, BH->pid, BH->size, BH->packed, BH->state);
  printf("   free %d  nmsgs %d  npending %d  tail %d\n",
	 BH->size-BH->tail, BH->nmsgs, BH->npending, BH->tail);
}



void AP_info_msg(Mhead *MH, char *str)
{
  Bhead *BH;

  BH= mh_to_bh(MH);

  printf("%d: %s:\n",AP_mypid,str);
  printf("   pid %d  id %d  bid %d  bhead %d  next %d  state %d  tag %d  "
	 "size %d\n",
	 BH->pid,MH->id,BH->id, MH->bhead, MH->next, MH->state, MH->tag,
	 MH->size);
}




void AP_info_ppair(Bhead *BH, Mhead *MH, char *str)
{
  if (MH)
    AP_info_msg(MH,str);
  else
    AP_info_block(BH,str);
}



void AP_info_defer_stats(char *s)
{
  int i;

  printf("%d: %s:\n",AP_mypid,s);
  printf("%d:   Sendblks %d  Recvblocks %d  (unseen %d) ndefer %d  nwait %d\n",
	 AP_mypid,AP_nsendblocks,AP_nrecvblocks,AP_nunseen,AP_ndefer,AP_nwait);

  printf("%d:   nwait_proc[]=",AP_mypid);
  for(i=0; i<AP_nprocs; i++)
    printf("  %d",AP_nwait_proc[i]);
  printf("\n");

}


#endif  /* CHECKS */
