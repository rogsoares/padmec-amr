/*
 *  (C) 2000 UNIVERSITY OF CHICAGO
 *      See COPYRIGHT in top-level directory.
 */




#include "header.h"


/*
 * Management of MPI send requests
 *
 */


#define SENDS_RET ( (AP_ndefer>0) ? AP_ndefer: -AP_nwait )

#define SENDS_RET_PROC(i)  \
        ( (AP_ndefer_proc[i]>0) ? AP_ndefer_proc[i]: -AP_nwait_proc[i] )



/*@

AP_check_sends - check status of underlying 'MPI' sends

.n SUBROUTINE AP_CHECK_SENDS(flags, return_value)
.n INTEGER flags, return_value
.n INCLUDE ''autopack.fh''

Parameters:
. flags - specify options (see below)

Description:

Check to see if 'MPI' has finished sending any messages, and free
their buffer space if they are done.  Also, if there are any
deferred messages, send as many as possible.

Flags may be a bitwise OR of the following
(in Fortran use addition)\:

.fin
'AP_NOFLAGS'
.fin
Do not block (default)
.fout

'AP_BLOCKING'
.fin
Block until at least one send completes
.fout

'AP_WAITDEFER'
.fin
Block until all deferred sends are posted to 'MPI'
(always returns <=0 )
.fout

'AP_WAITALL'
.fin
Block until 'MPI' completes all sends (always returns 0)
.fout
.fout

Caution must be used to avoid deadlock when using 'AP_BLOCKING'.
For example, if two processors call this after sending
each other messages, neither send is guaranteed to complete
before a receive is performed.


Return value:

0 if all sends have completed.

If there are deferred sends, returns how many.

If there are no deferred sends, returns -1 times the
number of incomplete 'MPI' send requests. 

(Note: packages are only counted as a single send.)


@*/


int AP_check_sends(int flags)
{

#ifdef CHECKS
  if (AP_nwait<=0 && AP_ndefer>0)
    {
      fprintf(stderr,"AP_check_sends: nwait<=0 and ndefer>0\n");
      AP_mpi_abort();
    }
#endif

  /* if there are no sends waiting for mpi to complete,
   * then there can't be any deferred sends, so just return
   * without checking for deferred.
   */

  if (AP_nwait<=0)
    return(SENDS_RET);

  if (flags==0)
    {
      AP_check_sends_nonblocking();
      AP_send_deferred();
      return(SENDS_RET);
    }


  if (flags & AP_BLOCKING)
    {
      AP_check_sends_blocking();
      AP_send_deferred();
      return(SENDS_RET);
    }

  if (flags & AP_WAITDEFER)
    {
      while (AP_ndefer>0)
	{
	  AP_check_sends_blocking();
	  AP_send_deferred();
	}

      return(SENDS_RET);
    }


  if (flags & AP_WAITALL)
    {
      while (AP_nwait>0)
	{
	  AP_check_sends_blocking();
	  AP_send_deferred();
	}

      return(SENDS_RET);
    }

  fprintf(stderr,"%d: AP_check_sends: flag error\n",AP_mypid);
  AP_mpi_abort();
  return(0);
}





/*@

AP_check_sends_proc - check sends to a single destination

.n SUBROUTINE AP_CHECK_SENDS_PROC(pid, flags, return_value)
.n INTEGER pid, flags, return_value
.n INCLUDE ''autopack.fh''

Parameters:
+ pid   - destination rank to check
- flags - specifies options (see below)

Description:

Like 'AP_check_sends()', but only check sends to the given destination.
If there are deferred messages to the destination, send as many as possible.

Flags may be one of the following\:

.fin
'AP_NOFLAGS' 
.fin
Do not block (default)
.fout
     
'AP_BLOCKING' 
.fin
Block until the first MPI send request for the
specified proc is complete, then check remaining ones without
blocking.
.fout
.fout

Return Value:

Like 'AP_check_sends()' but value only reflects sends deferred/waiting
for the specified processor.  
.n I.e.

0 if all sends to the destination have completed.

If there are deferred sends to the destination, returns how many.

If there are no deferred sends to the destination, returns -1 times the
number of incomplete 'MPI' send requests. 

(Note: packages are only counted as a single send.)


@*/


int AP_check_sends_proc(int pid, int flags)
{
  MPI_Request *sendreq;

  if (AP_nwait_proc[pid]<=0)
    return(SENDS_RET_PROC(pid));

  if ( (flags & AP_BLOCKING) && AP_get_first_req(pid,&sendreq) )
    AP_mpi_wait(sendreq);

  AP_check_sends_proc_nonblocking(pid);
  AP_send_deferred_proc(pid);

  return(SENDS_RET_PROC(pid));
}






void AP_check_sends_nonblocking(void)
{
  int i;

  for( i=0; i<AP_nprocs && AP_nwait>0 ; i++ )
    AP_check_sends_proc_nonblocking(i);

  CHECK_NWAIT();
}



/*
 * check to see if any sends to the given dest
 * are completed, and free their buffer space if so.
 */

void AP_check_sends_proc_nonblocking(int pid)
{
  Ppair *p;
  Bhead *BH;
  int state;

#ifdef CHECKS
  if (pid<0 || pid>=AP_nprocs)
    {
      fprintf(stderr,"%d: AP_check_sends_proc_nonblocking: bad pid %d\n",
	      AP_mypid,pid);
      AP_mpi_abort();
    }
#endif

  p= &AP_first_wait[pid];


  while ( p->BH && AP_check_sends_ppair(p) )
    {
#ifdef INFO_SENDBLKS
      printf("%d: mcsp: done pid %d  bid %d  mid %d  bstate %d\n",
	     AP_mypid, pid,p->BH->id, (p->MH)?p->MH->id:-1, p->BH->state);
#endif

      BH=p->BH;

      state=AP_ppair_next(p,AP_NEXTREQ);

      /* if we've moved on to another block, free previous block
       */
 
      if ( p->BH!=BH && (BH->packed || BH->state==BSTATE_CLOSED) )
	AP_free_block(BH,AP_SENDBLOCK);

      if (state!=STATE_WAIT)
	AP_ppair_set(p,NULL,NULL);
    }

}
  



int AP_check_sends_ppair(Ppair *p)
{
  if (p->MH)
    {
      CHECK_MSG_STATE(p->MH,MSTATE_WAIT);

      if ( !AP_mpi_done(&p->MH->sendreq) )
	return(0);

      p->MH->state=MSTATE_DONE;

      INFO_MSG(MH,"--- Indiv send done");
    }
  else
    {
      CHECK_BLOCK_STATE(p->BH,BSTATE_WAIT);
      if ( !AP_mpi_done(&p->BH->sendreq) )
	return(0);

      p->BH->state=BSTATE_DONE;

      INFO_BLOCK(BH,"--- Packed send done");
    }

  AP_nwait--;
  AP_nwait_proc[p->BH->pid]--;

  return(1);
}




void AP_check_sends_blocking(void)
{
  int i;
  int count;
  int outcount;
  MPI_Request *req;
  int index;

  INFO_DEFER_STATS("csb: before blocking");

  count=0;

  for (i=0; i<AP_nprocs; i++)
    if (AP_get_first_req(i,&req))
      {
	AP_waitpid[count]=i;
	AP_waitptr[count]= req;        /* location of request */
	AP_waitreq[count]= *req;       /* value of request */
	count++;
      }

#ifdef CHECKS
  if (count==0)
    {
      fprintf(stderr,"%d: AP_check_sends_blocking: "
	      "no req but AP_nwait=%d\n",AP_mypid,AP_nwait);
      AP_mpi_abort();
    }
#endif
  

#ifdef INFO_DEFER
  printf("%d: Blocking on %d requests\n",AP_mypid,count);
#endif


  SUCCESS( MPI_Waitsome(count,AP_waitreq,&outcount,
			AP_waitindex,AP_waitstat) );      /* blocking */


#ifdef INFO_DEFER
  printf("%d: Done blocking\n",AP_mypid);
#endif


  for (i=0; i<outcount; i++)
    {
      index=AP_waitindex[i];

#ifdef CHECKS
      if (AP_waitreq[index]!=MPI_REQUEST_NULL)
	{
	  fprintf(stderr,"%d: AP_check_sends_blocking: "
		  "request to proc %d is not null\n",
		  AP_mypid,AP_waitpid[AP_waitindex[i]]);
	  AP_mpi_abort();
	}
#endif

      *(AP_waitptr[index])=MPI_REQUEST_NULL;       /* important ! */
      AP_check_sends_proc_nonblocking(AP_waitpid[index]);
    }


  INFO_DEFER_STATS("csb: After checking sends");
}





/*
 * if there is a pending send request, return 1 with sendreq/packed set.
 * otherwise return 0.
 */

int AP_get_first_req(int pid, MPI_Request **sendreq)
{
  Ppair *p;

  p= &AP_first_wait[pid];

  if (!p->BH)
    {
#ifdef CHECKS
      if (AP_nwait_proc[pid]!=0)
	{
	  fprintf(stderr,"%d: mgfr: no first wait but nwait[%d]=%d\n",
		  AP_mypid,pid,AP_nwait_proc[pid]);
	  AP_mpi_abort();
	}
#endif
      return(0);
    }

  if (p->MH)
    {
      CHECK_MSG_STATE(p->MH,MSTATE_WAIT);
      *sendreq= &p->MH->sendreq;
    }
  else
    {
      CHECK_BLOCK_STATE(p->BH,BSTATE_WAIT);
      *sendreq= &p->BH->sendreq;
    }

  return(1);
}

