/*
 *  (C) 2000 UNIVERSITY OF CHICAGO
 *      See COPYRIGHT in top-level directory.
 */





/******************************************************  
 * WARNING: This file automatically generated.        *  
 *          Do not edit by hand.                      *  
 ******************************************************  
 */                                                      




extern int AP_send_or_defer(Bhead *BH, Mhead *MH);
extern void AP_do_send(Bhead *BH, Mhead *MH);
extern void AP_send_deferred(void);
extern void AP_send_deferred_proc(int pid);
extern int AP_send_deferred_one(int pid);
