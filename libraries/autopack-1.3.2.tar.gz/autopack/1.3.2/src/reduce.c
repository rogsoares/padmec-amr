/*
 *  (C) 2000 UNIVERSITY OF CHICAGO
 *      See COPYRIGHT in top-level directory.
 */



#include "header.h"


/*
 * Implement an asynchronous version of MPI_Allreduce()
 *
 */


#define RSTATE_INIT    0
#define RSTATE_SENDING 1
#define RSTATE_REDUCE  2
#define RSTATE_BCAST   3


static int AP_reduce_state;
static int AP_reduce_nrecv;               /* how many recvs to expect */
static int AP_reduce_dest;                /* where to send msg */

int AP_reduce_result=AP_UNKNOWN;          /* Do not make static */



/*
 * Determine number of receives expected at this processor
 * during a reduction to processor 0.
 *
 * Communication pattern: think of the processors numbered starting
 * with 1, then the children of i are 2i and 2i+1, its parent is i/2
 * (integer division).
 * 
 * IMPORTANT: the same pattern must be used for the broadcast or 
 * things can get out of sync.
 *
 */


void AP_reduce_count(int *count, int *dest) 
{
  int source1,source2;
  int n;

  n=0;

  source1=2*(AP_mypid+1)-1;
  source2=source1+1;

  if (source1<AP_nprocs)
    {
      n++;
      if (source2<AP_nprocs)
	n++;
    }

  *count=n;
  *dest= (AP_mypid+1)/2-1;
}



/*
 *  Call from AP_init() AND from AP_bcast_send()
 *  (when reduction is complete)
 *
 *  In the default state (RSTATE_INIT), accept reduction messages from
 *  other procs (this proc may not have reached the start of the
 *  reduction yet).
 *
 * Important: do not initialize AP_reduce_result here,
 * the user needs to access the result after this is called.
 *
 */


void AP_reduce_init(void)
{
  int i;

  for (i=0; i<AP_nprocs; i++)
    AP_nsends[i]=0;

  AP_reduce_count(&AP_reduce_nrecv, &AP_reduce_dest );
  AP_reduce_state=RSTATE_INIT;
  AP_count_enable=0;

#ifdef INFO_REDUCE
  printf("%d: reduce initialized  nrecv %d  dest %d\n",
	 AP_mypid,AP_reduce_nrecv,AP_reduce_dest);
#endif

}

  
/************************************************************************/

/*N Reduce_Organization

Overview:

The general organization of user code should be as follows.  Each
processor calls 'AP_send_begin()', then does some sends, then calls
'AP_send_end()'.  Then it loops calling 'AP_recv()', blocking if
desired (but using the 'AP_DROPOUT' flag if blocking).
'AP_recv_count()' will indicate when the loop should terminate.  It is
not necessary to synchronize the processors at any point during
this process.

N*/



/*@

AP_send_begin - Initiate a batch of sends

.n SUBROUTINE AP_SEND_BEGIN(return_value)
.n INTEGER return_value

Parameters:
None

Description:

Tells the library that the user code is about to begin a batch of
sends.  The library will then internally keep track of how many sends
go to each destination.  After doing the sends, call 'AP_recv_count()'
to initiate an asynchronous global reduction to determine how many
incoming message to expect.

It is an error to call 'AP_send_begin()' again before 'AP_recv_count()'
indicates the reduction is complete.

This routine will free space (via 'AP_check_sends()') from any
previous sends that are complete.

Return Value:

Returns the number of reductions since the library was initialized.
It can be used as a tag for the subsequent sends.  When the maximum
tag number has been reached, the count will wrap around to 0.

.N Reduce_Organization

@*/


int AP_send_begin(void)
{
  static int tag=0;

  if (AP_reduce_state != RSTATE_INIT)
    {
      fprintf(stderr,"%d: AP_send_begin: prior reduction is not complete\n",
	      AP_mypid);
      AP_mpi_abort();
    }

  AP_check_sends(0);

  AP_reduce_state=RSTATE_SENDING;
  AP_count_enable=1;
  AP_reduce_result=AP_UNKNOWN;

  tag=(tag+1)%AP_LIB_TAG;
  return(tag);
}



/*@

AP_send_end - End a batch of sends, initiate asynchronous reduction

.n SUBROUTINE AP_SEND_END

Parameters:
None

Description:

This function denotes the end of a batch of sends.  (To start of a
batch of sends, see 'AP_send_begin()'.) 

After flushing the send buffers (see 'AP_flush()'), this function
initiates an asynchronous reduction to compute how many messages this
processor will receive from the batch of sends.  The result of this
reduction may be queried through 'AP_recv_count()'.

Caveats:

Messages to implement the asynchronous reduction are handled
transparently.  However, each processor is obligated to call AP_recv()
repeatedly until 'AP_recv_count()' has indicated the reduction is
complete.  Otherwise, the reduction will not complete on this
processor (and possibly others).

Messages that implement the asynchronous reduction are always sent
immediately and are never deferred.  This may use up to 2 MPI send
requests per processor which are not counted in the 'nwait' or
'nwait_proc' setting (see 'AP_setparam()').

Return Value:
None

.N Reduce_Organization

@*/


void AP_send_end(void)
{

  if (AP_reduce_state != RSTATE_SENDING)
    {
      fprintf(stderr,"%d: AP_send_end: not at start of reduction\n",AP_mypid);
      AP_mpi_abort();
    }

  AP_flush();

  AP_count_enable=0;
  AP_reduce_state=RSTATE_REDUCE;
      
  /* bootstrap the reduction */

  AP_reduce_send();

}



/*@

AP_reduce_nsends - start reduction with explicit send count

Parameters:
int *nsends - array with count of sends to each destination

Description:

Still in testing.

Alternate interface to the asynchronous reduction.

Return Value:
None

.N Reduce_Organization

@*/

void AP_reduce_nsends(int *nsends)
{
  int i;

  if (AP_reduce_state != RSTATE_INIT)
    {
      fprintf(stderr,"%d: AP_reduce_nsends: prior reduction is not complete\n",
              AP_mypid);
      AP_mpi_abort();
    }

  AP_flush();
  AP_check_sends(0);
  AP_count_enable=0;

  for (i=0; i<AP_nprocs; i++)
    AP_nsends[i]=nsends[i];

  AP_reduce_state=RSTATE_REDUCE;
  AP_reduce_result=AP_UNKNOWN;

  /* bootstrap the reduction */
  AP_reduce_send();
}



/*@

AP_dsend_begin - denote the start of a batch of deterministic sends

.n SUBROUTINE AP_DSEND_BEGIN(return_value)
.n INTEGER return_value

Parameters:
None

Description:

Like 'AP_send_begin()', but denote the start of a
batch of sends that are guaranteed to arrive in deterministic order.
After the sends, call 'AP_dsend_end()'.  

Caveats: 

When this is called, there must be no outstanding messages (i.e. sent
but not received) in the system.

Messages sent within the bounds of 'AP_dsend_begin()'/'AP_dsend_end()'
will arrive in a deterministic order.

`Unlike` 'AP_send_begin()', `this call will cause a global synchronization.`

Memory requirements will be substantially higher than for
'AP_send_begin()', because no messages are passed on to the user until
all have arrived at this processor.

Return value:
Same as for 'AP_send_begin()'.

.N Reduce_Organization

@*/


int AP_dsend_begin(void)
{

  AP_check_recvs(0);
  MPI_Barrier(AP_comm);

  if (AP_nunseen!=0)
    {
      fprintf(stderr,"%d: AP_dsend_begin: error, there are "
	      "%d unreceived messages (none allowed).\n",
	      AP_mypid,AP_nunseen);
      AP_mpi_abort();
    }

  return(AP_send_begin());
}





/*@

AP_dsend_end -
End a batch of deterministic sends, initiate asynchronous reduction

.n SUBROUTINE AP_DSEND_END(return_value)
.n INTEGER return_value

Parameters:
None

Description:

Like 'AP_send_end()', but end a batch of messages
that are guaranteed to arrive in deterministic order.

`Unlike` 'AP_send_end()', `this call will cause a global synchronization.`

Return value:
None

.N Reduce_Organization

@*/


void AP_dsend_end(void)
{
  int nrecvs;

  AP_send_end();

  while ( !AP_recv_count(&nrecvs) || AP_nunseen<nrecvs ) 
    AP_check_recvs(AP_BLOCKING | AP_DROPOUT); 


  if (AP_nunseen!=nrecvs)
    {
      fprintf(stderr,"%d: AP_dsend_end: error, %d messages "
	      "expected but received %d\n",AP_mypid,nrecvs,AP_nunseen);
      AP_mpi_abort();
    }

  AP_check_sends(AP_WAITDEFER);
  MPI_Barrier(AP_comm);
}






/*M

AP_recv_count - query the result of an asynchronous reduction

Synopsis:
int AP_recv_count(int *count)

.n SUBROUTINE AP_RECV_COUNT(count, return_value)
.n INTEGER count, return_value

Parameters:
. count - result of the reduction

Description:

Queries the result of the pending asynchronous reduction to determine
how many messages from the prior batch of sends were sent to this
processor.

Return value:

If it returns zero, the asynchronous reduction is not yet complete.
The user code must call 'AP_recv()' with the expectation of receiving
more messages.  If desired, it is safe to block as long as the
'AP_DROPOUT' flag is specified (this flag makes 'AP_recv()' unblock and
return 0 if any reduction-related messages are seen).
'AP_recv_count()' can then be queried again.

If it returns nonzero, the asynchronous reduction is complete (at
least as far as this processor is concerned) and '*count' is set to
the number of messages whose destination is this processor.  `It is up
to the caller to compare this with the number received so far to
determine whether more messages are yet to arrive.`  After
'AP_recv_count()' returns nonzero, it is not necessary for this
processor to call 'AP_recv()' any longer.

.N Reduce_Organization

M*/

#define AP_recv_count(p)  \
        ( (AP_reduce_result<0) ? 0 : ( (*(p)=AP_reduce_result), 1) )






/************************************************************************/



/*
 * Handle an incoming message if probe has detected
 * one with AP_REDUCE_TAG or AP_BCAST_TAG
 */


void AP_recv_reduce(Minfo *minfo)
{
  int i;
  MPI_Status status;

#ifdef INFO_REDUCE
  printf("%d: received reduce msg from %d\n",AP_mypid,minfo->sender);
#endif

  /* Should be in state RSTATE_INIT, RSTATE_SENDING, or RSTATE_REDUCE 
   */

  if (AP_reduce_state==RSTATE_BCAST) 
    {
      fprintf(stderr,"%d: **** AP_recv_reduce: unexpected reduce "
	      "message from %d\n",AP_mypid,minfo->sender);
      AP_mpi_abort();
    }

  SUCCESS( MPI_Recv(AP_reduce_buf, AP_nprocs, MPI_INTEGER,
		    minfo->sender, minfo->tag, AP_comm, &status) );

  for (i=0; i<AP_nprocs; i++)
    {
      AP_nsends[i]+=AP_reduce_buf[i];
#if 0
      printf("%d:  AP_nsends[%d]=%d\n",AP_mypid,i,AP_nsends[i]);
#endif
    }

  AP_reduce_nrecv--;

  if (AP_reduce_nrecv<0)
    {
      fprintf(stderr,"%d: AP_reduce_send: too many reduce msgs received\n",
	      AP_mypid);
      AP_mpi_abort();
    }

  /* Pass it on
   */

  AP_reduce_send();
}




void AP_reduce_send(void)
{
  MPI_Request req;

  if (AP_reduce_nrecv>0)              /* Still waiting for incoming msgs */
    return;

  /* If this proc isn't in RSTATE_REDUCE, then it
   * hasn't gone through RSTATE_SENDING yet, and
   * its contribution hasn't been added.
   */

  if (AP_reduce_state!=RSTATE_REDUCE) 
    return;


  if (AP_mypid==0)                       /* reduction has reached root */
    {
      memcpy(AP_bcast_buf1,AP_nsends,sizeof(int)*AP_nprocs);
      AP_bcast_send();
      return;
    }

#ifdef INFO_REDUCE
  printf("%d: Sending reduction msg to %d\n",AP_mypid,AP_reduce_dest);
#endif

  SUCCESS( MPI_Isend(AP_nsends,AP_nprocs,MPI_INTEGER,
		     AP_reduce_dest,AP_REDUCE_TAG,AP_comm,&req) );
  SUCCESS( MPI_Request_free(&req) );

  /* Note: reception of BCAST msg implies the root has received
   * all reductions and these sends must be complete.
   */

  AP_reduce_state = RSTATE_BCAST;         /* waiting to receive BCAST */

}




void AP_recv_bcast(Minfo *minfo)
{
  MPI_Status status;

#ifdef INFO_REDUCE
  printf("%d: received bcast msg from %d\n",AP_mypid,minfo->sender);
#endif

  if (AP_reduce_state!=RSTATE_BCAST)
    {
      fprintf(stderr,"%d: **** AP_recv_bcast: unexpected broadcast message "
	      "from %d\n",AP_mypid,minfo->sender);
      AP_mpi_abort();
    }
      
  SUCCESS( MPI_Recv(AP_bcast_buf1, AP_nprocs, MPI_INTEGER,
		    minfo->sender, minfo->tag, AP_comm, &status) );

  AP_bcast_send();
}



/*
 * send to every proc that send to us in the reduction
 *	    
 * Note on send completion:
 *
 * The send buffers will not be reused until the next reduction.  This
 * is safe because the dest procs will not begin a new reduction until
 * they receive these msgs.
 *
 */
  

void AP_bcast_send(void)
{
  int dest1;
  int dest2;
  MPI_Request req;


  AP_reduce_result=AP_bcast_buf1[AP_mypid];

  /* Make sure to use the same communication pattern
   * as for the reduction, otherwise things may get out
   * of sync.
   */

  dest1=2*(AP_mypid+1)-1;
  dest2=dest1+1;


  if (dest2<AP_nprocs)
    {
      memcpy(AP_bcast_buf2,AP_bcast_buf1,sizeof(int)*AP_nprocs);
    
      SUCCESS( MPI_Isend(AP_bcast_buf2,AP_nprocs,MPI_INTEGER,
			 dest2,AP_BCAST_TAG,AP_comm,&req) );
      SUCCESS( MPI_Request_free(&req) );
    }


  if (dest1<AP_nprocs)
    {
      SUCCESS( MPI_Isend(AP_bcast_buf1,AP_nprocs,MPI_INTEGER,
			 dest1,AP_BCAST_TAG,AP_comm,&req) );
      SUCCESS( MPI_Request_free(&req) );
    }


  /* Note: this proc won't try to do another bcast until all procs
   * have completed another reduce, which they can't do until
   * this bcast is received and they reinit.
   */

#ifdef INFO_REDUCE
  printf("%d: result %d  sent bcast to %d, %d\n",
	 AP_mypid,AP_reduce_result,
	 (dest1<AP_nprocs)?dest1:-1,
	 (dest2<AP_nprocs)?dest2:-1);

#endif


  /*
   * We are done with the reduction, so reinitialize for the next one 
   */

  AP_reduce_init();
}




