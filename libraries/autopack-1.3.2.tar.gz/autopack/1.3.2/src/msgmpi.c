/*
 *  (C) 2000 UNIVERSITY OF CHICAGO
 *      See COPYRIGHT in top-level directory.
 */



#include "header.h"


/*
 * Interface to MPI with error checking
 */



/*
 * Receive message via MPI_Recv and check for errors
 *
 * Note: It is intended that MPI_IProbe() or MPI_Probe() be called
 * prior to this, so this routine will not actually block.
 *
 */


void AP_mpi_recv(void *buf,
		  int size,
		  int sendpid,
		  int tag)
{
  MPI_Status status;

  SUCCESS( MPI_Recv( buf, size, MPI_BYTE,
		     sendpid, tag, AP_comm, &status ) );

}



int AP_mpi_done(MPI_Request *req)
{
  int done;
  MPI_Status status;

  if (*req == MPI_REQUEST_NULL)
    return(1);


  SUCCESS( MPI_Test( req, &done, &status) );

  return(done);
}



/*
 * does a blocking/nonblocking probe for any msg.
 * if there is one, sets minfo (except msg field) and returns 1.
 * if not found, returns 0.  
 *
 * Flags may be:
 *    AP_BLOCKING         block until some message is available
 *                        Default is non-blocking.
 *
 * (If you choose blocking, it will return 1).
 * 
 */

  

int AP_mpi_probe(int flags, Minfo *minfo)
{
  MPI_Status status;
  int size;
  int mpiflag;

  if (flags & AP_BLOCKING)
    {
      if (AP_ndefer<=0)
	SUCCESS( MPI_Probe(MPI_ANY_SOURCE, MPI_ANY_TAG, AP_comm, &status) )
      else
	{
	  mpiflag=0;

	  /* There is no way to get a request for a probe, so
	   * there is no way to block on completion of (send | receive).
	   * So busy wait while there are deferred sends.
	   */

	  while (AP_check_sends(0)>0 && !mpiflag)
	    SUCCESS( MPI_Iprobe(MPI_ANY_SOURCE, MPI_ANY_TAG, AP_comm,
				&mpiflag, &status) );

	  /* if deferred sends have gone through,
	   * no longer any need to busy wait
	   */

	  if (!mpiflag)
	    SUCCESS( MPI_Probe(MPI_ANY_SOURCE, MPI_ANY_TAG, AP_comm,
			       &status) );
	}
    }
  else
    {
      if ( AP_ndefer>0 )
	AP_check_sends(0);

      SUCCESS( MPI_Iprobe(MPI_ANY_SOURCE, MPI_ANY_TAG, AP_comm,
			  &mpiflag, &status) );
      if (!mpiflag)
	return(0);
    }

  SUCCESS( MPI_Get_count(&status, MPI_BYTE, &size) );

  /* msg not received yet so does not set minfo->msg */
  minfo->sender = status.MPI_SOURCE;
  minfo->tag = status.MPI_TAG;
  minfo->size = size;

  return(1);
}



void AP_mpi_wait(MPI_Request *req)
{
  MPI_Status status;

  SUCCESS( MPI_Wait(req, &status) );
}




void AP_mpi_abort_msg(int errcode)
{
  char errmsg[MPI_MAX_ERROR_STRING];
  int errsize;

  fflush(stdout);
  MPI_Error_string(errcode,errmsg,&errsize);
  fprintf(stderr,"%d  error string: %s\n",AP_mypid,errmsg);
  MPI_Abort(AP_comm,errcode);
  abort();
}



void AP_mpi_abort(void)
{
  fprintf(stderr,"%d: **** calling MPI_Abort()\n",AP_mypid);
  fflush(stdout);
  MPI_Abort(AP_comm,0);
  abort();
}
