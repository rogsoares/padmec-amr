/*
 *  (C) 2000 UNIVERSITY OF CHICAGO
 *      See COPYRIGHT in top-level directory.
 */



#include "header.h"

#define POINTER int       /* Fortran type big enough to hold pointer */

#include "fort.h"


/*
 * Fortran bindings for the AUTOPACK functions
 *
 */


void ap_init_(void)
{
  if (sizeof(void *) != sizeof(int))
    {
      fprintf(stderr,"AP_INIT: warning: pointer and int sizes different\n");
      fprintf(stderr,"         sizeof(void *) = %d\n",sizeof(void *));
      fprintf(stderr,"         sizeof(int)    = %d\n",sizeof(int));
    }

  /* AP_init(*size,*packed,*nwait_proc,*nwait); */
  AP_init(NULL,NULL);

  /* printf("pid %d  %d\n",AP_mypid,getpid()); */
}



/*
 * void AP_finalize(void)
 *
 */

void ap_finalize_(void)
{
  AP_finalize();
}



/*
 * void AP_setparam(int size, int packed, int nwait_proc, int nwait);
 */


void ap_setparam_(int *size, int *packed, int *nwait_proc, int *nwait)
{
  AP_setparam(*size,*packed,*nwait_proc,*nwait);
}


/*
 * void *AP_alloc(int destpid, int tag, int size );
 * void AP_send(void *buf);
 *
 * not implemented- in fortran we will always use AP_bsend()
 *
 */



/*
 * void AP_flush(void);
 */

void ap_flush_(void)
{
  AP_flush();
}


/*
 * int AP_check_sends(int flags);
 *
 */

void ap_check_sends_(int *flags, int *ret)
{
  *ret=AP_check_sends(*flags);
}



/*
 * int AP_check_sends_proc(int pid, int flags);
 *
 */


void ap_check_sends_proc_(int *pid, int *flags, int *ret)
{
  *ret=AP_check_sends_proc(*pid, *flags);
}



/*
 * int AP_recv(int sender, int tag, int flags
 *	        void **ret_msg, int *ret_size, int *ret_sender, int *ret_tag)
 *
 * in fortran, the pointer to the message buffer will be sent back
 * in an integer
 *
 */

void ap_recv_(int *sender, int *tag, int *flags,
	      POINTER *ret_msg, int *ret_size, int *ret_sender, int *ret_tag,
	      int *ret)
{
  *ret= AP_recv(*sender, *tag, *flags,
		(void **)ret_msg, ret_size, ret_sender, ret_tag);

}		


/*D

AP_COPY_FREE - Copy message to Fortran variable and free buffer

Synopsis:

.n SUBROUTINE AP_COPY_FREE(dest, src, count)
.n <anytype> dest
.n INTEGER src, count

Parameters:

+ dest - a Fortran variable where the user wants to copy the message
. src  - the descriptor passed back by 'AP_RECV()'
- count - the size passed back by 'AP_RECV()'

Description:


After receiving a message using the Fortran binding of 'AP_recv()', call
this function to copy the message into Fortran memory space.  After
copying, this function will free the message descriptor so there is no
need to call 'AP_free()'.


D*/

void ap_copy_free_(void *dest, POINTER *src, int *count)
{
  memcpy( dest, (void *)(*src), *count);
  AP_free( (void *)(*src) );
}



/*
 * void AP_free(void *buf);
 *
 */

void ap_free_(POINTER *buf)
{
  AP_free( (void *)(*buf) );
}




/*
 * int AP_send_begin(void);
 *
 */

void ap_send_begin_(int *ret)
{
  *ret=AP_send_begin();
}




/*
 * void AP_send_end(void);
 *
 */

void ap_send_end_(void)
{
  AP_send_end();
}




/*
 * int AP_dsend_begin(void);
 *
 */


void ap_dsend_begin_(int *ret)
{
  *ret=AP_dsend_begin();
}




/*
 * void AP_dsend_end(void);
 *
 */

void ap_dsend_end_(void)
{
  AP_dsend_end();
}




/* int AP_recv_count(int *count)
 *
 */


void ap_recv_count_(int *count, int *ret)
{
  *ret= AP_recv_count(count);
}




/*
 * void AP_bsend(void *buf, int size, int dest, int tag)
 *
 */


void ap_bsend_(void *buf, int *size, int *dest, int *tag)
{
  AP_bsend(buf, *size, *dest, *tag);
}



/*
 * access global variables
 *
 */


/*************************************************/
/*D

AP_RANK - get the rank of this processor

Synopsis:

.n SUBROUTINE AP_RANK(rank)
.n INTEGER rank

Parameters:

. rank - on return this will be set to the rank

Description:

Duplicates 'MPI' functionality; provided for convenience
in the Fortran interface. 

Note - in C, the user should access the global variable AP_rank
to obtain the processor rank.

D*/


void ap_rank_(int *ret)
{
  *ret=AP_rank;
}


void ap_mypid_(int *ret)
{
  *ret=AP_mypid;
}


/*************************************************/
/*D

AP_SIZE - get the number of processors

Synopsis:

.n SUBROUTINE AP_SIZE(size)
.n INTEGER size

Parameters:

. size - on return this will be set to the number of processors

Description:

Duplicates 'MPI' functionality; provided for convenience in the
Fortran interface.

Note - in C, the user should access the global variable 'AP_size' to
access the number of processors.


D*/


void ap_size_(int *ret)
{
  *ret=AP_size;
}


void ap_nprocs_(int *ret)
{
  *ret=AP_nprocs;
}


