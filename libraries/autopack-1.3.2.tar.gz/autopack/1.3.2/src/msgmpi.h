/*
 *  (C) 2000 UNIVERSITY OF CHICAGO
 *      See COPYRIGHT in top-level directory.
 */





/******************************************************  
 * WARNING: This file automatically generated.        *  
 *          Do not edit by hand.                      *  
 ******************************************************  
 */                                                      




extern void AP_mpi_recv(void *buf,
                         int size,
                         int sendpid,
                         int tag);
extern int AP_mpi_done(MPI_Request *req);
extern int AP_mpi_probe(int flags, Minfo *minfo);
extern void AP_mpi_wait(MPI_Request *req);
extern void AP_mpi_abort_msg(int errcode);
extern void AP_mpi_abort(void);
