/*
 *  (C) 2000 UNIVERSITY OF CHICAGO
 *      See COPYRIGHT in top-level directory.
 */





/******************************************************  
 * WARNING: This file automatically generated.        *  
 *          Do not edit by hand.                      *  
 ******************************************************  
 */                                                      




extern void *AP_malloc(int size);
extern void AP_init(int *argc, char ***argv);
extern void AP_finalize(void);
extern void AP_setparam(int size, int packed, int nwait_proc, int nwait);
extern int AP_count(int packsize, int msgsize);
extern Bhead *AP_alloc_block(int pid, int size, int type);
extern void AP_free_block(Bhead *BH, int type);
extern Bhead *AP_alloc_block_init(int pid, int size, int type);
extern void AP_close_block(Bhead *BH, int type);
extern Bhead *AP_get_block_for_msg(int pid, int size, int type);
extern void *AP_alloc_indiv(int pid, int tag, int size, int type, Ppair *p);
extern void *AP_realloc(void *buf, int newsize);
extern void AP_cancel(void *buf);
extern int AP_ppair_next(Ppair *p, int type);
