/*
 *  (C) 2000 UNIVERSITY OF CHICAGO
 *      See COPYRIGHT in top-level directory.
 */





/******************************************************  
 * WARNING: This file automatically generated.        *  
 *          Do not edit by hand.                      *  
 ******************************************************  
 */                                                      




extern void ap_init_(void);
extern void ap_finalize_(void);
extern void ap_setparam_(int *size, int *packed, int *nwait_proc, int *nwait);
extern void ap_flush_(void);
extern void ap_check_sends_(int *flags, int *ret);
extern void ap_check_sends_proc_(int *pid, int *flags, int *ret);
extern void ap_recv_(int *sender, int *tag, int *flags,
                     POINTER *ret_msg, int *ret_size, int *ret_sender, int *ret_tag,
                     int *ret);
extern void ap_copy_free_(void *dest, POINTER *src, int *count);
extern void ap_free_(POINTER *buf);
extern void ap_send_begin_(int *ret);
extern void ap_send_end_(void);
extern void ap_dsend_begin_(int *ret);
extern void ap_dsend_end_(void);
extern void ap_recv_count_(int *count, int *ret);
extern void ap_bsend_(void *buf, int *size, int *dest, int *tag);
extern void ap_rank_(int *ret);
extern void ap_mypid_(int *ret);
extern void ap_size_(int *ret);
extern void ap_nprocs_(int *ret);
