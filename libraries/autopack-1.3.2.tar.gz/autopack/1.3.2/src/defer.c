/*
 *  (C) 2000 UNIVERSITY OF CHICAGO
 *      See COPYRIGHT in top-level directory.
 */




#include "header.h"


/*
 * Management of deferred sends
 */





/* 
 * null MH means this is a block send
 */

int AP_send_or_defer(Bhead *BH, Mhead *MH)
{
  Ppair *p;

  CHECK_BLOCK(BH);

  /* Indiv messages already have state set to MSTATE_SENT,
   * but blocks still need to have their state set
   */
  
  if (!MH)
    BH->state=BSTATE_SENT;


  /* Defer the send if any of these:
   *  - the destination proc has some msgs waiting already
   *  - over the global limit on mpi requests
   *  - over the per-proc limit on mpi requests
   */

  p= &AP_first_defer[BH->pid];

#if 1
  if (!p->BH &&
      AP_nwait<AP_max_nwait &&
      AP_nwait_proc[BH->pid]<AP_max_nwait_proc)
    {
      AP_do_send(BH,MH);
      return(1);
    }

  INFO_DEFER_PPAIR(BH,MH,"Deferring");

  AP_ndefer++;
  AP_ndefer_proc[BH->pid]++;

  AP_ppair_update(p,BH,MH);
  return(0);

#else

  if (p->BH)
    {
      INFO_DEFER_PPAIR(BH,MH,"Deferring");
      return(0);                              /* Already something queued */
    }

  if ( (AP_nwait>=AP_max_nwait) ||
       (AP_nwait_proc[BH->pid]>=AP_max_nwait_proc) )
    {
      AP_ppair_set(p,BH,MH);
      INFO_DEFER_PPAIR(BH,MH,"Deferring (first one)");

      return(0);
    }

  AP_do_send(BH,MH);
  return(1);

#endif

}




void AP_do_send(Bhead *BH, Mhead *MH)
{
  CHECK_BLOCK(BH);

  if (MH)                                                 /* indiv msg */
    {
      CHECK_MSG_STATE(MH,MSTATE_SENT);

      SUCCESS( MPI_Isend( mh_to_buf(MH) , MH->size, MPI_BYTE,
			  BH->pid, MH->tag, AP_comm, &(MH->sendreq) ) );

      MH->state=MSTATE_WAIT;
    }
  else                                                    /* block msg */
    {
      CHECK_BLOCK_STATE(BH,BSTATE_SENT);

      SUCCESS( MPI_Isend( BH, BH->tail, MPI_BYTE,
			  BH->pid, AP_BLOCK_TAG, AP_comm, &(BH->sendreq) ) );

      BH->state=BSTATE_WAIT;
    }


  AP_nwait++;
  AP_nwait_proc[BH->pid]++;
  AP_ppair_update( &AP_first_wait[BH->pid] ,BH,MH);
}



/*
 * Process as many deferred sends as possible,
 * in round-robin fashion for all destinations.
 */


void AP_send_deferred(void)
{
  int count;                               /* how many procs have not sent */
  static int pturn=0;


  count=0;
  while ( AP_ndefer>0 && AP_nwait<AP_max_nwait)
    {
      count++;

      if (AP_send_deferred_one(pturn))
	count=0;

      if (count>=AP_nprocs)            /* if all procs passed */
	return;

      pturn=(pturn+1)%AP_nprocs;
    }

  CHECK_NDEFER();
  return;
}


/*
 * Process as many deferred sends as
 * possible for the given destination.
 *
 */


void AP_send_deferred_proc(int pid)
{
  while (AP_send_deferred_one(pid))
    ;                                                       /* do nothing */
}




/* 
 * Try to process one deferred request for the dest processor.
 * return 1 if a deferred request is sent, 0 otherwise
 */


int AP_send_deferred_one(int pid)
{
  Ppair *p;

  p= &AP_first_defer[pid];

#ifdef CHECKS
  if ( (p->BH==NULL) != (AP_ndefer_proc[pid]==0) )
    {
      fprintf(stderr,"%d: AP_send_deferred_proc: "
	      "conflict between AP_first_defer[%d] and AP_ndefer_proc[%d]\n",
	      AP_mypid,pid,pid);
      AP_mpi_abort();
    }
#endif

  if ( (!p->BH) ||                                  /* None deferred */
       (AP_nwait_proc[pid]>=AP_max_nwait_proc) ||   /* Too many this proc */
       (AP_nwait>=AP_max_nwait) )                   /* Too many all procs */
    return(0);


  INFO_DEFER_PPAIR(p->BH,p->MH,"Releasing");

  AP_ndefer--;
  AP_ndefer_proc[p->BH->pid]--;

  AP_do_send(p->BH,p->MH);

  if ( AP_ppair_next(p,AP_NEXTREQ) != STATE_SENT )
    AP_ppair_set(p,NULL,NULL);

  return(1);
}



