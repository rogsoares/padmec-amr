/*
 *  (C) 2000 UNIVERSITY OF CHICAGO
 *      See COPYRIGHT in top-level directory.
 */





/******************************************************  
 * WARNING: This file automatically generated.        *  
 *          Do not edit by hand.                      *  
 ******************************************************  
 */                                                      




extern void AP_check_block(Bhead *BH);
extern void AP_check_msg(Mhead *MH);
extern void AP_check_msg_state(Mhead *MH, int state);
extern void AP_check_block_state(Bhead *BH, int state);
extern void AP_check_ndefer(void);
extern void AP_check_nwait(void);
extern void AP_info_block(Bhead *BH, char *str);
extern void AP_info_msg(Mhead *MH, char *str);
extern void AP_info_ppair(Bhead *BH, Mhead *MH, char *str);
extern void AP_info_defer_stats(char *s);
