/*
 *  (C) 2000 UNIVERSITY OF CHICAGO
 *      See COPYRIGHT in top-level directory.
 */




#define __AP_ALLOCATE__
#include "header.h"


/*
 * An important note about message ordering
 *
 * MPI guarantees that the order of messages from one proc to another
 * will be preserved.  In order to preserve this ordering, this library
 * requires that messages be sent in the same order they are allocated.
 *
 */


/***************************************************************************/




#ifdef CHECKS
static int blockid=0;      /* counter for assigning block ids */
static int msgid=100;      /* counter for assigning msg ids */
#endif




/***************************************************************************/


void *AP_malloc(int size)
{
  void *ptr;

  ptr=malloc(size);

  if (!ptr)
    {
      perror("malloc");
      fprintf(stderr,"AP_malloc: failed to malloc %d bytes\n",size);
      AP_mpi_abort();
    }

  return(ptr);
}



/***************************************************************************/

/*
 * Initialization and settings 
 *
 */


/*N AP_init

.n SUBROUTINE AP_INIT

Parameters:

+ argc - pointer to number of command line arguments
- argv - pointer to array of command line arguments

Description:

This routine must be called prior to any other 'AUTOPACK' calls.
The version for 'C' accepts the 'argc' and 'argv' that are
provided by the arguments to 'main()'.  They may be passed
as 'NULL' if no values are available.

During initialization, certain library parameter values will
be set to default values.  The user may wish to change them
using 'AP_setparam()'.  In future there will be provision
to set the defaults through the command line arguments.

Call this routine after MPI_Init().


Return Value:
None

N*/


/*@
AP_init - initialize the 'AUTOPACK' library

.N AP_init
@*/

void AP_init(int *argc, char ***argv)
{
  int i;
  static int initialized=0;

  if (initialized)
    {
      fprintf(stderr,"AP_init: library already initialized\n");
      AP_mpi_abort();
    }

  initialized=1;


  /*
   * Create a separate communicator for this lib
   */

  SUCCESS( MPI_Comm_dup(MPI_COMM_WORLD,&AP_comm) );

  SUCCESS( MPI_Comm_size(AP_comm,&AP_nprocs) );    /* deprecated */
  SUCCESS( MPI_Comm_size(AP_comm,&AP_size) );

  SUCCESS( MPI_Comm_rank(AP_comm,&AP_mypid) );     /* deprecated */
  SUCCESS( MPI_Comm_rank(AP_comm,&AP_rank) );


  /*
   * Sends
   */

  AP_sendbuffer= (pList *) AP_malloc( AP_nprocs * sizeof(pList) );
  for (i=0; i<AP_nprocs; i++)
    AP_sendbuffer[i]=AP_list_new();

  CHECK_DO(AP_nsendblocks=0);


  /*
   * Receives
   */


  AP_recvbuffer= (pList *) AP_malloc( AP_nprocs * sizeof(pList) );
  for (i=0; i<AP_nprocs; i++)
    AP_recvbuffer[i]=AP_list_new();

  CHECK_DO(AP_nrecvblocks=0);


  /*
   * These are for use with MPI_Waitsome() 
   */

  AP_waitpid  = (int *)AP_malloc( AP_nprocs * sizeof(int) );
  AP_waitptr  = (MPI_Request **)AP_malloc( AP_nprocs * sizeof(MPI_Request *) );
  AP_waitreq  = (MPI_Request *)AP_malloc( AP_nprocs * sizeof(MPI_Request) );
  AP_waitindex= (int *)AP_malloc( AP_nprocs * sizeof(int) );
  AP_waitstat = (MPI_Status *)AP_malloc(AP_nprocs * sizeof(MPI_Status) );


  /*
   * arrays to manage queued sends
   */

  AP_first_empty= (Ppair *) AP_malloc( AP_nprocs * sizeof(Ppair) );

  AP_first_wait=  (Ppair *) AP_malloc( AP_nprocs * sizeof(Ppair) );

  AP_nwait=0;
  AP_nwait_proc=  (int *) AP_malloc( AP_nprocs * sizeof(int) );

  AP_first_defer=  (Ppair *) AP_malloc( AP_nprocs * sizeof(Ppair) );

  AP_ndefer=0;
  AP_ndefer_proc= (int *) AP_malloc( AP_nprocs * sizeof(int) );

  for (i=0; i<AP_nprocs; i++)
    {
      AP_ppair_set(&AP_first_empty[i],NULL,NULL);

      AP_ppair_set(&AP_first_wait[i],NULL,NULL);
      AP_nwait_proc[i]=0;

      AP_ppair_set(&AP_first_defer[i],NULL,NULL);

      AP_ndefer_proc[i]=0;
    }

  /*
   * array to manage searches for recv msgs
   */

  AP_nunseen=0;
  AP_first_unseen= (Ppair *) AP_malloc( AP_nprocs * sizeof(Ppair) );

  for (i=0; i<AP_nprocs; i++)
    AP_ppair_set(&AP_first_unseen[i],NULL,NULL);


  /*
   * reductions
   *
   */

  AP_nsends= (int *) AP_malloc( AP_nprocs * sizeof(int) );
  AP_reduce_buf= (int *) AP_malloc( AP_nprocs * sizeof(int) );
  AP_bcast_buf1= (int *) AP_malloc( AP_nprocs * sizeof(int) );
  AP_bcast_buf2= (int *) AP_malloc( AP_nprocs * sizeof(int) );

  AP_reduce_init();

  /*
   * Warning message if -DCHECKS
   */

#ifdef CHECKS
  if (AP_mypid==0)
    printf("AP_init: library compiled with -DCHECKS\n");
#endif

#ifdef SERIALIZE
  if (AP_mypid==0)
    printf("AP_init: library compiled with -DSERIALIZE\n");
#endif

#if 0
  if (AP_mypid==0)
    printf("AP_init: BHS=%d  MHS=%d\n",BHS,MHS);
#endif


  /*
   * set global parameters
   */

  /* AP_setparam(size,packed,nwait_proc,nwait); */

  AP_setparam(1024,1,100,100);    /* default values */


}


/*N AP_finalize

.n SUBROUTINE AP_FINALIZE

Parameters:
None

Description:

This routine should be called when user is done using 'AUTOPACK'.
Call before MPI_Finalize().

Return Value:
None

N*/



/*@
AP_finalize - terminate the 'AUTOPACK' library

.N AP_finalize
@*/

void AP_finalize(void)
{
  /* For now, do nothing */
  /* eventually want to put in code to free memory here */
}



/*@

AP_setparam - Reset the parameters that govern behavior of 'AUTOPACK'

.n SUBROUTINE AP_SETPARAM(size, packed, nwait_proc, nwait)
.n INTEGER size, packed, nwait_proc, nwait

Parameters:

+ size       -  preferred size in bytes for memory blocks (packages)
. packed     -  if nonzero, enable automatic packing
. nwait_proc -  max number of MPI sends per destination proc
- nwait      -  max number of MPI sends for all destinations.
                If nwait<0, use only per-destination limit.
                
Return Value:
None

Description:

'AUTOPACK' parameters may be changed at any time.  Changes to 'size' or
'packed' will affect subsequent messages but will not affect any
message already allocated.  Changes to 'nwait_proc' or 'nwait' will
govern subsequent MPI sends.  If the limit is reduced, no pending
sends are cancelled; the limit may not be attained until some sends
complete.

User advice: 

Size is a guideline; allocation will be made larger if necessary.
If it is too small, you will end up with one message
per package/memory block.  Setting it too large will waste memory and
reduce potential overlap of computation/communication.

@*/


void AP_setparam(int size, int packed, int nwait_proc, int nwait)
{
  if (nwait<0)
    nwait= nwait_proc*AP_nprocs;

  AP_blocksize = size;
  AP_packmode= packed;
  AP_max_nwait_proc= nwait_proc;
  AP_max_nwait= nwait;
}  


/***************************************************************************/


/*
 * Allocation
 */



/*
 * convenience function
 * computes the number of messages of the given size
 * that will fit in a package of the given size
 *
 */

int AP_count(int packsize, int msgsize)
{
  int msize;
  int psize;

  msize= ALIGNED_SIZE(msgsize) + MHS;
  psize= packsize - BHS;

  if (msize>psize)
    return(1);

  return(psize/msize);
}



/*
 * Allocate a memory block for send or receive message buffers.
 * The block header must be initialized (or an incoming block
 * may have this info already.)
 *
 * Size specified is total including header (size should
 * not be less than BHS).
 *
 */


Bhead *AP_alloc_block(int pid, int size, int type)
{
  Bhead *block;

  block = (Bhead *) AP_malloc(size);

#ifdef CHECKS
  block->startflag=BLOCK_START_FLAG;
  block->id=AP_mypid*100+blockid++;
  block->endflag=BLOCK_END_FLAG;
#endif

  if (type==AP_SENDBLOCK)
    {
      block->listitem = AP_list_append(AP_sendbuffer[pid],block);
      CHECK_DO(AP_nsendblocks++);
    }
  else
    {
      block->listitem = AP_list_append(AP_recvbuffer[pid],block);
      CHECK_DO(AP_nrecvblocks++);
    }

  return(block);
}
  



void AP_free_block(Bhead *BH, int type)
{
  CHECK_BLOCK(BH);
  INFO_BLOCK(BH,"Freeing block");


  if (type==AP_SENDBLOCK)
    {
#ifdef INFO_SENDBLKS
      printf("%d: Freeing send block              id=%d\n",AP_mypid,BH->id);
#endif
#ifdef CHECKS
      if ( (BH->packed && BH->state!=BSTATE_DONE) ||
	   (!BH->packed && BH->state!=BSTATE_CLOSED) )
	{
	  fprintf(stderr,"%d: AP_free_block: "
		  "error, trying to free block in use: "
		  "packed=%d  state=%d\n",
		  AP_mypid,BH->packed,BH->state);
	  AP_mpi_abort();
	}
#endif

      AP_list_delete_item(AP_sendbuffer[BH->pid],BH->listitem);
      CHECK_DO(AP_nsendblocks--);
    }
  else
    {
#ifdef INFO_RECVBLKS
      printf("%d: Freeing receive block              id=%d\n",AP_mypid,BH->id);
#endif
      AP_list_delete_item(AP_recvbuffer[BH->pid],BH->listitem);
      CHECK_DO(AP_nrecvblocks--);

      {  /* Fix for unseen problem */              /* rml20021024 */
        Ppair *p;                                  /* rml20021024 */
                                                   /* rml20021024 */
        p= &AP_first_unseen[BH->pid];              /* rml20021024 */
                                                   /* rml20021024 */
        if (AP_nunseen==0)                         /* rml20021024 */
          {                                        /* rml20021024 */
            AP_ppair_set(p,NULL,NULL);             /* rml20021024 */
          }                                        /* rml20021024 */
        else                                       /* rml20021024 */
          if (BH==p->BH)                           /* rml20021024 */
            {                                      /* rml20021024 */
              p->MH=NULL;                          /* rml20021024 */
              AP_ppair_next(p,AP_NEXTINDIV);       /* rml20021024 */
            }                                      /* rml20021024 */
      }                                            /* rml20021024 */

    }

#ifdef CHECKS
  BH->state=BSTATE_DELETED;
#endif

  free(BH);
}




/*
 * allocate new block for send or receive buffer big enough to
 * hold a message of given size (size should include message header)
 *
 */


Bhead *AP_alloc_block_init(int pid, int size, int type)
{
  Bhead *BH;

  size += BHS ;

  if (size < AP_blocksize)       
    size = AP_blocksize;          /* Bump up to standard block size */


  BH= AP_alloc_block(pid, size, type);

#ifdef INFO_RECVBLKS
  if (type==AP_RECVBLOCK)
    printf("%d: Alloc indiv  recv block id=%d\n",AP_mypid,BH->id);
#endif

  BH->pid=pid;
  BH->size= size;                 /* total size in bytes of block */
  BH->packed= AP_packmode;       /* use current mode */
  BH->state= BSTATE_OPEN;
  BH->sendreq= MPI_REQUEST_NULL;

  BH->nmsgs=0;
  BH->npending=0;

  BH->tail= BHS;

  return(BH);
}



/*
 * if block is closed, it means it no longer
 * can accept new message allocations.
 */


void AP_close_block(Bhead *BH, int type)
{
  CHECK_BLOCK_STATE(BH,BSTATE_OPEN);

#ifdef INFO_SENDBLKS
  if (type==AP_SENDBLOCK)
    printf("%d: closing block id= %d  packed %d  npending=%d\n",
	   AP_mypid,BH->id,BH->packed,BH->npending);
#endif

  BH->state = BSTATE_CLOSED;
  INFO_BLOCK(BH,"********** Closed block");

  if (BH->npending != 0)
    return;

  if (type==AP_SENDBLOCK)
    {
      if (BH->packed)
	AP_send_or_defer(BH,NULL);
    }
  else
    AP_free_block(BH,type);
}



/*
 * find an existing block that has room for a message,
 * or allocate a new block if necessary.
 * 
 */


Bhead *AP_get_block_for_msg(int pid, int size, int type)
{
  Bhead *BH;
  pList blocklist;

  if (type==AP_SENDBLOCK)
    blocklist=AP_sendbuffer[pid];
  else
    blocklist=AP_recvbuffer[pid];


  if ( !AP_list_tail(blocklist,(void **)&BH) ||
       BH->state != BSTATE_OPEN )
    return( AP_alloc_block_init(pid,size,type) );

  CHECK_BLOCK(BH);

  /*
   * An open block exists.
   * Block must have same mode (packed/non-packed)
   * that is currently set, and have room available.
   */

  if (BH->packed == AP_packmode &&
      BH->size-BH->tail >= size)
    return(BH);

  /*
   * last block is not suitable, close it and alloc a new one
   */

  AP_close_block(BH,type);

  return( AP_alloc_block_init(pid,size,type) );
}





void *AP_alloc_indiv(int pid, int tag, int size, int type, Ppair *p)
{
  Bhead *BH;
  Mhead *MH;
  int total_size;


  total_size = ALIGNED_SIZE(size);
  total_size += MHS;

  BH= AP_get_block_for_msg(pid, total_size, type);
  CHECK_BLOCK(BH);

  MH= bh_offset_mh(BH,BH->tail);
  MH->bhead = BH->tail;

  /*
   * Update the block header for the new message 
   */

  BH->nmsgs++;
  BH->npending++;

  BH->tail += total_size;

  /*
   * Initialize the new message header
   */

  MH->next= BH->tail;
  MH->state= MSTATE_EMPTY;
  MH->tag = tag;
  MH->size = size;

#ifdef CHECKS
  MH->startflag= MSG_START_FLAG;
  MH->id=msgid++;
  MH->endflag= MSG_END_FLAG;
#endif

  AP_ppair_set(p,BH,MH);
  return( mh_to_buf(MH) );
}


/*@

AP_realloc - Reallocate an outgoing message buffer

Parameters:

+ buf        - an outgoing buffer previously allocated by 'AP_alloc()'
- newsize    - the new desired size of the buffer


Description:

Still being tested.

Changes the size of the buffer pointed to by 'buf' to 'newsize' bytes
and returns a pointer to the (possibly moved) buffer. The contents
will be unchanged up to the lesser of the new and old sizes.

The buffer must be the most recently allocated buffer for the
destination, otherwise it is an error.  It is also erroneous to
specify a buffer which has previously passed to 'AP_send()'.  These
errors may or may not be detected depending on whether the library was
compiled with NO_USER_CHECKS.

If the buffer is reduced in size, it is guaranteed not to be moved.
If the buffer is increased in size, it may or may not move depending
on available space in the current internal memory block (package).


Return Value:
A pointer to the reallocated buffer.

@*/


void *AP_realloc(void *buf, int newsize)
{
  Mhead *MH;
  Bhead *BH;
  int new_tot_size;
  void *newbuf;

  MH= buf_to_mh(buf);
  CHECK_MSG(MH);
  BH= mh_to_bh(MH);
  CHECK_BLOCK(BH);

#ifndef NO_USER_CHECKS
  if( MH->state != MSTATE_EMPTY )
  {
    fprintf(stderr,"AP_realloc: tried to realloc message in wrong state\n");
    AP_mpi_abort();
  }

  /* check if message is the most recently allocated one for the given
   * destination.  if not, do not allow resizing for two reasons.
   * first, if made smaller, there would be a hole in the package that
   * would never be used.  second, if made bigger, a move would be
   * required that would disrupt the message ordering.
   */

  if (MH->next!=BH->tail)
  {
    fprintf(stderr,"AP_realloc: message is not last in block\n");
    AP_mpi_abort();
  }

  if (AP_listitem_next(BH->listitem))
  {
    fprintf(stderr,"AP_realloc: message is not last allocated for dest\n");
    AP_mpi_abort();
  }
#endif

  new_tot_size= ALIGNED_SIZE(newsize) + MHS;

  /* if new size still fits in this block, just adjust headers
   * (could be shrinking or growing)
   */

  if ( (BH->size - MH->bhead) >= new_tot_size)
    {
      BH->tail = MH->bhead + new_tot_size;
      MH->next = BH->tail;
      MH->size = newsize;
      return(buf);
    }

  /* will not fit-  reallocate and move it 
   * must be the case that newsize > MH->size 
   */

  newbuf=AP_alloc(BH->pid,MH->tag,newsize);   /* allocate new buffer */
  memcpy(newbuf,buf,MH->size);

  BH->tail = MH->bhead;                       /* delete the old buffer */
  BH->nmsgs--;
  BH->npending--;

  AP_close_block(BH,AP_SENDBLOCK);

  return(newbuf);
}



/*@

AP_cancel - Cancel an outgoing message buffer

Parameters:

- buf        - an outgoing buffer previously allocated by 'AP_alloc()'

Description:

Still being tested.

Needs a Fortran interface.

Cancels a send buffer previously allocated by 'AP_alloc()' and
frees any internal buffer space.  After this call, 'buf' is invalid
and should not be used in any way.

The buffer must be the most recently allocated buffer for the
destination, otherwise it is an error.  It is also erroneous to
specify a buffer which has previously passed to 'AP_send()'.  These
errors may or may not be detected depending on whether the library was
compiled with NO_USER_CHECKS.

Return Value:
None

@*/


void AP_cancel(void *buf)
{
  Mhead *MH;
  Bhead *BH;
  int new_tot_size;
  void *newbuf;

  MH= buf_to_mh(buf);
  CHECK_MSG(MH);
  BH= mh_to_bh(MH);
  CHECK_BLOCK(BH);

#ifndef NO_USER_CHECKS
  if( MH->state != MSTATE_EMPTY )
  {
    fprintf(stderr,"AP_cancel: tried to cancel message in wrong state\n");
    AP_mpi_abort();
  }

  /* check if message is the most recently allocated one for the given
   * destination.  if not, do not allow cancelling to 
   * avoid a hole in the package.
   */

  if (MH->next!=BH->tail)
  {
    fprintf(stderr,"AP_cancel: message is not last in block\n");
    AP_mpi_abort();
  }

  if (AP_listitem_next(BH->listitem))
  {
    fprintf(stderr,"AP_cancel: message is not last allocated for dest\n");
    AP_mpi_abort();
  }
#endif


  BH->tail = MH->bhead;                       /* delete the old buffer */
  BH->nmsgs--;
  BH->npending--;
}



/*********************************************************************/


/*
 * Manipulation of Ppairs
 * 
 */


int AP_ppair_next(Ppair *p, int type)
{
  pListitem item;

  if (!p->BH)                                 /* not at any msg now */
    return(STATE_NONE);

  CHECK_BLOCK(p->BH);


  if (p->MH)
    {
      CHECK_MSG(p->MH);

#ifdef CHECKS
      if (p->MH->next > p->BH->tail)
	{
	  fprintf(stderr,"AP_next: ran off end of block\n");
	  AP_mpi_abort();
	}
#endif

      if (p->MH->next < p->BH->tail)          /* more msgs in same block */
	{
	  /* p->BH unchanged */
	  p->MH= bh_offset_mh(p->BH, p->MH->next);
	  return(p->MH->state);
	}
      
      /* this is the last msg in block (next==tail) */
    }

  /*
   * Go on to next block
   */

  item=AP_listitem_next(p->BH->listitem); 

  if (!item)                       /* No more blocks */
    {
      AP_ppair_set(p,NULL,NULL);
      return(STATE_NONE);
    }

  p->BH = AP_listitem_data(item);
  CHECK_BLOCK(p->BH);

#ifdef CHECKS
  if ( p->BH->tail <= BHS )
    {
      fprintf(stderr,"AP_next: block null/empty\n");
      AP_mpi_abort();
    }
#endif

  /*
   * If we want the next send request, and this block is packed,
   * then not interested in individual messages; otherwise,
   * want the first message in the block.
   */

  if (type==AP_NEXTREQ && p->BH->packed)
    {
      p->MH=NULL;
      return(p->BH->state);
    }
  else
    {
      p->MH = bh_first_mh(p->BH);        /* first msg in block */
      CHECK_MSG(p->MH);
      return(p->MH->state);
    }

}



