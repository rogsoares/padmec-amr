/*
 *  (C) 2000 UNIVERSITY OF CHICAGO
 *      See COPYRIGHT in top-level directory.
 */



#include "header.h"


/****************************************************************************/

/*
 * Sends
 *
 */


/*@

AP_alloc - Allocate an outgoing message buffer

Parameters:

+ destpid - the destination of the message
. tag     - the message''s tag
- size    - size of the message in bytes

Description:

Allocates a buffer for an outgoing message with the given destination,
tag, and size.  Returns a pointer to this buffer.  After the caller
has stored data in the buffer, 'AP_send()' is used to send it.

Return Value:
A pointer to the allocated buffer.


@*/


void *AP_alloc(int destpid, int tag, int size )
{
  void *buf;
  Ppair p;

#ifndef NO_USER_CHECKS

  if (tag>=AP_LIB_TAG)
    {
      fprintf(stderr,"AP_alloc: tag %d is reserved; check AP_MAXTAG\n",tag);
      AP_mpi_abort();
    }

  if (destpid<0 || destpid>=AP_nprocs)
    {
      fprintf(stderr,"AP_alloc: destination pid %d is out of range\n",
	      destpid);
      AP_mpi_abort();
    }

#endif

  buf= AP_alloc_indiv(destpid, tag, size, AP_SENDBLOCK, &p);
  CHECK_MSG(p.MH);

  INFO_MSG(MH,"New allocated message");
  INFO_BLOCK(p.BH,"In block");

#ifndef NO_USER_CHECKS
  AP_ppair_update( &AP_first_empty[destpid], p.BH, p.MH);
#endif

  return(buf);
}
	  



/*@

AP_send - send a message

Parameters:

. buf - a message buffer previously allocated via 'AP_alloc()'

Return Value:
None

Description:

Send a message previously allocated with AP_alloc().
After sending the message, the user may no longer
access 'buf'.

Parameter values 'packed', 'nwait', and 'nwait_proc' (see
'AP_setparam()') will affect when the send actually takes place.  If
packing is enabled, the message will not be sent until a full package
has been accumulated or the user calls AP_flush().  The send may be
also be deferred depending on the current number of sends posted to
MPI, and the value of 'nwait_proc' and 'nwait' (see 'AP_setparam()').

In order for the library to free memory associated with the sends, and
to process deferred messages, the user should call AP_check_sends()
periodically until the return value indicates no messages are
deferred.  Calls to AP_recv() will also expedite deferred messages.

Caveats:

At present, all messages are sent using type MPI_BYTE.

@*/


void AP_send(void *buf)
{
  Mhead *MH ;
  Bhead *BH;

#ifndef NO_USER_CHECKS
  Ppair *p;
#endif


  MH= buf_to_mh(buf);
  CHECK_MSG(MH);

#ifndef NO_USER_CHECKS
  if( MH->state != MSTATE_EMPTY )
  {
    fprintf(stderr,"AP_send: tried to send message in wrong state\n");
    AP_mpi_abort();
  }
#endif

  MH->state= MSTATE_SENT;

  BH= mh_to_bh(MH);
  CHECK_BLOCK(BH);
  BH->npending--;


#ifndef NO_USER_CHECKS
  p= &AP_first_empty[BH->pid];
  if (p->MH!=MH)
    {
      fprintf(stderr,"%d: AP_send: Send to destination %d done out of order\n",
	      AP_mypid,BH->pid);
      AP_mpi_abort();
    }
  else
    AP_ppair_next(p,AP_NEXTINDIV);
#endif


  if (AP_count_enable)                      /* Keep count for reduction */
    AP_nsends[BH->pid]++;

  if (BH->packed)
    {
      if ( BH->state==BSTATE_CLOSED && BH->npending==0 )
	AP_send_or_defer(BH,NULL);
    }
  else
    AP_send_or_defer(BH,MH);

}


  


/*@
 
AP_flush - flush all pending sends

.n SUBROUTINE AP_FLUSH

Parameters:
. None - 

Return Value:
None

Description:
Flush all sends.  Any open packages are closed and sent.

'AP_send()' tells the library to send the message, but the underlying
MPI send is governed by the settings passed to 'AP_init()' or
'AP_setparam()'.

@*/


void AP_flush(void)
{
  Bhead *BH;
  int i;

  /*
   * only the tail block for each proc may be open,
   * so only need to check there
   *
   * for non-packed blocks, this call is not really 
   * necessary but it will close the last block
   * to allow it to be freed.
   *
   */

  for (i=0; i<AP_nprocs; i++)
    {
      if (AP_list_tail(AP_sendbuffer[i],(void **)&BH) &&
	  BH->state==BSTATE_OPEN &&
	  BH->nmsgs!=0)                     /* In case of cancelled msg */
	AP_close_block(BH,AP_SENDBLOCK);
    }
}



