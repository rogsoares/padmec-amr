/*
 *  (C) 2000 UNIVERSITY OF CHICAGO
 *      See COPYRIGHT in top-level directory.
 */




/******************************************************  
 * WARNING: This file automatically generated.        *  
 *          Do not edit by hand.                      *  
 ******************************************************  
 */                                                      




#ifndef _AUTOPACK_H
#define _AUTOPACK_H

#ifdef __cplusplus
extern "C" {
#endif  /* __cplusplus */ 




/*@
AP_init - initialize the 'AUTOPACK' library

.N AP_init
@*/

extern void AP_init(int *argc, char ***argv);




/*@
AP_finalize - terminate the 'AUTOPACK' library

.N AP_finalize
@*/

extern void AP_finalize(void);




/*@

AP_setparam - Reset the parameters that govern behavior of 'AUTOPACK'

.n SUBROUTINE AP_SETPARAM(size, packed, nwait_proc, nwait)
.n INTEGER size, packed, nwait_proc, nwait

Parameters:

+ size       -  preferred size in bytes for memory blocks (packages)
. packed     -  if nonzero, enable automatic packing
. nwait_proc -  max number of MPI sends per destination proc
- nwait      -  max number of MPI sends for all destinations.
                If nwait<0, use only per-destination limit.
                
Return Value:
None

Description:

'AUTOPACK' parameters may be changed at any time.  Changes to 'size' or
'packed' will affect subsequent messages but will not affect any
message already allocated.  Changes to 'nwait_proc' or 'nwait' will
govern subsequent MPI sends.  If the limit is reduced, no pending
sends are cancelled; the limit may not be attained until some sends
complete.

User advice: 

Size is a guideline; allocation will be made larger if necessary.
If it is too small, you will end up with one message
per package/memory block.  Setting it too large will waste memory and
reduce potential overlap of computation/communication.

@*/


extern void AP_setparam(int size, int packed, int nwait_proc, int nwait);




/*@

AP_realloc - Reallocate an outgoing message buffer

Parameters:

+ buf        - an outgoing buffer previously allocated by 'AP_alloc()'
- newsize    - the new desired size of the buffer


Description:

Still being tested.

Changes the size of the buffer pointed to by 'buf' to 'newsize' bytes
and returns a pointer to the (possibly moved) buffer. The contents
will be unchanged up to the lesser of the new and old sizes.

The buffer must be the most recently allocated buffer for the
destination, otherwise it is an error.  It is also erroneous to
specify a buffer which has previously passed to 'AP_send()'.  These
errors may or may not be detected depending on whether the library was
compiled with NO_USER_CHECKS.

If the buffer is reduced in size, it is guaranteed not to be moved.
If the buffer is increased in size, it may or may not move depending
on available space in the current internal memory block (package).


Return Value:
A pointer to the reallocated buffer.

@*/


extern void *AP_realloc(void *buf, int newsize);




/*@

AP_cancel - Cancel an outgoing message buffer

Parameters:

- buf        - an outgoing buffer previously allocated by 'AP_alloc()'

Description:

Still being tested.

Needs a Fortran interface.

Cancels a send buffer previously allocated by 'AP_alloc()' and
frees any internal buffer space.  After this call, 'buf' is invalid
and should not be used in any way.

The buffer must be the most recently allocated buffer for the
destination, otherwise it is an error.  It is also erroneous to
specify a buffer which has previously passed to 'AP_send()'.  These
errors may or may not be detected depending on whether the library was
compiled with NO_USER_CHECKS.

Return Value:
None

@*/


extern void AP_cancel(void *buf);




/*@

AP_alloc - Allocate an outgoing message buffer

Parameters:

+ destpid - the destination of the message
. tag     - the message''s tag
- size    - size of the message in bytes

Description:

Allocates a buffer for an outgoing message with the given destination,
tag, and size.  Returns a pointer to this buffer.  After the caller
has stored data in the buffer, 'AP_send()' is used to send it.

Return Value:
A pointer to the allocated buffer.


@*/


extern void *AP_alloc(int destpid, int tag, int size );




/*@

AP_send - send a message

Parameters:

. buf - a message buffer previously allocated via 'AP_alloc()'

Return Value:
None

Description:

Send a message previously allocated with AP_alloc().
After sending the message, the user may no longer
access 'buf'.

Parameter values 'packed', 'nwait', and 'nwait_proc' (see
'AP_setparam()') will affect when the send actually takes place.  If
packing is enabled, the message will not be sent until a full package
has been accumulated or the user calls AP_flush().  The send may be
also be deferred depending on the current number of sends posted to
MPI, and the value of 'nwait_proc' and 'nwait' (see 'AP_setparam()').

In order for the library to free memory associated with the sends, and
to process deferred messages, the user should call AP_check_sends()
periodically until the return value indicates no messages are
deferred.  Calls to AP_recv() will also expedite deferred messages.

Caveats:

At present, all messages are sent using type MPI_BYTE.

@*/


extern void AP_send(void *buf);




/*@
 
AP_flush - flush all pending sends

.n SUBROUTINE AP_FLUSH

Parameters:
. None - 

Return Value:
None

Description:
Flush all sends.  Any open packages are closed and sent.

'AP_send()' tells the library to send the message, but the underlying
MPI send is governed by the settings passed to 'AP_init()' or
'AP_setparam()'.

@*/


extern void AP_flush(void);




/*@

AP_check_sends - check status of underlying 'MPI' sends

.n SUBROUTINE AP_CHECK_SENDS(flags, return_value)
.n INTEGER flags, return_value
.n INCLUDE ''autopack.fh''

Parameters:
. flags - specify options (see below)

Description:

Check to see if 'MPI' has finished sending any messages, and free
their buffer space if they are done.  Also, if there are any
deferred messages, send as many as possible.

Flags may be a bitwise OR of the following
(in Fortran use addition)\:

.fin
'AP_NOFLAGS'
.fin
Do not block (default)
.fout

'AP_BLOCKING'
.fin
Block until at least one send completes
.fout

'AP_WAITDEFER'
.fin
Block until all deferred sends are posted to 'MPI'
(always returns <=0 )
.fout

'AP_WAITALL'
.fin
Block until 'MPI' completes all sends (always returns 0)
.fout
.fout

Caution must be used to avoid deadlock when using 'AP_BLOCKING'.
For example, if two processors call this after sending
each other messages, neither send is guaranteed to complete
before a receive is performed.


Return value:

0 if all sends have completed.

If there are deferred sends, returns how many.

If there are no deferred sends, returns -1 times the
number of incomplete 'MPI' send requests. 

(Note: packages are only counted as a single send.)


@*/


extern int AP_check_sends(int flags);




/*@

AP_check_sends_proc - check sends to a single destination

.n SUBROUTINE AP_CHECK_SENDS_PROC(pid, flags, return_value)
.n INTEGER pid, flags, return_value
.n INCLUDE ''autopack.fh''

Parameters:
+ pid   - destination rank to check
- flags - specifies options (see below)

Description:

Like 'AP_check_sends()', but only check sends to the given destination.
If there are deferred messages to the destination, send as many as possible.

Flags may be one of the following\:

.fin
'AP_NOFLAGS' 
.fin
Do not block (default)
.fout
     
'AP_BLOCKING' 
.fin
Block until the first MPI send request for the
specified proc is complete, then check remaining ones without
blocking.
.fout
.fout

Return Value:

Like 'AP_check_sends()' but value only reflects sends deferred/waiting
for the specified processor.  
.n I.e.

0 if all sends to the destination have completed.

If there are deferred sends to the destination, returns how many.

If there are no deferred sends to the destination, returns -1 times the
number of incomplete 'MPI' send requests. 

(Note: packages are only counted as a single send.)


@*/


extern int AP_check_sends_proc(int pid, int flags);




/*@

AP_recv - Receive a message

.n SUBROUTINE AP_RECV(sender, tag, flags, ret_msg, ret_size, ret_sender,
ret_tag, return_value)
.n INTEGER sender, tag, flags, ret_msg, ret_size, ret_sender, ret_tag,
return_value
.n INCLUDE ''autopack.fh''


Parameters:

+ sender     - specifies rank of the message source (may be 'MPI_ANY_SOURCE')
. tag        - specifies tag of the message (may be 'MPI_ANY_TAG')
. flags      - flags to specify options (see below)

. ret_msg    - the received message (or in Fortran, a descriptor)
. ret_size   - size of the received message
. ret_sender - sender of the received message
- ret_tag    - tag of the received message

Return Value:

Returns nonzero if a message has been successfully received, otherwise
returns 0.  If a message has been received, the arguments 'ret_msg',
'ret_size', 'ret_sender', and 'ret_tag' pass back information about
the message.

In the Fortran binding, it is not possible to return a pointer to the
message in 'ret_msg'.  Instead, a descriptor is returned that may be
passed to 'AP_COPY_FREE()' to retrieve the message.


Description:

Receive a message with given sender and tag ('MPI_ANY_SOURCE' and
'MPI_ANY_TAG' may be used).  If such a message is available, returns
nonzero and sets '*ret_msg', '*ret_size', '*ret_sender', and '*ret_tag'.
If no message matching the criteria is found, returns zero.

Any of 'ret_size', 'ret_sender', and 'ret_tag' may be passed NULL if
the caller is not interested in the return information.

After the caller has processed the information in ret_msg, 
the function 'AP_free()' must be called to free the buffer space.
Failure to do this will result in a memory leak.


Flags may be a bitwise OR of the following
(in Fortran, use addition)\:

.fin
'AP_NOFLAGS'
.fin
Default
.fout

'AP_BLOCKING'
.fin
Block until a matching message is received (by
default, do not block).  Will always return 1 unless 'AP_DROPOUT' is
specified.
.fout

'AP_DROPOUT' 
.fin
Used in conjunction with 'AP_BLOCKING'.  If some change
in status occurs (e.g. an asynchronous reduction message is received)
before a message is available, then unblock and return 0.
.fout

'AP_FIFO'
.fin
When searching for messages, only look at first incoming
message from each source.  Default action is to search all incoming
messages from a source (then continuing to the next source if
'MPI_ANY_SOURCE' was specified).
.fout
.fout

If there are deferred sends, the library will try to process them
before each attempt to receive a new message from MPI.  This is the
case whether the call to 'AP_recv()' is blocking or non-blocking,


Efficiency notes:

The library will be most efficient when messages are received in the
same order they arrive.  If all the messages have the same tag, this
is not a concern.  However, if the incoming messages have a variety of
tags, 'MPI_ANY_TAG' will always match the first one and is the most
efficient.  If a particular tag is specified, use 'AP_FIFO' if
the circumstances permit.

The library will be more efficient when a particular source is
specified rather than 'MPI_ANY_SOURCE'.  If 'MPI_ANY_SOURCE' is
specified, sources will be checked in round-robin fashion starting
with the rank from which the last message was received.  The search
is depth-first (although 'AP_FIFO' may truncate the search).

@*/


extern int AP_recv(int sender, int tag, int flags,
                   void **ret_msg, int *ret_size, int *ret_sender, int *ret_tag);




/*@

AP_free - free a message buffer

.n SUBROUTINE AP_FREE(buf)
.n INTEGER buf

Parameters:
. buf - the buffer to free (in Fortran, the descriptor)

Return Value:
None

Description:

Call this function to free message buffer space 
allocated by 'AP_recv()'.

Note that in the Fortran binding, it is not necessary to call this
after 'AP_COPY_FREE()' since that function frees that buffer before
returning.  However, this function may be of use in case the user
wants to free the message without actually accessing it.

@*/


extern void AP_free(void *buf);




/*@

AP_send_begin - Initiate a batch of sends

.n SUBROUTINE AP_SEND_BEGIN(return_value)
.n INTEGER return_value

Parameters:
None

Description:

Tells the library that the user code is about to begin a batch of
sends.  The library will then internally keep track of how many sends
go to each destination.  After doing the sends, call 'AP_recv_count()'
to initiate an asynchronous global reduction to determine how many
incoming message to expect.

It is an error to call 'AP_send_begin()' again before 'AP_recv_count()'
indicates the reduction is complete.

This routine will free space (via 'AP_check_sends()') from any
previous sends that are complete.

Return Value:

Returns the number of reductions since the library was initialized.
It can be used as a tag for the subsequent sends.  When the maximum
tag number has been reached, the count will wrap around to 0.

.N Reduce_Organization

@*/


extern int AP_send_begin(void);




/*@

AP_send_end - End a batch of sends, initiate asynchronous reduction

.n SUBROUTINE AP_SEND_END

Parameters:
None

Description:

This function denotes the end of a batch of sends.  (To start of a
batch of sends, see 'AP_send_begin()'.) 

After flushing the send buffers (see 'AP_flush()'), this function
initiates an asynchronous reduction to compute how many messages this
processor will receive from the batch of sends.  The result of this
reduction may be queried through 'AP_recv_count()'.

Caveats:

Messages to implement the asynchronous reduction are handled
transparently.  However, each processor is obligated to call AP_recv()
repeatedly until 'AP_recv_count()' has indicated the reduction is
complete.  Otherwise, the reduction will not complete on this
processor (and possibly others).

Messages that implement the asynchronous reduction are always sent
immediately and are never deferred.  This may use up to 2 MPI send
requests per processor which are not counted in the 'nwait' or
'nwait_proc' setting (see 'AP_setparam()').

Return Value:
None

.N Reduce_Organization

@*/


extern void AP_send_end(void);




/*@

AP_reduce_nsends - start reduction with explicit send count

Parameters:
int *nsends - array with count of sends to each destination

Description:

Still in testing.

Alternate interface to the asynchronous reduction.

Return Value:
None

.N Reduce_Organization

@*/

extern void AP_reduce_nsends(int *nsends);




/*@

AP_dsend_begin - denote the start of a batch of deterministic sends

.n SUBROUTINE AP_DSEND_BEGIN(return_value)
.n INTEGER return_value

Parameters:
None

Description:

Like 'AP_send_begin()', but denote the start of a
batch of sends that are guaranteed to arrive in deterministic order.
After the sends, call 'AP_dsend_end()'.  

Caveats: 

When this is called, there must be no outstanding messages (i.e. sent
but not received) in the system.

Messages sent within the bounds of 'AP_dsend_begin()'/'AP_dsend_end()'
will arrive in a deterministic order.

`Unlike` 'AP_send_begin()', `this call will cause a global synchronization.`

Memory requirements will be substantially higher than for
'AP_send_begin()', because no messages are passed on to the user until
all have arrived at this processor.

Return value:
Same as for 'AP_send_begin()'.

.N Reduce_Organization

@*/


extern int AP_dsend_begin(void);




/*@

AP_dsend_end -
End a batch of deterministic sends, initiate asynchronous reduction

.n SUBROUTINE AP_DSEND_END(return_value)
.n INTEGER return_value

Parameters:
None

Description:

Like 'AP_send_end()', but end a batch of messages
that are guaranteed to arrive in deterministic order.

`Unlike` 'AP_send_end()', `this call will cause a global synchronization.`

Return value:
None

.N Reduce_Organization

@*/


extern void AP_dsend_end(void);




/*M

AP_recv_count - query the result of an asynchronous reduction

Synopsis:
int AP_recv_count(int *count)

.n SUBROUTINE AP_RECV_COUNT(count, return_value)
.n INTEGER count, return_value

Parameters:
. count - result of the reduction

Description:

Queries the result of the pending asynchronous reduction to determine
how many messages from the prior batch of sends were sent to this
processor.

Return value:

If it returns zero, the asynchronous reduction is not yet complete.
The user code must call 'AP_recv()' with the expectation of receiving
more messages.  If desired, it is safe to block as long as the
'AP_DROPOUT' flag is specified (this flag makes 'AP_recv()' unblock and
return 0 if any reduction-related messages are seen).
'AP_recv_count()' can then be queried again.

If it returns nonzero, the asynchronous reduction is complete (at
least as far as this processor is concerned) and '*count' is set to
the number of messages whose destination is this processor.  `It is up
to the caller to compare this with the number received so far to
determine whether more messages are yet to arrive.`  After
'AP_recv_count()' returns nonzero, it is not necessary for this
processor to call 'AP_recv()' any longer.

.N Reduce_Organization

M*/

#define AP_recv_count(p)  \
        ( (AP_reduce_result<0) ? 0 : ( (*(p)=AP_reduce_result), 1) )





extern int AP_int_sum(int value);




extern double AP_double_sum(double value);




extern int AP_int_scan(int value);




extern float AP_float_scan(float value);




extern int AP_int_bcast(int value, int sender);




extern double AP_double_bcast(double value, int sender);




extern void AP_block_bcast(void *buf, int size, int sender);




extern double AP_double_min(double value);




extern double AP_double_max(double value);




/*@

AP_bsend - buffered send

.n SUBROUTINE AP_BSEND(buf, size, dest, tag)
.n <anytype> buf
.n INTEGER size, dest, tag

Parameters:
+ buf - the data to send
. size - size (in bytes) of data to send
. dest - destination rank
- tag - message tag

Description:

Allocates a send buffer, copies the data to this buffer,
and sends it.

Try to avoid using this function because it introduces
a potentially unnecessary memory-memory copy.

This function provided mainly for backwards compatibility,
and for use within the Fortran interface.

@*/

extern void AP_bsend(void *buf, int size, int dest, int tag);




extern void AP_breceive(void *buf, int size, int *from, int tag);




#include <mpi.h>


/*
 * Flags for function argments
 *
 */

#define AP_NOFLAGS     0x00
#define AP_BLOCKING    0x01
#define AP_FIFO        0x02
#define AP_DROPOUT     0x04
#define AP_WAITDEFER   0x08
#define AP_WAITALL     0x10

/*
 * Global variables
 *
 */

extern int AP_mypid;
extern int AP_rank;

extern int AP_nprocs;
extern int AP_size;

extern int AP_reduce_result;        /* private */



#ifdef __cplusplus
}
#endif  /* __cplusplus */ 

#endif  /* _AUTOPACK_H_ */  
