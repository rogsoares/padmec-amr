/*
 *  (C) 2000 UNIVERSITY OF CHICAGO
 *      See COPYRIGHT in top-level directory.
 */



#include "header.h"

/*
 * Convenience functions.
 *
 */


/*N Convenience

Notes:
This function duplicates 'MPI' functionality,
it is provided only for convenience.

N*/


/*

AP_int_sum - Sum an integer value from each processor

Parameters:
. value - the value on this processor to add up

Return value:
Sum 'value' from each processor, and return sum to all processors.

.N Convenience

*/

PUBLIC_PROTO
int AP_int_sum(int value)
{
  int recvbuf;

  SUCCESS( MPI_Allreduce(&value,&recvbuf,1,MPI_INT,MPI_SUM,MPI_COMM_WORLD) );

  return(recvbuf);
}




/*

AP_double_sum - Sum a double precision value from each processor

Parameters:
. value - the value on this processor to add up

Return value:
Sum a value from each processor, and return sum to all processors.

.N Convenience

*/

PUBLIC_PROTO
double AP_double_sum(double value)
{
  double recvbuf;

  SUCCESS( MPI_Allreduce(&value,&recvbuf,1,MPI_DOUBLE,MPI_SUM,MPI_COMM_WORLD) );

  return(recvbuf);
}





/*

AP_int_scan - Perform an "exclusive" integer scan

Parameters:
. value - input to the scan

Return value:

Perform "exclusive" scan of 'value' from each processor.

.vb
   processor       0    1    2      3        ...
   ---------------------------------------------
   value           v0   v1   v2     v3       ...
   return value    0    v0   v0+v1  v0+v1+v2 ...
.ve

.N Convenience

*/
 
PUBLIC_PROTO
int AP_int_scan(int value)
{
  int recvbuf;

  SUCCESS( MPI_Scan(&value,&recvbuf,1,MPI_INT,MPI_SUM,MPI_COMM_WORLD) );

  return(recvbuf-value);
}




/*

AP_float_scan - perform an "exclusive" scan of float values

Parameters:
. value - input to the scan

Return value:

Perform "exclusive" scan of 'value' from each processor.

.vb
   processor       0    1    2      3        ...
   ---------------------------------------------
   value           v0   v1   v2     v3       ...
   return value    0    v0   v0+v1  v0+v1+v2 ...
.ve


.N Convenience

*/
 

PUBLIC_PROTO
float AP_float_scan(float value)
{
  float recvbuf;

  SUCCESS( MPI_Scan(&value,&recvbuf,1,MPI_FLOAT,MPI_SUM,MPI_COMM_WORLD) );

  return(recvbuf-value);
}



/*

AP_int_bcast - broadcast an int from one proc to all

Parameters:
+ value  - value to broadcast
- sender - rank to send from

Description:

Broadcast from one proc to all ('value' is ignored on processors other
than the 'sender').  On all processors, returns the value from sender.

.N Convenience

*/


PUBLIC_PROTO
int AP_int_bcast(int value, int sender)
{
  SUCCESS( MPI_Bcast(&value,1,MPI_INT,sender,MPI_COMM_WORLD) );

  return(value);
}



/*

AP_double_bcast - broadcast a double from one proc to all

Parameters:
+ value  - value to broadcast
- sender - rank to send from

Description:

Broadcast from one proc to all ('value' is ignored on processors other
than the 'sender').  On all processors, returns the value from sender.

.N Convenience

*/


PUBLIC_PROTO
double AP_double_bcast(double value, int sender)
{
  SUCCESS( MPI_Bcast(&value,1,MPI_DOUBLE,sender,MPI_COMM_WORLD) );

  return(value);
}


/*

AP_block_bcast - broadcast a block of data

Parameters:
+ buf - pointer to the block of data
. size - data size in bytes
- sender - rank of the sender

Description:

Broadcast contents of 'buf' from one proc to all (contents of 'buf'
are filled in on processors other than 'sender').

Return value:
None

.N Convenience

*/


PUBLIC_PROTO
void AP_block_bcast(void *buf, int size, int sender)
{

  SUCCESS( MPI_Bcast(buf,size,MPI_BYTE,sender,MPI_COMM_WORLD) );

}



/*

AP_double_min - Find min value across procs and return it on all procs

Parameters:
. value - value to find min of

Return value:

Find min value across procs and return it on all procs.

.N Convenience

*/


PUBLIC_PROTO
double AP_double_min(double value)
{
  double recvbuf;

  SUCCESS(MPI_Allreduce(&value,&recvbuf,1,MPI_DOUBLE,MPI_MIN,MPI_COMM_WORLD));

  return(recvbuf);
}



/*

AP_double_max - Find max value across procs and return it on all procs

Parameters:
. value - value to find max of

Return value:

Find max value across procs and return it on all procs.

.N Convenience

*/


PUBLIC_PROTO
double AP_double_max(double value)
{
  double recvbuf;


  SUCCESS(MPI_Allreduce(&value,&recvbuf,1,MPI_DOUBLE,MPI_MAX,MPI_COMM_WORLD));

  return(recvbuf);
}




/*@

AP_bsend - buffered send

.n SUBROUTINE AP_BSEND(buf, size, dest, tag)
.n <anytype> buf
.n INTEGER size, dest, tag

Parameters:
+ buf - the data to send
. size - size (in bytes) of data to send
. dest - destination rank
- tag - message tag

Description:

Allocates a send buffer, copies the data to this buffer,
and sends it.

Try to avoid using this function because it introduces
a potentially unnecessary memory-memory copy.

This function provided mainly for backwards compatibility,
and for use within the Fortran interface.

@*/

void AP_bsend(void *buf, int size, int dest, int tag)
{
  void *temp;

  temp=AP_alloc(dest, tag, size);
  memcpy(temp,buf,size);
  AP_send(temp);
}



/*

AP_breceive - buffered receive (OBSOLETE)

Parameters:
+ buf -  pointer to a buffer to receive the message into
. size - expected message size (buffer must be at least this big)
. from - sender of the message
- tag -  desired tag 

Description:

Provided solely for backwards compatibility.

This function is superceded and use is not recommended.

*/


PUBLIC_PROTO
void AP_breceive(void *buf, int size, int *from, int tag)
{
  void *msg;
  int asize;
  int atag;

  while ( !AP_recv( MPI_ANY_SOURCE, tag, AP_BLOCKING,
		    &msg, &asize, from, &atag ) )
    ;

  if (asize!=size)
    {
      fprintf(stderr,"%d: AP_breceive: expected %d bytes but got %d bytes\n",
	      AP_mypid,size,asize);
      AP_mpi_abort();
    }

  memcpy(buf,msg,size);
  AP_free(msg);
}
