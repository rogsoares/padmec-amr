/*
 *  (C) 2000 UNIVERSITY OF CHICAGO
 *      See COPYRIGHT in top-level directory.
 */





/******************************************************  
 * WARNING: This file automatically generated.        *  
 *          Do not edit by hand.                      *  
 ******************************************************  
 */                                                      




extern int AP_search(int pid, int tag, int flags, Minfo *minfo);
extern int AP_search_first(int tag, Minfo *minfo);
extern int AP_search_dfs(int tag, Minfo *minfo);
extern int AP_search_proc(int pid, int tag, Minfo *minfo);
extern int AP_ppair_search(Ppair *start, int tag, Minfo *minfo);
extern int AP_match(Ppair *p, int tag, Minfo *minfo);
extern int AP_search_block(Bhead *BH, int tag, Minfo *minfo);
extern void AP_mark_received(Mhead *MH);
extern int AP_recv(int sender, int tag, int flags,
                   void **ret_msg, int *ret_size, int *ret_sender, int *ret_tag);
extern void AP_check_recvs(int flags);
extern int AP_recv_new(int sender, int tag, int flags, Minfo *minfo);
extern int AP_recv_probe(int *flags, Minfo *minfo);
extern void AP_recv_indiv(Minfo *minfo)                    /* minfo INPUT/OUTPUT */;
extern void AP_recv_block(Minfo *minfo)       /* minfo is INPUT only */;
extern void AP_free(void *buf);
