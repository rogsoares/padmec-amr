/*
 *  (C) 2000 UNIVERSITY OF CHICAGO
 *      See COPYRIGHT in top-level directory.
 */





/******************************************************  
 * WARNING: This file automatically generated.        *  
 *          Do not edit by hand.                      *  
 ******************************************************  
 */                                                      




extern int AP_check_sends(int flags);
extern int AP_check_sends_proc(int pid, int flags);
extern void AP_check_sends_nonblocking(void);
extern void AP_check_sends_proc_nonblocking(int pid);
extern int AP_check_sends_ppair(Ppair *p);
extern void AP_check_sends_blocking(void);
extern int AP_get_first_req(int pid, MPI_Request **sendreq);
