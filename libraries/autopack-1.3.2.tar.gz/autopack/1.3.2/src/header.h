/*
 *  (C) 2000 UNIVERSITY OF CHICAGO
 *      See COPYRIGHT in top-level directory.
 */



#ifndef __HEADER_H_
#define __HEADER_H_


#define PUBLIC_H_BEGIN
#define PUBLIC_H_END
#define PUBLIC_PROTO


#include <stdlib.h>
#include <stdio.h>
#include <string.h>

PUBLIC_H_BEGIN
#include <mpi.h>
PUBLIC_H_END

#include "listops.h"



/* 
 * Machine-specific memory alignment
 *
 * Addresses that are multiples of ALIGN must be
 * suitable for any type of variable.
 * 
 */


#define ALIGN  8


/* ALIGNED_SIZE(constant) will compile to a constant
 * (at least on sgi and sparc).
 */

#define ALIGNED_SIZE(n)  ( (n%ALIGN) ? (n+ALIGN-n%ALIGN) : n )

#define BHS  ( ALIGNED_SIZE( sizeof( Bhead )) )
#define MHS  ( ALIGNED_SIZE( sizeof( Mhead )) )



/*
 * constants for function arguments
 *
 */


#define AP_SENDBLOCK   0
#define AP_RECVBLOCK   1

#define AP_NEXTREQ     0
#define AP_NEXTINDIV   1


/*
 *  under MPI tags must at least be up to 32767 
 */

#define AP_MAX_TAG         32767

#define AP_REDUCE_TAG      (AP_MAX_TAG-1)
#define AP_BCAST_TAG       (AP_MAX_TAG-2)
#define AP_BLOCK_TAG       (AP_MAX_TAG-3)
#define AP_LIB_TAG         AP_BLOCK_TAG       /* Smallest tag used by lib */

/*
 * reductions
 *
 */

#define AP_UNKNOWN  (-1)



/***************************************************************************/

/*
 * Memory blocks
 */


/* States common to block headers and message headers */
#define STATE_NONE      0
#define STATE_SENT      3
#define STATE_WAIT      4


#define BSTATE_OPEN     1             /* new msg allocations can be made */
#define BSTATE_CLOSED   2             /* no new allocations can be made */
#define BSTATE_SENT     STATE_SENT    /* user sent; send by MPI ASAP */
#define BSTATE_WAIT     STATE_WAIT    /* waiting for block send */
#define BSTATE_DONE     5
#define BSTATE_DELETED  -99


typedef struct
{
#ifdef CHECKS
  int startflag;
  int id;
#endif
  
  pListitem listitem;

  int pid;                  /* source or dest of this block */
  int size;                 /* Size of memory block */
  int packed;               /* 0/1 indicates packed */
  int state;
  MPI_Request sendreq;      /* for packed sends */

  int nmsgs;                /* how many msgs allocated */
  int npending;             /* how many pending user action (send/free) */

  int tail;                 /* offset past last message in block */

#ifdef CHECKS
  int endflag;
#endif

} Bhead;


/***************************************************************************/


/*
 * Messages within memory blocks
 *
 */


#define MSTATE_EMPTY         10
#define MSTATE_SENT          STATE_SENT
#define MSTATE_WAIT          STATE_WAIT     /* not used if packed */
#define MSTATE_DONE          13             /* not used if packed */

#define MSTATE_UNSEEN        STATE_SENT
#define MSTATE_RECEIVED      14
#define MSTATE_FREED         15



typedef struct
{
#ifdef CHECKS
  int startflag;
  int id;
#endif  
  
  int bhead;                /* offset to block header */
  int next;                 /* offset to next message */
  int state;
  MPI_Request sendreq;      /* for non-packed sends */

  int tag;                  /* msg tag */
  int size;                 /* msg size */

#ifdef CHECKS
  int endflag;
#endif

} Mhead;



/***************************************************************************/


/*
 * Minfo
 *
 * This structure is used internally to pass around information
 * about received messages.
 *
 */

typedef struct
{
#ifdef CHECKS
  int startflag;
#endif  

  void *msg;
  int sender;
  int size;
  int tag;

  void *ptr;        /* Pointer to MH or BH */

#ifdef CHECKS
  int endflag;
#endif  

} Minfo;
  

/***************************************************************************/

/*
 * Ppair
 *
 * structure to hold a pointer pair (BH and MH).
 * (point to a message+block, or a just a block if MH is NULL.
 *
 */


typedef struct
{
  Bhead *BH;
  Mhead *MH;

} Ppair;



/***************************************************************************/


/*
 * Global variables
 */

#include "globals.h"


/***************************************************************************/

/*
 * Prototypes
 */


#include "alloc.h"
#include "checks.h"
#include "defer.h"
#include "list.h"
#include "msgmpi.h"
#include "recv.h"
#include "reduce.h"
#include "req.h"
#include "send.h"
#include "util.h"


/*
 * autopack.h is the only file available to the user
 * include it here to make sure it doesn't conflict.
 */

#include "autopack.h"


/*************************************************************************/
/*
 * Macros
 *
 */


#ifndef NO_MPI_CHECKS
#define SUCCESS(mpicmd)   { \
                             int sretval; \
                             if ( (sretval=(mpicmd)) != MPI_SUCCESS ) \
                             { \
                                fprintf(stderr,"MPI failure\n"); \
                                AP_mpi_abort_msg(sretval); \
                             } \
                          }
#else
#define SUCCESS(mpicmd)   (mpicmd);
#endif




/*
 * from block header to its first message header 
 */

#define bh_first_mh(bh)           ( (Mhead *) ( (char *)(bh) + BHS ) )


/*
 * from block header to message header at given offset
 */

#define bh_offset_mh(bh,offset)   ( (Mhead *) ( (char *)(bh) + (offset) ) )


/*
 * from message header to its block header
 */

#define mh_to_bh(mh)              ( (Bhead *) ( (char *)(mh) - (mh)->bhead ) )


/*
 * from message header to its message buffer
 */

#define mh_to_buf(mh)             ( (void *)  ( (char *)(mh) + MHS ) )


/*
 * from message buffer to its message header
 */

#define buf_to_mh(buf)            ( (Mhead *) ( (char *)(buf) - MHS ) )



/*
 * set the contents of a Ppair
 */

#define AP_ppair_set(p,bh,mh)  { (p)->BH=(bh); (p)->MH=(mh); }


/*
 * if the ppair is NULL, set it
 */

#define AP_ppair_update(p,bh,mh) { if(!(p)->BH) AP_ppair_set(p,bh,mh) }



/**************************************************************************/


#ifdef CHECKS

#define BLOCK_START_FLAG  12345678
#define BLOCK_END_FLAG    90123456

#define MSG_START_FLAG    24680246
#define MSG_END_FLAG      80246802


#define CHECK_DO(statement)            statement

#define CHECK_BLOCK(BH)                AP_check_block(BH)
#define CHECK_BLOCK_STATE(BH,STATE)    AP_check_block_state(BH,STATE)

#define CHECK_MSG(MH)                  AP_check_msg(MH)
#define CHECK_MSG_STATE(MH,STATE)      AP_check_msg_state(MH,STATE)

#define CHECK_NDEFER()                 AP_check_ndefer()
#define CHECK_NWAIT()                  AP_check_nwait()


#else   /* CHECKS */

#define CHECK_DO(statement)

#define CHECK_BLOCK(BH)
#define CHECK_BLOCK_STATE(BH,STATE)

#define CHECK_MSG(MH)
#define CHECK_MSG_STATE(MH,STATE)

#define CHECK_NDEFER()
#define CHECK_NWAIT()

#endif  /* CHECKS */

/***********************************************************/


#ifdef INFO_ALLOC

#define INFO_BLOCK(BH,str) AP_info_block(BH,str)
#define INFO_MSG(MH,str)   AP_info_msg(MH,str)

#else  /* INFO_ALLOC */

#define INFO_BLOCK(BH,str)
#define INFO_MSG(MH,str)

#endif  /* INFO_ALLOC */


/***********************************************************/


#ifdef INFO_DEFER

#define INFO_DEFER_PPAIR(BH,MH,s)   AP_info_ppair(BH,MH,s)
#define INFO_DEFER_STATS(s)         AP_info_defer_stats(s)

#else   /* INFO_DEFER */

#define INFO_DEFER_PPAIR(BH,MH,s)
#define INFO_DEFER_STATS(s)

#endif /* INFO_DEFER */


/***********************************************************/

/*
 * Some stuff that will end up in the user .h file
 */


PUBLIC_H_BEGIN


/*
 * Flags for function argments
 *
 */

#define AP_NOFLAGS     0x00
#define AP_BLOCKING    0x01
#define AP_FIFO        0x02
#define AP_DROPOUT     0x04
#define AP_WAITDEFER   0x08
#define AP_WAITALL     0x10

/*
 * Global variables
 *
 */

extern int AP_mypid;
extern int AP_rank;

extern int AP_nprocs;
extern int AP_size;

extern int AP_reduce_result;        /* private */

PUBLIC_H_END


#endif  /* __HEADER_H_ */
