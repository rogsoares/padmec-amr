/*
 *  (C) 2000 UNIVERSITY OF CHICAGO
 *      See COPYRIGHT in top-level directory.
 */



#include <unistd.h>
#include <stdio.h>
#include "autopack.h"

/*
 * C example program 2
 *
 * Each processor sends 3 messages and receives 3 messages
 * using nonblocking receive.
 *
 */

int main(int argc, char *argv[])
{
  int i;
  int *senddata;
  int *recdata;
  int sender;

  MPI_Init(&argc,&argv);
  AP_init(&argc,&argv);

  /*
   * set package size, enable packing, set maximum 10 sends at a time
   */

  AP_setparam(1024,1,10,10);    
  
  if (AP_size<3)
    {
      printf("Need at least 3 processors\n");
      return(1);
    }

  for (i=1; i<=3; i++)
    {
      senddata= (int *) AP_alloc( (AP_rank+i)%AP_size, 99, sizeof(int));
      *senddata= AP_rank*100+i;
      AP_send(senddata);
    }
      
  AP_flush();
  AP_check_sends(AP_WAITDEFER);

  for (i=0; i<3; i++)
    {
      /* if nonblocking receive fails, sleep and try again */

      while (! AP_recv(MPI_ANY_SOURCE, /*tag*/ 99, AP_NOFLAGS,
		       (void **)&recdata,NULL,&sender,NULL))
	sleep(1);

      printf("my rank: %d  sender %d  received data: %d\n",
	     AP_rank,sender,*recdata);
      
      AP_free(recdata);
    }

  AP_check_sends(AP_WAITALL);

  AP_finalize();
  MPI_Finalize();
  return(0);
}
