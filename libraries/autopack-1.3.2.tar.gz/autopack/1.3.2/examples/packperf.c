/*
 *  (C) 2000 UNIVERSITY OF CHICAGO
 *      See COPYRIGHT in top-level directory.
 */



#include <sys/time.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include "mpi.h"
#include "autopack.h"


/*
 * This test sends messages all-to-all in round-robin fashion.
 * No matter how many processors, each processor always sends
 * NMSGS.  Therefore, the more processors, the fewer sends to
 * a given destination.  Of course, all destinations receive
 * NMSGS total.
 *
 */

#define NMSGS   200000       /* number of messages sent by each processor */
#define MSGSIZE    100       /* size in bytes of messages */
int     MAXREQ_PROC =1;
#define MAXREQ       1       /* max reqs all procs */
#define NREPEAT      1       /* repeat test and average times */
#define PACKITER     6       /* number of times to double package size */
#define NONPACKED    0

int nmsgs;
struct timeval timer;



void timer_start(void)
{
  gettimeofday(&timer,NULL);
}



float timer_stop(void)
{
  struct timeval endtime;
  long sec, usec;
  float elapsed;

  gettimeofday(&endtime,NULL);

  sec = endtime.tv_sec  - timer.tv_sec;
  usec= endtime.tv_usec - timer.tv_usec;

  elapsed= (float) sec + (float) usec * 1e-6;

  return(elapsed);
}




float send_msgs(void)
{
  int i;
  float time;
  void *msg;
  int size, sender, tag;
  int count;


  MPI_Barrier(MPI_COMM_WORLD);
  timer_start();

  /*
   * Send a bunch of messages
   */

  for (i=0; i<nmsgs; i++)
    {
      msg=AP_alloc( i%AP_nprocs ,1,MSGSIZE);
      AP_send(msg);
    }

  AP_flush();

  /*
   * Loop to receive messages
   */

  count=0;
  while (count<nmsgs)
    {
      AP_recv(MPI_ANY_SOURCE,MPI_ANY_TAG, AP_BLOCKING,
		       &msg,&size,&sender,&tag);

      AP_free(msg);
      count++;
    }


  /*
   * This proc done with receives; make sure it pushes
   * out all remaining sends
   */

  while (AP_check_sends(AP_BLOCKING))
    ;

  /*
   * Done with the timed part
   */

  MPI_Barrier(MPI_COMM_WORLD);
  time=timer_stop();


  if (AP_check_sends(0))
    {
      fprintf(stderr,"there are pending sends!\n");
      abort();
    }

  if ( AP_recv(MPI_ANY_SOURCE,MPI_ANY_TAG,AP_NOFLAGS,
		&msg,&size,&sender,&tag) )
    {
      fprintf(stderr,"there are extra receives!\n");
      abort();
    }

  return(time);
}




float time_msgs(void)
{
  int i;
  float sum;

  sum=0;
  for (i=0; i<NREPEAT; i++)
    sum+=send_msgs();

  return(sum/NREPEAT);
}



int main(int argc, char **argv)
{
  int i;
  float time;
  int size;

  FILE *fp;
  char fname[128];
  FILE *fp2;
  char fname2[128];

  {
    char *s;

    if (s=getenv("MAXREQ_PROC"))
      sscanf(s,"%d",&MAXREQ_PROC);
  }

  MPI_Init(&argc,&argv);
  AP_init(&argc,&argv);
  AP_setparam(10240,0,MAXREQ_PROC,MAXREQ);

  nmsgs=NMSGS;
  if (nmsgs%AP_nprocs)
    nmsgs+=(AP_nprocs-NMSGS%AP_nprocs);

  if (argc>1)
    {
      printf("%d: Process %d\n",AP_mypid,getpid());
      /* sleep(10); */
    }

  if (AP_mypid==0)
    {
      printf("\n");
      printf("AP_nprocs= %d\n",AP_nprocs);
      printf("nmsgs= %d\n",nmsgs);
      printf("msgs/dest= %d\n",nmsgs/AP_nprocs);
      printf("MSGSIZE= %d\n",MSGSIZE);
      printf("MAXREQ_PROC= %d\n",MAXREQ_PROC);
      printf("MAXREQ= %d\n",MAXREQ);
      printf("NREPEAT= %d\n",NREPEAT);
      printf("\n");
      printf("\nStarting test\n\n");

      sprintf(fname,"packdata.%d.%d",AP_nprocs,MAXREQ_PROC);
      fp=fopen(fname,"w");
      sprintf(fname2,"procdata.%d.%d",AP_nprocs,MAXREQ_PROC);
      fp2=fopen(fname2,"w");
    }

  if (NONPACKED)
    {
      AP_setparam(10240,0,MAXREQ_PROC,MAXREQ);
      time=time_msgs();
      if (AP_mypid==0)
	{
	  printf("Non-packed:\n");
	  printf("                               %6.2f\n\n",time);
	  fprintf(fp2,"%2d  %6.2f",AP_nprocs,time);
	}
    }

  if (AP_mypid==0)
    printf("Packed:\n");


  size=512;
  for (i=0; i<PACKITER; i++)
    {
      AP_setparam(size,1,MAXREQ_PROC,MAXREQ);
      time=time_msgs();
      if (AP_mypid==0)
	{
	  float npackets;

	  npackets= (float)nmsgs/AP_nprocs/AP_count(size,MSGSIZE);
	  if (npackets!=(int)npackets)
	    npackets++;

	  printf("            %6d x %6d :  %6.2f\n",(int)npackets,size,time);

	  fprintf(fp,"%6d %6.2f\n",size,time);
	  fprintf(fp2,"  %6.2f",time);
	}
      size*=2;
    }

  if (AP_mypid==0)
    {
      printf("\n");
      fclose(fp);

      fprintf(fp2,"\n");
      fclose(fp2);
    }

  MPI_Finalize();
  return(0);
}

