/*
 *  (C) 2000 UNIVERSITY OF CHICAGO
 *      See COPYRIGHT in top-level directory.
 */



#include <unistd.h>

#if 0
#include "header.h"
#else
#include <stdio.h>
#include "mpi.h"
#include "autopack.h"
#define INFO_DEFER_STATS(s)
#endif



#define MAXTAG 32000
#define ENDTAG 32001


void fill(char *msg, int tag, int size)
{
  int i;
  int value;

  value=(tag*100)%256;
  
  for (i=0; i<size; i++)
    {
      msg[i]= (char)value;
      value=(value+1)%256;
    }
}


void check(char *msg, int tag, int size)
{
  int i;
  int value;

  value=(tag*100)%256;

  for (i=0; i<size; i++)
    {
      if (msg[i]!= (char)value)
	{
	  fprintf(stderr,"%d: Error in message tag %d at %d of %d bytes\n",
		  AP_mypid, tag, i, size);
	  fprintf(stderr,"    msg[%d]=%d  value=%d\n",i,msg[i],value);   
	  MPI_Abort(MPI_COMM_WORLD,0);
	}

      value=(value+1)%256;
    }
}



int main(int argc, char **argv)
{
  char *msg;
  int size;
  int sender;
  int tag;
  int i;
  int nrecvs;
  char *(recvs[100]);
  int npending, last_npending;
  int nreq;
  int done;
  int packmode=0;

  MPI_Init(&argc,&argv);
  AP_init(&argc, &argv);

#define PACKED 0

#if 0
  /* This test for allocation of message buffers */

  AP_setparam(200,PACKED,5,1024);

  if (AP_mypid==0)
    for (i=0; i<10; i++)
      AP_alloc(i%AP_nprocs,2,10);

#endif

#if 1

#define SWITCHMODE 1
#if SWITCHMODE
  AP_setparam(1024,packmode,1,10);
#else
  AP_setparam(1024,PACKED,1,10);
#endif

  if (argc>1)
    {
      printf("%d: Process %d\n",AP_mypid,getpid());
      sleep(5);
    }

  tag=100;

  /* AP_alloc(1,10,10); */  /* test for out-of-order */

  if (AP_mypid==0)
    {
      /* was 10 */
      for (i=0; i<200; i++)
	{
	  tag=(tag+1)%MAXTAG;
	  /* sgi: small is <64; med 65-16K; large >16K */
	  size=100;

	  msg=AP_alloc(i%(AP_nprocs-1)+1,tag,size);
	  fill(msg,tag,size);
	  AP_send(msg);

#if 0
	  nreq=AP_check_sends(AP_BLOCKING);
	  printf("&&&&& Pending sends %d\n",nreq);
#endif


#if SWITCHMODE
	  if (i%10==0)
	    {
	      packmode = !packmode;
	      AP_setparam(1024,packmode,10000,256);
	    }
#endif

	}

      /* Send a message indicating the end */
      size=1;
      for (i=1; i<AP_nprocs; i++)
	{
	  msg=AP_alloc(i,ENDTAG,size);
	  AP_send(msg);
	}

      printf("%d: Flushing sends\n",AP_mypid);
      AP_flush();

      INFO_DEFER_STATS("main: After sends");
    }

#if 0
  MPI_Barrier(AP_comm);         /* Note: uses two mpi requests */
#endif

#define SPIN 0
#define VERBOSE_BLOCKING 1
#define VERBOSE_RECV 0

#if SPIN
  last_npending= -1;

  while( npending=AP_check_sends(0) )
    if (npending==last_npending)
      printf("Spinning\n");
    else
      {
	last_npending=npending;
	printf("%d: Have %d pending sends, spinning\n",AP_mypid,npending);
      }

#else  /* SPIN */

#if 0
  if (AP_check_sends(0))
#else
  if (1)
#endif
    {
      printf("%d: main: blocking on sends\n",AP_mypid);

      while( (npending=AP_check_sends(AP_BLOCKING)) )
	{
	  printf("%d: **** Done blocking on sends, npending  %d\n",
		 AP_mypid,npending);
#if VERBOSE_BLOCKING
	  INFO_DEFER_STATS("blocking on sends");
#else
	  ;
#endif
	}

      printf("%d: main: done blocking on sends\n",AP_mypid);
    }

#endif  /* SPIN */

  printf("%d: ---------------------------------\n",AP_mypid);


  nrecvs=0;

  if (AP_mypid>0)
    done=0;
  else
    done=1;

  while (!done)
    {
      AP_recv(MPI_ANY_SOURCE, MPI_ANY_TAG, AP_BLOCKING,
	       (void **) &msg, &size, &sender, &tag);

      if (tag== ENDTAG)
	done=1;
      else
	check(msg,tag,size);
      

#if VERBOSE_RECV
      printf("%d: Received msg from %d tag %d size %d\n",
	     AP_mypid, sender, tag, size);
#endif


#define FREEGROUP 0

#if FREEGROUP
      recvs[nrecvs]=msg;
#else
      AP_free(msg);
#endif
      nrecvs++;
    }

  printf("%d: Total receives %d\n",AP_mypid,nrecvs);

#if FREEGROUP
  printf("%d: Freeing receives\n",AP_mypid);

  for (i=0; i<nrecvs; i++)
    AP_free(recvs[i]);
#endif

#endif

#if 0
  info_defer_stats("Final");
#else
  INFO_DEFER_STATS("Final");
#endif

  MPI_Barrier(MPI_COMM_WORLD);
  MPI_Finalize();
  printf("%d: Done\n",AP_mypid);
  
  return(0);
}

