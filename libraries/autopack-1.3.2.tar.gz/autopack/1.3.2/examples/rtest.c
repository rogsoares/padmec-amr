/*
 *  (C) 2000 UNIVERSITY OF CHICAGO
 *      See COPYRIGHT in top-level directory.
 */




#include <unistd.h>
#include <stdio.h>
#include "mpi.h"
#include "autopack.h"


#define MAXTAG 32000
#define ENDTAG 32001



#define PACKED 0
#define ONEBYONE 1
#define VERBOSE_RECV 1
#define DETERMINISTIC 0



#if DETERMINISTIC
#define SEND_BEGIN()  AP_dsend_begin()
#define SEND_END()    AP_dsend_end()
#else
#define SEND_BEGIN()  AP_send_begin()
#define SEND_END()    AP_send_end()
#endif


#if 0
#define RFLAGS   (0)
#else
#define RFLAGS   (AP_BLOCKING | AP_FIFO | AP_DROPOUT)
#endif


void test1(void)
{
  int dest;
  int expected;
  int i;
  int nrecvs;

  int *msg;
  int size;
  int sender;
  int tag;

  tag=SEND_BEGIN();

  for (i=0; i<9; i++)
    {
      dest=(AP_mypid+i%3+1)%AP_nprocs;
      msg=AP_alloc(dest,tag,sizeof(int));
      *msg=AP_mypid*10+i;
      AP_send(msg);
    }

  SEND_END();

  i=0;
  while( !AP_recv_count(&nrecvs) || i<nrecvs )
    {
      if ( AP_recv(MPI_ANY_SOURCE, tag, RFLAGS,
		     (void **) &msg, &size, &sender, &tag) )
	{
#if VERBOSE_RECV
	  if (AP_mypid==0)
	    printf("%d: Received msg from %d tag %d size %d contents %d\n",
		   AP_mypid, sender, tag, size, *msg);
#endif
	  AP_free(msg);
	  i++;
	}
    }
  printf("%d: Round 1 Total receives %d\n",AP_mypid,nrecvs);
  expected= 9;

  if (nrecvs!= expected)
    {
      printf("%d: **************** ERROR expected %d receives\n",
	     AP_mypid,expected);
      MPI_Abort(MPI_COMM_WORLD,0);
    }

  AP_check_sends(AP_WAITDEFER);
}




void test2(void)
{
  int i,j;
  int expected;
  int nrecvs;

  void *msg;
  int size;
  int sender;
  int tag;

  tag=SEND_BEGIN();

  for (i=0; i<AP_nprocs; i++)
    for (j=0; j<(AP_nprocs-i); j++)
      {
	msg=AP_alloc(i,tag,10);
	AP_send(msg);
      }

  SEND_END();

  i=0;
  while( !AP_recv_count(&nrecvs) || i<nrecvs )
    {
#if 0
      if (AP_mypid==5 && i%2)
	sleep(1);
#endif

      if ( AP_recv(MPI_ANY_SOURCE, tag, RFLAGS,
		     (void **) &msg, &size, &sender, &tag) )
	{
	  AP_free(msg);
	  i++;
	}
    }
  printf("%d: Round 2 Total receives %d\n",AP_mypid,nrecvs);
  expected= AP_nprocs*(AP_nprocs-AP_mypid);

  if (nrecvs!=expected)
    {
      printf("%d: **************** ERROR expected %d receives\n",
	     AP_mypid,expected);
      MPI_Abort(MPI_COMM_WORLD,0);
    }


  AP_check_sends(AP_WAITDEFER);
}




void test3(void)
{
  int expected;
  int i;
  int nrecvs;

  void *msg;
  int size;
  int sender;
  int tag;

  tag=SEND_BEGIN();

  if (AP_mypid%2==0)
    for (i=0; i<100; i++)
      {
	msg=AP_alloc( (AP_mypid-1+AP_nprocs)%AP_nprocs ,tag,10);
	/* Fill in message */
	AP_send(msg);
      }

  SEND_END();

  i=0;
  while( !AP_recv_count(&nrecvs) || i<nrecvs )
    {
      if ( AP_recv(MPI_ANY_SOURCE, tag, RFLAGS,
		     (void **) &msg, &size, &sender, &tag) )
	{
	  /* Handle message contents here */
	  AP_free(msg);
	  i++;
	}
    }
  printf("%d: Round 3 Total receives %d\n",AP_mypid,nrecvs);
  if (AP_nprocs>1)
    expected= (AP_mypid%2==0)?0:100;
  else
    expected=100;

  if (nrecvs!= expected)
    {
      printf("%d: **************** ERROR expected %d receives\n",
	     AP_mypid,expected);
      MPI_Abort(MPI_COMM_WORLD,0);
    }


  AP_check_sends(AP_WAITDEFER); 
}



int main(int argc, char **argv)
{
  int packmode;

  MPI_Init(&argc,&argv);
  AP_init(&argc,&argv);

  packmode=PACKED;


#if ONEBYONE
  AP_setparam(2048,packmode,1,1);
#else
  AP_setparam(1024,packmode,1000,1000);
#endif



  if (argc>1)
    {
      int sec;

      printf("%d: Process %d\n",AP_mypid,getpid());
      sscanf(argv[1],"%d",&sec);
      sleep(sec);
    }


  test1();
  test2();
  test3();

#if 0
  MPI_Barrier(MPI_COMM_WORLD);
  sleep(1);
  printf("%d: nmatch=%4d rn=%4d  %.2f\n",
	 AP_mypid,AP_nmatch,AP_nr,(float)AP_nmatch/AP_nr);
#endif

  /* info_defer_stats("Final");  */

  MPI_Finalize();

  return(0);
}


