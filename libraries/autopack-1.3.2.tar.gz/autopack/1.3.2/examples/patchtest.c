/*
 *  (C) 2000 UNIVERSITY OF CHICAGO
 *      See COPYRIGHT in top-level directory.
 */



#include <stdio.h>
#include "autopack.h"

/*
 * C example program 1
 *
 * Processor 0 sends an array to the other processors and they
 * print the array contents.
 *
 */

int main(int argc, char *argv[])
{
  int j;
  int *senddata;
  int *recdata;
  int size,sender,tag;

  MPI_Init(&argc,&argv);
  AP_init(&argc,&argv);

  AP_setparam(300,1,100,100);

  if (AP_rank==0)
    {
      for (j=0; j<10; j++)
	{
	  /* AP_alloc( destination, tag, size (in bytes) */

	  senddata= (int *) AP_alloc(1, j, sizeof(int));

	  *senddata= 100;

	  AP_send(senddata);
	}
      
      AP_flush();
      AP_check_sends(AP_WAITALL);
    }
  else
    {
      for (j=5; j>=0; j-=1)
	{
	  AP_recv(MPI_ANY_SOURCE,j,AP_BLOCKING,
		  (void **)&recdata,&size,&sender,&tag);
	  
	  printf("my rank: %d  sender %d  tag %d received: %d\n",
		 AP_rank,sender,tag,*recdata);

	  AP_free(recdata);
	}

      for (j=9; j>5; j-=1)
	{
	  AP_recv(MPI_ANY_SOURCE,j,AP_BLOCKING,
		  (void **)&recdata,&size,&sender,&tag);
	  
	  printf("my rank: %d  sender %d tag %d  received: %d\n",
		 AP_rank,sender,tag,*recdata);

	  AP_free(recdata);
	}
    }

  AP_finalize();
  MPI_Finalize();
  return(0);
}
