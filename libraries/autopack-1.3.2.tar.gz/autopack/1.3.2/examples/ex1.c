/*
 *  (C) 2000 UNIVERSITY OF CHICAGO
 *      See COPYRIGHT in top-level directory.
 */



#include <stdio.h>
#include "autopack.h"

/*
 * C example program 1
 *
 * Processor 0 sends an array to the other processors and they
 * print the array contents.
 *
 */

int main(int argc, char *argv[])
{
  int i,j;
  int *senddata;
  int *recdata;
  int size,sender,tag;

  MPI_Init(&argc,&argv);
  AP_init(&argc,&argv);

  if (AP_rank==0)
    {
      for (j=1; j<AP_size; j++)
	{
	  /* AP_alloc( destination, tag, size (in bytes) */

	  senddata= (int *) AP_alloc(j, 55, sizeof(int)*4);

	  for (i=1; i<=4; i++)
	    senddata[i]= j*100+i;

	  AP_send(senddata);
	}
      
      AP_flush();
      AP_check_sends(AP_WAITALL);
    }
  else
    {
      AP_recv(MPI_ANY_SOURCE,MPI_ANY_TAG,AP_BLOCKING,
	      (void **)&recdata,&size,&sender,&tag);

      printf("my rank: %d  sender %d  received: %d  %d  %d  %d\n",
	     AP_rank,sender,recdata[0],recdata[1],recdata[2],recdata[3]);

      AP_free(recdata);
    }

  AP_finalize();
  MPI_Finalize();
  return(0);
}
