/******************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*********************************************************************************/

/*<i> ****************************************************************************
 *
 *  AOMD/include/pmMigrateUtil.h
 *  Created by Seegyoung Seol, on Mon Dec 08 2003, 10:26:37 EDT
 *
 *  File Content: mesh migration utility functions
 *
 *************************************************************************** </i>*/
#ifdef PARALLEL

#ifndef PM_MIGRATE_UTIL_H
#define PM_MIGRATE_UTIL_H

#include <list>
#include <vector>
#include <map>
#include <set>
#include "mMesh.h"
#include "mEntity.h"
#include "pmUtility.h"
#include "pmDataExchanger.h"
#include "pmMigrationCallbacks.h"

namespace AOMD {

// **********************************************
//     structure used for communication
// **********************************************
 
const int TAGVERTEX = 2222;
const int TAGNONVERTEX = 2223;

struct packedVertex
{
  mEntity* sender;
  int iD;
  int gTag;
  int gType;
  double coord[3];
  int numRC;
  int numBP;
  int numParam;
};

struct packedNonVertex
{
  mEntity* sender;
  int type;
  int gTag;
  int gType;
  int numRC;
  int numBP;
};

void set_subtract(std::set<int> A, std::set<int> B, std::set<int>& C);
void exchangeEntitiesToBounce(std::vector<rc_struct_2>&);
void* packMVertex(mEntity*, int, pmMigrationCallbacks &cb);

void pmLoadBalance(mMesh* mesh, pmMigrationCallbacks &cb);

int pmMerge(mMesh* mesh, pmMigrationCallbacks &cb);

int pmMeshMigration(mMesh* mesh,
                    int dimToMove,std::list<mEntity*>& entities,
                    pmMigrationCallbacks &cb,
                    std::vector<mEntity*>* rmE,
                    std::vector<mEntity*>* newE);

int pmMeshMigration(mMesh* mesh, pmMigrationCallbacks &cb,
 		    std::list<mEntity*>& vtsOnCB, 
		    std::list<std::pair<mEntity*,mEntity*> > &vtfcPairs,
                    std::vector<mEntity*>* rmE,
                    std::vector<mEntity*>* newE);
		    
int migrateMeshEntities(mMesh* mesh, 
                        std::map<mEntity*,int>& POtoMove,
		        pmMigrationCallbacks& cb);
int migrateMeshEntities(mMesh*mesh, 
                        std::map<mEntity*,int>& POtoMove,
		        pmMigrationCallbacks& cb,
                        std::vector<mEntity*>* rmE,
                        std::vector<mEntity*>* newE);

struct rc_struct
{
  int from;
  mEntity* fromE;
  mEntity* toE;
  rc_struct(int i,mEntity* e1, mEntity* e2):from(i),fromE(e1),toE(e2) {}
};
 
class bpsExchanger : public pmDataExchanger
{
public :
  virtual int tag() const;
  virtual void * AP_alloc_and_fill_buffer (mEntity *e, int pid, mEntity* rc, int);
  virtual void receiveData (int pid, void *buf);
};

class bpsReseter : public pmDataExchanger
{
public :
  virtual int tag() const;
  virtual void * AP_alloc_and_fill_buffer (mEntity *e, int pid, mEntity* rc, int);
  virtual void receiveData (int pid, void *buf);
};

class remoteCopyRemover : public pmDataExchanger
{
public :
  virtual int tag() const;
  virtual void * AP_alloc_and_fill_buffer (mEntity *e, int pid, mEntity* rc, int);
  virtual void receiveData (int pid, void *buf);
};

// migration helper functions
void getFamily(mEntity* ent, std::set<mEntity*>& family);
void printFamily(mEntity* ent);

void getEntitiesToHandle(std::map<mEntity*,int>& entitiesToMove,
        std::set<mEntity*>* entitiesToHandle);
void setBPs(int, std::map<mEntity*,int>& POToMove, std::set<mEntity*>* entitiesToHandle);
void exchangeBPs(std::set<mEntity*>* entitiesToHandle);
void updatePC_and_collectEntitiesToRemove(std::set<mEntity*>* entitiesToHandle, 
					std::set<mEntity*>* entitiesToRemove);
void removeUnusedEntities(mMesh*, int, std::set<mEntity*>*);


void exchangeEntities(mMesh*, int, pmMigrationCallbacks &cb,
                     int, std::set<mEntity*>&, std::vector<mEntity*>*);

void unifyEntitiesToMove(mMesh* mesh, std::list<mEntity*>& entities);
typedef std::map<mEntity*, int> entityPidMap;

void getPOsToMoveFromPartitionVector(mMesh *mesh, int from,
                		int *partitionVector, int delta_id, 
				std::map<mEntity*, int>& entitiesToMove);
void getPOsToMove(mMesh* mesh, 
			std::list<mEntity*>& entities,int ent_dim,
			std::map<mEntity*,int>& entitiesToMove);
// getEntitiesToMove for snapping		
void getEntitiesToMove(mMesh*,std::list<mEntity*>& vtsOnCB, 
		      std::list<std::pair<mEntity*,mEntity*> > &vtfcPairs,
		      std::map<mEntity*,int>& entitiesToMove);			
// new one
void getPOsToMoveForSnap(mMesh* mesh, std::list<mEntity*>& vtsOnCB, 
		      std::list<std::pair<mEntity*,mEntity*> > &vtfcPairs,
		      std::map<mEntity*,int>& entitiesToMove);
		      
// ghost entity copy related
// - implemented in pmMigrateGhost.cc

int migrateGhostEntities(mMesh* mesh, pmMigrationCallbacks &cb);

int expandGhostEntities(mMesh* mesh, pmMigrationCallbacks &cb, 
			std::vector<mEntity*>& vtsToExpand, int dimToExpand);

void removeGhostEntities(mMesh* mesh);

}  // end of AOMD

#endif
#endif /* PARALLEL */
