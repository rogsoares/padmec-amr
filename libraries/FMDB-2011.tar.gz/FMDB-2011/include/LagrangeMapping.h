/* 
   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of Trellis written and maintained by the 
   Scientific Computation Research Center (SCOREC) at Rensselaer Polytechnic
   Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA
*/

#ifndef H_LagrangeMapping
#define H_LagrangeMapping

#include "Mapping.h"
#ifdef AOMD
#include "AOMD_Internals.h"
#endif

//typedef double (* LevelSetFunction)(Trellis_Util::mPoint &);

namespace Trellis_Util {

  class LagrangeMapping : public Mapping
    { 
      std::vector<mPoint> knots;
    public:
      TRELLIS_MTYPE elementType;
      virtual ~LagrangeMapping(){};
      LagrangeMapping(pEntity me);
      LagrangeMapping(pEntity me, LevelSetFunction _levelSetFunc, int condition);
      LagrangeMapping(pEntity me, std::vector<mPoint> *input_knots);
      inline std::vector<mPoint> * getKnots(){return &knots;}
      virtual void normalVector (pEntity border , 
				 double u, double v, double w, 
				 mVector &n) const;
      virtual void eval(double u, double v, double w,
			double &x, double &y, double &z) const;
      
      virtual void deval(double u, double v, double w,
			 double &dxdu, double &dydu, double &dzdu,
			 double &dxdv, double &dydv, double &dzdv,
			 double &dxdw, double &dydw, double &dzdw) const;
      virtual void boundingBox (  mPoint &min, mPoint &max ) const;
      int geomOrder() const;
      int order() const;
    protected:
      void   GeomShapeFunction          (double u, double v, double w, double * ) const;
      void   GradGeomShapeFunction      (double u, double v ,double w , mVector*) const;
    };

  class ConstantLagrangeMapping : public LagrangeMapping
    {
      double det;
      mTensor2 jac;
    public:
      virtual ~ConstantLagrangeMapping(){}
      ConstantLagrangeMapping(pEntity me);
      virtual double jacInverse(double x, double y, double z, 
				mTensor2&) const;
      virtual double detJac(double u, double v, double w) const;
    };

  class CylindricalCoordinatesLagrangeMapping : public LagrangeMapping
    {
    public:
      virtual ~CylindricalCoordinatesLagrangeMapping(){}
      CylindricalCoordinatesLagrangeMapping(pEntity me);
      virtual double jacInverse(double x, double y, double z, 
				mTensor2&) const;
      virtual double detJac(double u, double v, double w) const;
      virtual int order() const;
    };
  
  class RegularCubeLagrangeMapping : public LagrangeMapping
    {
      double x0,y0,z0;
      double dx,dy,dz;
    public:
      virtual ~RegularCubeLagrangeMapping(){}
      RegularCubeLagrangeMapping(pEntity me);
      virtual void normalVector (pEntity border , 
				 double u, double v, double w, 
				 mVector &n) const;
      virtual void eval(double u, double v, double w,
			double &x, double &y, double &z) const;
      
      virtual void deval(double u, double v, double w,
			 double &dxdu, double &dydu, double &dzdu,
			 double &dxdv, double &dydv, double &dzdv,
			 double &dxdw, double &dydw, double &dzdw) const;
      virtual bool invert(double x, double y, double z,
			  double &u, double &v, double &w) const;
      virtual double jacInverse(double x, double y, double z, 
				mTensor2&) const;
      virtual double detJac(double u, double v, double w) const;
      virtual double PushBack (double u, double v, double w, int vsize, std::vector<mVector> &vec) const;
    protected:
    };
} //end of namespace

#endif
