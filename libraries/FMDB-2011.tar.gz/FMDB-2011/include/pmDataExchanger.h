/**************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*****************************************************************************/

/*<i> ****************************************************************************
 *
 *  AOMD/include/pmDataExchanger.h
 *  Created by Seegyoung Seol, on Mon Dec 08 2003, 10:26:37 EDT
 *
 *  File Content: generic data exchanger class
 *
 *************************************************************************** </i>*/
#ifdef PARALLEL

#ifndef _PM_DATA_EXCHANGER_H_
#define _PM_DATA_EXCHANGER_H_

#include "mMesh.h"
#include "ParUtil.h"
#include "autopack.h"

namespace AOMD {

class mEntity;

class pmDataExchanger
{
  public :
  /// get a tag
  virtual int tag() const = 0;
    /// user sends a message related to mesh entity *e to proc si.pid() to the counterpart si.getRemotePointer().
  virtual void * AP_alloc_and_fill_buffer (mEntity *e,int pid, mEntity*, int tag) = 0;
    /// user recieve data *buf form proc pid.
  virtual void receiveData (int pid, void *buf) = 0; 
};

template <class Iterator>
void genericDataExchanger(const Iterator &beg, const Iterator &end ,
                         pmDataExchanger& de)
{
  mEntity* ent;
  int *sendcounts = new int[ParUtil::Instance()->size()];
  for(int i=0;i<ParUtil::Instance()->size();i++)sendcounts[i]=0;
  for( Iterator it=beg; it != end ; ++it)
  {
    ent = *it;
    if (ent->getNumRemoteCopies()==0)
      continue;
    for (mEntity::RCIter rcIter=ent->rcBegin(); rcIter!=ent->rcEnd();++rcIter)
    {
      void *buf = de.AP_alloc_and_fill_buffer (ent, (*rcIter).first, (*rcIter).second, de.tag());
      if (buf)
      {
        AP_send(buf);
        sendcounts[(*rcIter).first]++;
      }
    }
  }
 
  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts);
  int message=0;
  int count;
 
  while (!AP_recv_count(&count) || message<count)
  {
    void *msg;
    int from, tag, size, rc;
    rc=AP_recv(MPI_ANY_SOURCE, de.tag(), AP_BLOCKING|AP_DROPOUT,
                   &msg, &size, &from, &tag);
    if (rc)
    {
      message++;
      de.receiveData (from, msg);
      AP_free(msg);
    }
  }
  AP_check_sends(AP_WAITALL);
}

} // end of namespace 

#endif
#endif
