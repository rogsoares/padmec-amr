/**************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*****************************************************************************/
#ifndef _RANS_MESH_H_
#define _RANS_MESH_H_
#ifdef __cplusplus
extern "C" {
#endif
/// These are the functions that are required for
/// the RANS finite volume solver. It is based on
/// an unstructured hex-type discretization  

///------------------------------------------------
/// Loading the mesh : the function builds up
/// a complete set of adjacencies (bidirectional
/// representation).
void loadmesh_ ( char * filename) ;

///------------------------------------------------
/// Computes the number of nodes
void numnod_ ( int *NumNodes ) ;

///------------------------------------------------
/// Computes the number of nodes
void xyznod_ ( int *iNode , double *X ) ;

///------------------------------------------------
/// Computes the number of edges
void numedg_ ( int *NumEdges ) ;

///------------------------------------------------
/// Computes the nodes of an edge
void nodedg_ ( int *iEdge, int Nodes[2] ) ;

///------------------------------------------------
/// Computes the number of faces
void numfac_ ( int *NumFaces ) ;

///------------------------------------------------
/// Computes the nodes of a face
void nodfac_ ( int *iFace, int Nodes[4] ) ;

///------------------------------------------------
/// Computes the number of hexaedron
void numhex_ ( int *NumHexes ) ;

///------------------------------------------------
/// Computes the edges of an hex
void edghex_ ( int *iHex, int Edges[12] ) ;

///------------------------------------------------
/// Computes the nodes of an hex
void nodhex_ ( int *iHex, int Nodes[8] ) ;

///------------------------------------------------
/// Computes the edges of an hex
void fachex_ ( int *iHex, int Faces[6] ) ;

///------------------------------------------------
/// Computes the edges of a face
void edgfac_ ( int *iFace, int Edges[4] ) ;

///------------------------------------------------
/// Computes the neighbors of a face
/// Only available in 2D !!!!!!!!!!!!!!!!!
void facfac_ ( int *iFace, int Faces[4] ) ;

///------------------------------------------------
/// Computes the neighbors of n hex
void hexhex_ ( int *iHex, int Hexes[8] ) ;

///------------------------------------------------
/// Computes the faces neighboring an edge 
/// Only available in 2D !!!!!!!!!!!!!!!!!
void facedg_ ( int *iEdge, int Faces[2] ) ;

///------------------------------------------------
/// Computes the hexes neighboring a face
void hexfac_ ( int *iFace, int Hexes[2] ) ;

///------------------------------------------------
/// Computes the edges neighboring a node
void nedgnod_ ( int *iNode, int *numEdges ) ;
void edgnod_    ( int *iNode, int *Edges    ) ;

///------------------------------------------------
/// Computes the faces neighboring a node
void nfacnod_ ( int *iNode, int *numFaces ) ;
void facnod_    ( int *iNode, int *Faces    ) ;

///------------------------------------------------
/// Computes the hexes neighboring a node
void nhexndod_ ( int *iNode, int *numHexes ) ;
void hexnod_    ( int *iNode, int *Hexes    ) ;

///------------------------------------------------
/// Computes the normal to a face iFace that points 
/// OUT of the hex iHex
void nvect3d_ ( int *iFace, int *iHex, double *n);

///------------------------------------------------
/// Computes the normal to an edge iEdge that points 
/// OUT of the face iFace (ONLY AVAILABLE IN 2D)
void nvect2d_ ( int *iEdge, int *iFace, double *n);

///------------------------------------------------
/// Compute the (positive) volume of an hex 
void volume_ ( int *iHex, double *v);

///------------------------------------------------
/// Compute the (positive) surface of a face 
void surfac_ ( int *iFace, double *s);

///------------------------------------------------
/// Computes the zone of a face (for boundary 
/// conditions)
void zonfac_ ( int *iFace , int *iZone );

///------------------------------------------------
/// Computes the zone of an edge
void zonedg_ ( int *iEdge , int *iZone );
  
///------------------------------------------------
/// Computes the zone of an edge
void zonenod_ ( int *iNod , int *iZone );
  
///------------------------------------------------
/// Computes the opposite face to a given face
/// of an hex
void opface_ (int *iHex, int *iFace1, int *iFace2);

///------------------------------------------------
/// Computes the opposite edge to a given edge
/// of a face
void opedge_ (int *iFace, int *iEdge1, int *iEdge2);

///------------------------------------------------
/// Computes the other hex neighboring a given face
void otherhex_(int *iHex, int *iFace1, int *iHex2);

///------------------------------------------------
/// Computes the center of gravity of an hex
void coghex_(int *iHex, double *p);

///------------------------------------------------
/// Computes the center of gravity of a face
void cogfac_(int *iHex, double *p);

///------------------------------------------------
/// Computes the common face of 2 hexes
void hexfachex_(int *iHex1, int *iHex2, int *iFace);


#ifdef __cplusplus
}
#endif
#endif

