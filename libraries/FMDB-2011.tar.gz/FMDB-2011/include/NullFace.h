/* 
   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of Trellis written and maintained by the 
   Scientific Computation Research Center (SCOREC) at Rensselaer Polytechnic
   Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA
*/
#ifndef H_NullFace
#define H_NullFace

 /***************************************************************
 * $Id: NullFace.h,v 1.10 2005/02/02 00:08:56 acbauer Exp $
 * Description: 

*/
//#include "SList.h"
#include "GFace.h"
#include "NullEntity.h"

template<class T> class SSList;
class NullEdge;
class NullRegion;
class GRegion;
class GEPoint;

/** A "fake" model face. 
 */
class NullFace : public GFace, public NullEntity {
public:
  NullFace(NullModel *m, int tag, const SSList<GEdge*> &edges, const SSList<int> &dirs);
  NullFace(NullModel *m, int tag);
  virtual ~NullFace();

  virtual RepType::Value repType(void) const;

  virtual GeoRep * geometry();

  //Geometric Ops
  Range<double> parBounds(int i) const;
  virtual int paramDegeneracies(int dir, double *par);
  virtual SBoundingBox3d bounds() const;
  virtual GFPoint point(double par1, double par2) const;
  virtual GFPoint point(const SPoint2 &pt) const;
  virtual GFPoint closestPoint(const SPoint3 & queryPoint);

  virtual int containsPoint(const SPoint3 &pt) const;
  virtual int containsParam(const SPoint2 &pt) const;

  virtual SVector3 normal(const SPoint2 &param) const;
  virtual Pair<SVector3,SVector3> firstDer(const SPoint2 &param) const;
  virtual double * nthDerivative(const SPoint2 &param, int n, 
				 double *array) const;

  virtual GeomType::Value geomType() const;
  virtual int geomDirection() const;

  virtual Logical::Value continuous(int dim) const;
  virtual Logical::Value periodic(int dim) const;
  virtual Logical::Value degenerate(int dim) const;

  virtual double tolerance() const;

  SVector3 inwardSecant(GEdge *e, double ept, int dir);

protected:
  virtual Logical::Value surfPeriodic(int dim) const;

  virtual SPoint2 parFromEdgePar(GEdge *edge, double epar, int dir) const;
  virtual SPoint2 parFromPoint(const SPoint3 &) const;

};

#endif
