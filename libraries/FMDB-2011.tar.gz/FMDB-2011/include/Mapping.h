/* 
   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of Trellis written and maintained by the 
   Scientific Computation Research Center (SCOREC) at Rensselaer Polytechnic
   Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA
*/
#ifndef H_Mapping
#define H_Mapping

#include "mTensor2.h"

#ifdef SIM
#define TRELLIS_MTYPE Trellis_mType
typedef enum TRELLIS_MTYPE {VERTEX,EDGE,TRI,QUAD,HEX,PRISM,PYRAMID,TET};
#include "MeshSim.h"
#include "MSMapping.h"
#else
// for AOMD the mType enum is specified in AOMD_Internals.h
#define TRELLIS_MTYPE mType
#include "AOMD.h"
#include "AOMD_Internals.h"
#endif

#include <vector>
#include <list>

typedef double (* LevelSetFunction)(Trellis_Util::mPoint &);


/**
   Mapping for mesh entities. We suppose that we have 2 systems of
   coordinates : (u,v,w) and (x,y,z). The mapping deals with these
   2 systems of coordinates.
 */

namespace Trellis_Util {

  class mPoint;
  class mVector;
  class Mapping;

  class Mapping
  {
    protected:

/******************************************************************
  Three new member variables and corresponding member functiones 
  are added by P.Hu  July, 2002
******************************************************************/
      TRELLIS_MTYPE entityType;
      int entityDim;
      Mapping *rootMapping; 

      pEntity ent;
    public:
      /**
	 Constructor takes a mesh entity as input	 
       */
    Mapping(pEntity e);
      /**
	 Constructor takes a mesh entity, vector of all vertecies and entity type, entity dim  as input	 
       */
/****************************************************************
  One Question: Member variable 'knots' is not in the base class
  Mapping, therefore, this constructor can't really work here, if 
  move the variable 'knots' in the base calss, it will be better
****************************************************************/

      Mapping(Mapping *theMapping, std::vector<Trellis_Util::mPoint> *_input_knots, 
	      TRELLIS_MTYPE _type, int dim);
      
      virtual void buildMappings(Mapping * theMapping, LevelSetFunction _levelSetFunc, 
				 int flag, std::list<Mapping *> &out_list );
      
      /**
	 virtual destructor does nothing
       */
      virtual ~Mapping(){}
      /**
	 get the mesh entity
       */
      inline pEntity getEntity () const {return ent;}
      /**
	 set the entity type
      */
      inline void setEntityType(TRELLIS_MTYPE _type) {entityType = _type;}
      /**
	 get the entity type
      */
      inline TRELLIS_MTYPE getEntityType() const {return entityType;}
      /**
	 set the entity dimension
      */
      inline void setEntityDim(int _dim) {entityDim = _dim;}
      /**
	 get the entity dimension
      */
      inline int getEntityDim() const {return entityDim;}
      /**      
	 set the root mapping
      */
      inline void setRootMapping(Mapping *_theMapping) {rootMapping = _theMapping;}
      /**
	 get the root mapping
      */
      inline Mapping * getRootMapping() const {return rootMapping;}

      //      virtual std::vector<AOMD::mPoint> * getKnots() const;

      void local2rootlocal(double u, double v, double w, double &r_u, double &r_v, double &r_w);

      /**
	 Inversion of the mapping by a newton algorithm
       */      
      virtual bool invert(double x, double y, double z,
			  double &u, double &v, double &w) const;
      /**
	 Jacobian = d(x,y,z)/d(u,v,w) is a 3x3 matrix
	 computation of the inverse of the jacobian at (u,v,w), 
	 returns the determinant of the jacobian (not of the inverse).
       */
      virtual double jacInverse(double x, double y, double z, 
				mTensor2&) const;
      /**
	 returns determinant of jacobian at (u,v,w).
       */
      virtual double detJac(double u, double v, double w) const;
      /**
	 tells if a point (u,v,w) is inside the reference element or not
       */
      virtual bool inReferenceElement(double u, double v, double w) const;
      /**
	 checks if a point in REAL coordinates is inside the element ent
	 if it's the case, returns local coordinates
       */
      virtual bool interiorCheck (pEntity , const mPoint &p, double &u, double &v, double &w) const;   
      /**
	 returns the center of gravity of the element in local coordinates
       */
      virtual void COG (double &u, double &v, double &w) const;
      /**
	 Computes gradients in real world knowing them in refernce world
       */
      virtual double PushBack ( double u, double v, double w, int vsize, 
			       mVector *vec ) const;
      virtual double PushBack ( double u, double v, double w, int vsize, 
			       mTensor2 *vec ) const;		       

      inline double PushBack (double u, double v, double w, int vsize, 
			       std::vector<mVector> &vec) const
      {
		return PushBack (u,v,w,vsize,&(*vec.begin()));
      }      
      
      int simplexation ( int &dim , int &nbPnt, double *u, double *v, double *w, int combn [][4] ) const ; 


      //---------------------------------------------//
      //  P u r e   V i r t u a l   M e m b e r s    //
      //---------------------------------------------//


      /**
	 eval and deval functions have to be re-written for different mesh
	 mappings (curvilinear, bezier,...).	 
	 eval computes x(u,v,w) , y(u,v,w) and z(u,v,w) 
	 deval computes derivatives dx/du , dy/du ...
      */

      
      virtual void eval (double u, double v, double w,
			 double &x, double &y, double &z) const = 0;

      virtual void deval(double u, double v, double w,
			 double &dxdu, double &dydu, double &dzdu,
			 double &dxdv, double &dydv, double &dzdv,
			 double &dxdw, double &dydw, double &dzdw) const = 0;

      /**
	 compute the exterior normal to ent at a point u,v,w of the reference
	 face face
       */
      virtual void normalVector(pEntity face, double u , double v , double w, mVector &n) const = 0;
      
      /**
	 computes the normal vector to a face !!! If it's an edge, then
	 we suppose that the normal vector is t_edge x ez 
       */      
      virtual void normalVector(double u , double v , double w, mVector &n) const;

      /**
	 computes the bounding box of a mesh entity
       */
      virtual void boundingBox (  mPoint &min, mPoint &max ) const = 0;

      virtual int order() const = 0;
      virtual int geomOrder() const = 0;

  };
} //end of namespace

#endif
