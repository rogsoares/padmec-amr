/* 
   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of Trellis written and maintained by the 
   Scientific Computation Research Center (SCOREC) at Rensselaer Polytechnic
   Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA
*/
 /***************************************************************
 * $Id: TFace.h,v 1.11 2005/02/02 00:08:57 acbauer Exp $
 * Description: 
 * Modification 9/15/98 - added the tagId member data that is returned in the
 * case of that RealFace = Null Pointer 

*/

#ifndef H_TFace
#define H_TFace

//#include "SList.h"
#include "GFace.h"

template<class T> class SSList;
class GRegion;

/* A topological face. May represent a copy of an existing face. */
class TFace : public GFace {
public:
  TFace(SGModel *model, int tag, GFace *f,SSList<GEdge*> edges, 
	SSList<int> dirs);
  virtual ~TFace();

  virtual GeoRep * geometry();

  //Geometric Ops
  Range<double> parBounds(int i) const;
  virtual int paramDegeneracies(int dir, double *par);
  virtual SBoundingBox3d bounds() const;
  virtual GFPoint point(double par1, double par2) const;
  virtual GFPoint point(const SPoint2 &pt) const;
  virtual GFPoint closestPoint(const SPoint3 & queryPoint);
  virtual int containsPoint(const SPoint3 &pt) const;
  virtual int containsParam(const SPoint2 &par) const;

  virtual double period(int dir) const;

  virtual SVector3 normal(const SPoint2 &param) const;
  virtual Pair<SVector3,SVector3> firstDer(const SPoint2 &param) const;
  virtual double * nthDerivative(const SPoint2 &param, int n, 
				 double *array) const;

  virtual GeomType::Value geomType() const;
  virtual int geomDirection() const;

  virtual Logical::Value continuous(int dim) const;
  virtual Logical::Value periodic(int dim) const;
  virtual Logical::Value degenerate(int dim) const;

  virtual double tolerance() const;

  virtual SSList<GEdge*> splitU(double u);
  virtual SSList<GEdge*> splitV(double v);

  virtual SSList<GEdge*> splitSeamU(double ulow, double uhigh);
  virtual SSList<GEdge*> splitSeamV(double vlow, double vhigh);

  virtual GEntity *getBaseRep();
  virtual void * getNativePtr() const;
  virtual int getNativeInt() const;

  // these should only be called internalled (by other GEntity classes)
  virtual void insertEdge(GEdge *e);

protected:
  virtual Logical::Value surfPeriodic(int dim) const;

  SSList<GEdge*> splitAtConstParam(int axis, double par1, double par2);

  SPoint2 parFromPoint(const SPoint3 &pt) const;
  void makeNewLoops(GEdge *e, GFaceUse *fu, GFaceUse *fu1, GFaceUse *fu2, GLoopUse **l1, GLoopUse **l2);
    
  GFace *RealFace;
  int d_periodic[2];
};

#endif
