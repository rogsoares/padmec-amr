/**************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*****************************************************************************/

/*<i> ****************************************************************************
 *
 *  AOMD/pmodel/pmMeshMigration.cc
 *  Created by Seegyoung Seol, on The Dec 09 2003, 10:26:37 EDT
 *
 *  File Content: main mesh migration functions 
 *
 *************************************************************************** </i>*/

#ifdef PARALLEL
 
#ifndef _PM_ZOLTAN_CALLBACKS_H_
#define _PM_ZOLTAN_CALLBACKS_H_

#include "pmMigrationCallbacks.h"
#include "ParUtil.h"

namespace AOMD {

/**
   A load balancer that uses Zoltan library.
   I have only implemented the interface for
   ParMetis and the Octree.
*/
class pmZoltanCallbacks: public pmMigrationCallbacks
{
public :
  /// Algorithms available
  enum Algorithm {LDiffusion,GDiffusion,Remap,MLRemap,Random,Octree,Serial};
private:
  /// save the algorithm
  Algorithm theAlgorithm;
public :
  /// Constructor takes the algorithm as input
  pmZoltanCallbacks(Algorithm algo = Remap);
  /// this function interfaces with Zoltan
  virtual void partition(AOMD_distributed_graph2 &theGraph , int *partitionVector);
  /// change the algorithm
  void setAlgorithm (const Algorithm &algo);  
//  Algorithm getAlgorithm();
  virtual int nbProcs() const { return ParUtil::Instance()->size();}
};

bool deleteUserData(mEntity* ent,int);

class zoltanCB: public pmZoltanCallbacks
{
public :
  zoltanCB() 
    : pmZoltanCallbacks(pmZoltanCallbacks::Serial){}
  virtual void * getUserData (mEntity* e, int dest_proc, int &size)
  {
    size = 0;
    return 0;
  } 
  virtual void recieveUserData (mEntity* e, int pid, int tag, void *buf) 
  {  }
  virtual void deleteUserData (void *buf) 
  { free(buf); }  
  bool useWeights() const {return false;} 
  float getWeight (mEntity*) const {return 1.0;}  
};

class migrationCB: public pmZoltanCallbacks
{
public :
  migrationCB() 
    : pmZoltanCallbacks(pmZoltanCallbacks::LDiffusion){}
  virtual void * getUserData (mEntity* e, int dest_proc, int &size)
  {
    size = 0;
    return 0;
  } 
  virtual void recieveUserData (mEntity* e, int pid, int tag, void *buf) 
  {  }
  virtual void deleteUserData (void *buf) 
  { free(buf); }  
  bool useWeights() const {return false;} 
  float getWeight (mEntity*) const {return 1.0;}  
};

} // end of namespace 


#endif  /* _PM_ZOLTAN_CALLBACKS_H_ */
#endif 	/* PARALLEL */

