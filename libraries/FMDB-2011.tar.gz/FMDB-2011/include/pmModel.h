/**************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*****************************************************************************/

/*<i> ****************************************************************************
 *
 *  AOMD/include/pmModel.cc
 *  Created by Seegyoung Seol, on Mon Dec 08 2003, 10:26:37 EDT
 *
 *  File Content: partition model class
 *
 *************************************************************************** </i>*/

#ifdef PARALLEL

#ifndef _PM_MODEL_H_
#define _PM_MODEL_H_

#include "pmEntity.h"
#include <iostream>
#include <set>
#include <vector>

namespace AOMD {

class mMesh;
class mEntity;

class pmModel
{
protected:
  static pmModel* instance;
  mMesh* mesh;
// isUptodate determines 3 things
//   1. CB entities pool is up-to-date, or not
//   2. bounding partition list is up-to-date, or not
//   3. Reverse PClassification is up-to-date, or not
  bool isUptodate;	
  std::set<pmEntity*, pmEntityLessThanKey> allPEntities;	
  std::vector<mEntity*> allCBEntities[4];
  // stores bounding partition ids of this mesh
  std::vector<int> BPs;  
  
public:
  typedef std::set<pmEntity*,pmEntityLessThanKey>::const_iterator PEIter; 
  typedef std::vector<mEntity*>::iterator CBIter;
  typedef std::vector<int>::iterator BPIter;

// constructor + destuctor
  pmModel();
  ~pmModel();
  static pmModel* Instance();

// set/get private data
  void setMesh(mMesh* m) {  mesh=m; }
  bool is_uptodate() { return isUptodate; }

// update ownership of mesh entities
  void updateOwnership();

// update partition model in 3 things
// 1. bounding partitions
// 2. pool of cb entities 
// 3. reverse PClassification
  void update();

// partition entities operators
  void addPEntity(pmEntity* pe)

  { allPEntities.insert(pe); }
  PEIter peBegin() const
  {  return allPEntities.begin();}
  PEIter peEnd  () const
  {  return allPEntities.end();}
  int getNumPEs() { return allPEntities.size(); }
  pmEntity* getPartitionEntity(std::set<int>& bps);
  pmEntity* getPartitionEntity(int id);
// bounding partitions operators
  BPIter bpBegin();
  BPIter bpEnd();

// common boundary entities operators
  CBIter cbBegin(int dim);
  CBIter cbEnd(int dim);
  // returns CB entities of dimension dim
  // if dim=-1, it returns all CB entities
  void getCBEntities(int dim, std::vector<mEntity*>&);

// return reverse partition classification
void getRPClassification(pmEntity* pe, std::vector<mEntity*>& entities);

// Misc.
  void print();

};
				    
} // end of namespace

#endif
#endif /* PARALLEL */
