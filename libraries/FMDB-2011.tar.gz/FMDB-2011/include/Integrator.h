/* 
   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of Trellis written and maintained by the 
   Scientific Computation Research Center (SCOREC) at Rensselaer Polytechnic
   Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA
*/
#ifndef _INTEGRATOR_H_
#define _INTEGRATOR_H_
#ifdef SIM
#include "MeshSim.h"
#else
#include "AOMD.h"
#include "AOMD_Internals.h"
#endif

#include "Mapping.h"

namespace Trellis_Util {

class Integrator
{  
  public :
    virtual int nbIntegrationPoints(int order) const = 0;
  //    virtual int nbIntegrationPoints_way2(int order) const = 0;
    virtual void iPoint(int i, int order , double &u, double &v, double &w, double &weight) const = 0;  
  //    virtual void iPoint_way2(int i,int order,double &u, double &v, double &w, double &weight) const = 0;
};

class GaussIntegrator : public Integrator
{
  pEntity ent;
  TRELLIS_MTYPE entityType;

 public:
  GaussIntegrator(pEntity);
  GaussIntegrator(Mapping *);
  virtual int nbIntegrationPoints(int order) const;
  //  virtual int nbIntegrationPoints_way2(int order) const;
  virtual void iPoint(int i,int order,double &u, double &v, double &w, double &weight) const;  
  //  virtual void iPoint_way2(int i,int order,double &u, double &v, double &w, double &weight) const;
};
}

#endif


