/* 
   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of Trellis written and maintained by the 
   Scientific Computation Research Center (SCOREC) at Rensselaer Polytechnic
   Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA
*/

#ifndef H_TFaceSplitEdge
#define H_TFaceSplitEdge

#include "GEdge.h"

class SPoint2;

/** An edge that splits a face at a constant
  parameter value. The edge can lie on a seam in the underlying
  parametric space and thus can have two parameter values w.r.t. the
  face parameter that is fixed. 
  */
class TFaceSplitEdge : public GEdge {
public:
  TFaceSplitEdge(SGModel *model, int tag, GFace *realFace, GVertex *v0, 
		 GVertex *v1, 
		 double parStart, double parEnd, int axis, double fParPos,
		 double fParNeg);


  virtual Logical::Value continuous(int dim) const;
  virtual Logical::Value periodic(int dim) const;
  virtual Logical::Value degenerate(int dim) const;

  Range<double> parBounds(int i) const;
  SBoundingBox3d bounds() const;
  // Geometric Ops
  virtual GEPoint point(double p) const;
  virtual GEPoint closestPoint(const SPoint3 & queryPoint);
  virtual int containsPoint(const SPoint3 &pt) const;
  virtual int containsParam(double par) const;

  virtual SVector3 firstDer(double par) const;
  virtual void nthDerivative(double param, int n, double *array) const;

  virtual SPoint2 reparamOnFace(GFace * face, double epar, int dir) const;

  virtual GeomType::Value geomType() const;

  virtual GeoRep * geometry();
  int geomDirection() const;

  virtual double tolerance() const;

  virtual GVertex * split(double par);
  virtual SSList<GEPoint> intersect(int fAxis, double fPar, GFace *f);

protected:
  virtual double parFromPoint(const SPoint3 &pt) const;
  SPoint2 facePar(double p) const;

  GFace *RealFace;
  double ParStart, ParEnd, FPar[2];
  int FixedPar;  // the parameter value that is fixed along this edge

};

#endif
