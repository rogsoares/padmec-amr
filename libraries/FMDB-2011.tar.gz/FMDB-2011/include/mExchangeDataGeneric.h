/**************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*****************************************************************************/
#ifndef  _AOMD_EXCHANGEDATAGENERIC_H_
#define  _AOMD_EXCHANGEDATAGENERIC_H_

#include "mExchangeData.h"
#include "AOMD_OwnerManager.h"
#include "mMesh.h"
#include "ParUtil.h"

#ifdef PARALLEL
#include "autopack.h"
#endif

namespace AOMD {
  
#ifdef PARALLEL
  template <class Iterator> 
  void exchangeDataGeneric (const Iterator &beg, const Iterator &end , 
                           AOMD_DataExchanger &de )
  {
    int *sendcounts = new int[ParUtil::Instance()->size()];
    for(int i=0;i<ParUtil::Instance()->size();i++)sendcounts[i]=0;
    
    Iterator it = beg;
    
    for( ; it != end ; ++it)
      {	      
	mEntity *e = (*it).first;
	AOMD_SharedInfo si = (*it).second;
	void *buf = de.AP_alloc_and_fill_buffer (e, si, de.tag());
	if(buf)
	  {
	    AP_send(buf);
	    sendcounts[si.pid()] ++;
	  }
      }
    
    AP_check_sends(AP_NOFLAGS);
    AP_reduce_nsends(sendcounts);
    
    int message=0;
    int count;
    
    while (!AP_recv_count(&count) || message<count) 
      {
	void *msg;
	int from;
	int tag;
	int size;
	int rc;
	rc=AP_recv(MPI_ANY_SOURCE, de.tag(), AP_BLOCKING|AP_DROPOUT,
		   &msg, &size, &from, &tag);
	if (rc) 
	  {
	    message++;
	    de.receiveData (from, msg);
	    AP_free(msg);
	  }
      }    
    AP_check_sends(AP_WAITALL);
  }
#else // not parallel
  template <class Iterator> 
  void exchangeDataGeneric ( const Iterator &beg, const Iterator &end , AOMD_DataExchanger &de )
  {
    Iterator it = beg;
    
    for( ; it != end ; ++it)
      {	      
	mEntity *e = (*it).first;
	AOMD_SharedInfo si = (*it).second;    
	void *buf = de.AP_alloc_and_fill_buffer (e, si, de.tag());
	if(buf)
	  {
	    de.receiveData (ParUtil::Instance()->rank(), buf);
	    free(buf);
	  }
      }   
  }
#endif
  
#ifdef PARALLEL  
  template <class Iterator> 
  void exchangeDataGeneric_NonBlocking ( const Iterator &beg, const Iterator &end , AOMD_DataExchanger &de )
  {
    
    int tag = AP_send_begin();

    Iterator it = beg;

    int nbsend = 0;
    
    for( ; it != end ; ++it)
      {	      
	mEntity *e = (*it).first;
	AOMD_SharedInfo si = (*it).second;
	void *buf = de.AP_alloc_and_fill_buffer (e, si, tag);
	if(buf)
	  {
	    AP_send(buf);
	    nbsend++;
	  }
      }
    
    AP_send_end();

    int message=0;
    int count;
    
    while (!AP_recv_count(&count) || message<count) 
      {
	void *msg;
	int from;
	int rtag;
	int size;
	int rc;

	rc=AP_recv(MPI_ANY_SOURCE, tag, AP_BLOCKING| AP_FIFO |AP_DROPOUT,
		   &msg, &size, &from, &rtag);

	if (rc) 
	  {
	    message++;
	    de.receiveData (from, msg);
	    AP_free(msg);
	  }	
      }    
    
    AP_check_sends(AP_WAITDEFER);
  }
#endif
} // end of namespace
#endif // end define

