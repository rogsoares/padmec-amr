/* 
   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of Trellis written and maintained by the 
   Scientific Computation Research Center (SCOREC) at Rensselaer Polytechnic
   Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA
*/
 /***************************************************************
 * Modification 9/15/98 - added the tagId member data that is returned in the
 * case of that RealEdge = Null Pointer 

*/

#ifndef H_TEdge
#define H_TEdge

//#include "SList.h"
#include "GEdge.h"

template<class T> class SSList;
class GVertex;

/** A topological edge. May represent a copy of an existing edge. */
class TEdge : public GEdge {
public:
  TEdge(SGModel *model, int tag, GEdge *,GVertex *v0, GVertex *v1);
  virtual ~TEdge();

  virtual Logical::Value continuous(int dim=0) const;
  virtual Logical::Value periodic(int dim=0) const;
  virtual Logical::Value degenerate(int dim=0) const;
  virtual int isSeam(GFace *face) const;

  Range<double> parBounds(int i=0) const;
  SBoundingBox3d bounds() const;
  // Geometric Ops
  virtual GEPoint point(double p) const;
  virtual GEPoint closestPoint(const SPoint3 & queryPoint);
  virtual int containsPoint(const SPoint3 &pt) const;
  virtual int containsParam(double par) const;

  virtual SVector3 firstDer(double par) const;
  virtual void nthDerivative(double param, int n, double *array) const;
  virtual SPoint2 reparamOnFace(GFace * face, double epar, int dir) const;

  virtual GeomType::Value geomType() const;

  virtual GeoRep * geometry();
  int geomDirection() const;

  virtual double tolerance() const;

  // topological operations
  virtual GEntity *getBaseRep();
  virtual void * getNativePtr() const;
  virtual int getNativeInt() const;

  virtual GVertex * split(double par);

  virtual SSList<GEPoint> intersect(int fAxis, double fPar, GFace *f);
protected:
  virtual double parFromPoint(const SPoint3 &pt) const;

  GEdge *RealEdge;

};


#endif
