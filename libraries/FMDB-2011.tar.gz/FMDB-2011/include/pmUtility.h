/**************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*****************************************************************************/

/*<i> ****************************************************************************
 *
 *  AOMD/include/pmUtility.h
 *  Created by Seegyoung Seol, on Mon Dec 15 2003, 10:26:37 EDT
 *
 *  File Content: general parallel utility functions
 *
 *************************************************************************** </i>*/
#ifdef PARALLEL

#ifndef PM_UTILITY_H
#define PM_UTILITY_H

#include <list>
#include <vector>
#include <map>
#include <set>
#include "mMesh.h"
#include "mEntity.h"
#include "pmDataExchanger.h"
#include "pmMigrationCallbacks.h"

namespace AOMD {

struct int4_struct
{
  int idata[4];
};

struct mEnt_struct
{
  mEntity* entity;
};

struct int_mEnt_struct
{
  int i;
  mEntity *entity;
};
 
struct int2_mEnt_struct
{
  int i;
  int j;
  mEntity *entity;
};

struct mEnt2_struct
{
  mEntity* ent1;
  mEntity* ent2;
};

struct int_mEnt2_struct
{
  int i;
  mEntity* ent1;
  mEntity* ent2;
};

struct int2_mEnt2_struct
{
  int i;
  int j;
  mEntity* ent1;
  mEntity* ent2;
};

struct rc_struct_1
{
  int pid;
  mEntity* entity;
  rc_struct_1(int i, mEntity* e): pid(i), entity(e){}
};

struct rc_struct_2
{
  mEntity* ent1;
  int pid;
  mEntity* ent2;
  rc_struct_2(mEntity* e1, int i, mEntity* e2): ent1(e1), pid(i), ent2(e2){}
};

void mergeArray(std::vector<int>& vec);

}  // end of AOMD

#endif
#endif /* PARALLEL */
