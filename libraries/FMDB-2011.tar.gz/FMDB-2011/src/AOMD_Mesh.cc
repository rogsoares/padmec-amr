/******************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*********************************************************************************/

/*<i> ****************************************************************************
 *
 *  AOMD/cint/AOMD_Mesh.cc
 *  Created by Seegyoung Seol, on Mon Dec 15 2003, 10:26:37 EDT
 *
 *  File Content: AOMD c-iterface for Mesh
 *
 *************************************************************************** </i>*/
 
#ifndef SIM
#include "AOMD_cint.h"
#include "AOMD_Internals.h"
#include "AOMDfwd.h"
#include "AOMD_Defs.h"
#include "ParUtil.h"
#include "mParallelUtility.h"
#include "mEntity.h"
#include "mMesh.h"
#include "mEdge.h"
#include "mVector.h"
#include "mPoint.h"
#include "mVertex.h"
#include "mException.h"
#include "mAOMD.h"
#include "mDebugUtil.h"
#ifdef PARALLEL
#include "autopack.h"
#include "pmModel.h"
#include "pmModelUtil.h"
#include "pmMigrateUtil.h"
#include "pmMigrationCallbacks.h"
#include "pmZoltanCallbacks.h"
#endif
#ifdef DMUM
#include "mDmum.h"
#endif

#include <iostream>
#include <list>
#include <vector>
#include <algorithm>
#include <iterator>
#include <string>

using namespace AOMD;
using std::cout;
using std::endl;
using std::vector;
using std::copy;
using std::string;

// **********************************
// General mesh Info
// **********************************
int M_getMaxVId(pMesh mesh)
{
#ifndef PARALLEL
  return mesh->getIdGenerator().getMaxValue(); 
#else
  return P_getMaxInt(mesh->getIdGenerator().getMaxValue());  
#endif   
}

int M_pid()
{
  return P_pid();
}

int M_size()
{
  return P_size();
}

int PM_load (pMesh pm, const char *fName)
{
#ifdef PARALLEL
  // check file extension
  char ext[6];
  strcpy(ext,fName+(strlen(fName)-4));
  if(strcmp(ext,".sms"))
  {
    char text[256];
    sprintf(text,"AOMD cannot load partitioned %s",fName);
    throw mException (__LINE__,__FILE__,text);
  }
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n****************************\n");
  ParUtil::Instance()->Msg(ParUtil::INFO,"    PM_load - %s\n",fName);
  double t1 = ParUtil::Instance()->wTime();

  AOMD_Util::Instance()->loadPartitionedMesh(pm,fName);

  double t2 = ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"   (t = %f sec)\n", t2-t1);
  ParUtil::Instance()->Msg(ParUtil::INFO,"****************************\n");
#endif
  return 1;
}
  
int PM_write(pMesh pm, const char *fName)
{
#ifdef PARALLEL
  // check file extension
  char ext[6];
  strcpy(ext,fName+(strlen(fName)-4));
  if(strcmp(ext,".sms"))
  {
    char text[256];
    sprintf(text,"AOMD cannot write partitioned mesh into %s",fName);
    throw mException (__LINE__,__FILE__,text);
  }
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n****************************\n");
  ParUtil::Instance()->Msg(ParUtil::INFO,"    PM_write - %s\n",fName);
  double t1 = ParUtil::Instance()->wTime();

  AOMD_Util::Instance()->writePartitionedMesh(pm,fName);

  double t2 = ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"   (t = %f sec)\n", t2-t1);
  ParUtil::Instance()->Msg(ParUtil::INFO,"****************************\n");
#endif
  return 1;
}
  

void M_getCBEntities(pMesh mesh,int dim, std::vector<pEntity>& cbEntities)
{
#ifdef PARALLEL
   pmModel::Instance()->getCBEntities(dim, cbEntities);
#endif
}

void M_getPOEntities(pMesh mesh, std::vector<pEntity>* poEntities)
{
  for (int i=0; i<3; ++i)
    for (mMesh::iterall it=mesh->beginall(i); it!=mesh->endall(i); ++it)
    {
      if ((*it)->size(i+1)==0)
        poEntities[i].push_back(*it);
    }
  for (mMesh::iterall it=mesh->beginall(3); it!=mesh->endall(3); ++it)
    poEntities[3].push_back(*it);
}

void M_boundingPids(std::vector<int>& bps)
{
#ifdef PARALLEL
  pmModel* pmodel=pmModel::Instance();
  pmodel->update();
  std::copy(pmodel->bpBegin(), pmodel->bpEnd(),back_inserter(bps));
#endif
}


void M_print(pMesh pm)
{
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n***  M_print(mesh)  ***\n");	  
  pm->printAll();
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n***  M_print(mesh)  ***\n");	  
}


bool M_compare(pMesh mesh, pMesh mesh2)
{
  double t1 = ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n****************************\n");
  ParUtil::Instance()->Msg(ParUtil::INFO,"    M_compare");
  
  mEntity* ent;
  mEntity* ent2;
  pmEntity* pe;
  pmEntity* pe2;
  for (int i=0; i<=3;++i)
  {
  // compare the total number of entities
    assert(mesh->size(i)==mesh2->size(i));
    mMesh::iterall it=mesh->beginall(i);
    mMesh::iterall it2=mesh2->beginall(i);
    mMesh::iterall itend=mesh->endall(i);
    mMesh::iterall itend2=mesh2->endall(i);
    // compare entity by entity
    for (;it!=itend&&it2!=itend2;)
    {
      ent=*it;
      ent2=*it2;
      assert(ent->getId()==ent2->getId());
      assert(ent->getUid().compare(ent2->getUid())==0);
      assert(ent->getLevel()==ent2->getLevel());
      assert(ent->getOwner()==ent2->getOwner());
      assert(ent->getClassification()==ent2->getClassification());
#ifdef PARALLEL
      assert(ent->getNumRemoteCopies()==ent2->getNumRemoteCopies());
#endif
      pe = ent->getPClassification();
      if (pe)
      {
        pe2=ent2->getPClassification();
	assert(pe2!=0);
	assert(pe->getId()==pe2->getId());
	assert(pe->getLevel()==pe2->getLevel());
	assert(pe->getOwner()==pe2->getOwner());
	assert(pe->getNumBPs()==pe2->getNumBPs());
      }
      ++it;
      ++it2;
    }    
  }
  double t2 = ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO," SUCCEED\n  ");
  ParUtil::Instance()->Msg(ParUtil::INFO,"   (t = %f sec)\n",t2-t1);
  ParUtil::Instance()->Msg(ParUtil::INFO,"****************************\n\n");
  return true;
}

bool M_verify(pMesh mesh)
{
#ifdef PARALLEL
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
#endif
  double t1 = ParUtil::Instance()->wTime();
  if (ParUtil::Instance()->rank()==0)
  {
    printf("\n****************************\n");
    printf("    M_verify");
  }
  bool ret=verify_mesh(mesh);
#ifdef PARALLEL
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
#endif
  double t2 = ParUtil::Instance()->wTime();
  if (ParUtil::Instance()->rank()==0)
  {
    if(ret) printf(" SUCCEED\n");
    else printf(" FAIL\n");
    printf("   (t = %f sec)\n",t2-t1);
    printf("****************************\n\n");
  }
  return ret;
}

void M_printNumEntities(pMesh mesh)
{
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n****************************\n");
  ParUtil::Instance()->Msg(ParUtil::INFO,"    M_printNumEntities\n\n");
  mesh->printNumEntities();  
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n****************************\n\n");	  
}


int PM_merge(pMesh mesh)
{
#ifdef PARALLEL
  if (P_size()==1) return 0;
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
#ifdef DEBUG
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n****************************\n");
  ParUtil::Instance()->Msg(ParUtil::INFO,"    PM_merge - ");
  double t1 = ParUtil::Instance()->wTime();
#endif
  zoltanCB zlb;
  int ret = pmMerge(mesh,zlb);
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
#ifdef DEBUG
  double t2 = ParUtil::Instance()->wTime(); 
  ParUtil::Instance()->Msg(ParUtil::INFO,
          "      (t = %f sec)\n",t2-t1);
  ParUtil::Instance()->Msg(ParUtil::INFO,"****************************\n\n");	  
#endif
  return ret;
#else
  return 0;
#endif
}

#ifdef PARALLEL

int M_createGhost(mMesh* mesh, pmMigrationCallbacks &cb)
{
  if (P_size()==1) return 0;
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
#ifdef DEBUG
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n****************************\n");
  ParUtil::Instance()->Msg(ParUtil::INFO,"    M_createGhost\n");
#endif
  int ret=migrateGhostEntities(mesh, cb);

  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
#ifdef DEBUG
  ParUtil::Instance()->Msg(ParUtil::INFO,"****************************\n\n");	  
#endif
  return ret;
}

int M_expandGhost(pMesh mesh, AOMD::pmMigrationCallbacks &cb, 
                 std::vector<pEntity>& vtsToExpand, int dimToExpand)
{
  if (P_size()==1) return 0;
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
#ifdef DEBUG
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n****************************\n");
  ParUtil::Instance()->Msg(ParUtil::INFO,"    M_expandGhost (dim=%d)\n", dimToExpand);
#endif
  int ret=expandGhostEntities(mesh, cb, vtsToExpand, dimToExpand);

  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
#ifdef DEBUG
  ParUtil::Instance()->Msg(ParUtil::INFO,"****************************\n\n");	  
#endif
  return ret;		 
}

void M_removeGhost(mMesh* mesh)
{
  if (P_size()==1) return;

  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
#ifdef DEBUG
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n****************************\n");
  ParUtil::Instance()->Msg(ParUtil::INFO,"    M_removeGhost\n");
#endif
  removeGhostEntities(mesh);
  
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
#ifdef DEBUG
  ParUtil::Instance()->Msg(ParUtil::INFO,"****************************\n\n");	  
#endif
}

void M_loadbalance(pMesh  mesh,AOMD::pmMigrationCallbacks &cb)
{
  if (P_size()==1) return;
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n****************************\n");
  ParUtil::Instance()->Msg(ParUtil::INFO,"    M_loadbalance\n");
  pmLoadBalance(mesh, cb);
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  ParUtil::Instance()->Msg(ParUtil::INFO,"****************************\n\n");	  
  return;
}

int M_migration(pMesh mesh, int dimToMove, std::list<pEntity>& entList,
                AOMD::pmMigrationCallbacks &cb,
                int dimToKnow1, std::vector<pEntity>& rmE1, std::vector<pEntity>& newE1,
		int dimToKnow2, std::vector<pEntity>& rmE2, std::vector<pEntity>& newE2)
{
  if (P_size()==1) return 0;
//  M_verify(mesh);
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
#ifdef DEBUG
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n****************************\n");
  if (dimToMove==1)
  {
    if (dimToKnow1 == 3)
      ParUtil::Instance()->Msg(ParUtil::INFO,"    M_migration_Realign\n");
    else if (dimToKnow1==1)      
      ParUtil::Instance()->Msg(ParUtil::INFO,"    M_migration_Swap\n");
  }
  else
  {
    if (dimToKnow2==-1)
      ParUtil::Instance()->Msg(ParUtil::INFO,"    M_migration_Coarsen\n");
    else 
      ParUtil::Instance()->Msg(ParUtil::INFO,"    M_migration_Snap\n");
  }
#endif
  std::vector<pEntity> rmE[4];
  std::vector<pEntity> newE[4];
  int ret=pmMeshMigration(mesh, dimToMove,entList,cb,rmE,newE);
  if (dimToKnow1>=0)
  {  
    std::copy(rmE[dimToKnow1].begin(), rmE[dimToKnow1].end(), 
              std::back_inserter(rmE1));
    std::copy(newE[dimToKnow1].begin(), newE[dimToKnow1].end(), 
              std::back_inserter(newE1));
  }

  if (dimToKnow2>=0)
  {  
    std::copy(rmE[dimToKnow2].begin(), rmE[dimToKnow2].end(), 
              std::back_inserter(rmE2));
    std::copy(newE[dimToKnow2].begin(), newE[dimToKnow2].end(), 
              std::back_inserter(newE2));
  }
  
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
#ifdef DEBUG
  ParUtil::Instance()->Msg(ParUtil::INFO,"****************************\n\n");	  
#endif
  return ret;
}


int M_migrationForSnap(pMesh mesh, AOMD::pmMigrationCallbacks &cb,
		std::list<pEntity>& vtsOnCB, 
  	        std::list<std::pair<pEntity,pEntity> > &vtfcPairs,
                int dimToKnow1, std::vector<pEntity>& rmE1, std::vector<pEntity>& newE1)
{
  if (P_size()==1) return 0;
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
#ifdef DEBUG
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n****************************\n");
  ParUtil::Instance()->Msg(ParUtil::INFO,"    M_migration_Snap\n");
#endif
  std::vector<pEntity> rmE[4];
  std::vector<pEntity> newE[4];
  int ret=pmMeshMigration(mesh, cb, vtsOnCB, vtfcPairs,rmE,newE);
  if (dimToKnow1>=0)
  {  
    std::copy(rmE[dimToKnow1].begin(), rmE[dimToKnow1].end(), 
              std::back_inserter(rmE1));
    std::copy(newE[dimToKnow1].begin(), newE[dimToKnow1].end(), 
              std::back_inserter(newE1));
  }
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
#ifdef DEBUG
  ParUtil::Instance()->Msg(ParUtil::INFO,"****************************\n\n");	  
#endif
  return ret;
}			   
#endif

int M_globalMaxDim(pMesh mesh)
{
  int dim = mesh->getDim();
  int maxDim = P_getMaxInt(dim);
  return maxDim;
}

int M_globalMinDim(pMesh mesh)
{
  int dim = mesh->getDim();
  int maxDim = P_getMinInt(dim);
  return maxDim;
}

void M_numEntitiesOwned(pMesh mesh, int dim, vector<int>& output)
{
#ifdef PARALLEL
  unsigned int numPE = ParUtil::Instance()->size();
  output.resize(numPE);
  int* senddata;
  int* recvdata;

  // send phase begins
  int* sendcounts=new int[numPE];
  for (unsigned int i=0;i<numPE;++i) sendcounts[i]=0;
 
  mEntity* ent;
  int numEnt=0;
  for (mMesh::iterall it=mesh->beginall(dim);it!=mesh->endall(dim);++it)
  {
    ent = *it;
    if (ent->getOwner()==ParUtil::Instance()->rank())
      numEnt++;
  }
  
  for (unsigned int pid=0;pid<numPE;++pid)
  {
    if ((unsigned int)ParUtil::Instance()->rank() != pid)
    {
      senddata = (int*)AP_alloc(pid,554,sizeof(int)*(2));
      senddata[0]=ParUtil::Instance()->rank();
      senddata[1]=numEnt;
      AP_send(senddata);
      sendcounts[pid]++;      
    }
  }
  
  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts);

  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  int message=0;
  int count;
  while(!AP_recv_count(&count)||message<count)
  {
    int from,tag,size,rc;
  // receive phase begins
    rc=AP_recv(MPI_ANY_SOURCE,554,AP_BLOCKING|AP_DROPOUT,
               (void**)&recvdata,&size,&from,&tag);
    if (rc)
    {
      message++;
      output[recvdata[0]] = recvdata[1];
      AP_free(recvdata);
    }  // if(rc)
  } // while
  AP_check_sends(AP_WAITALL);
  delete [] sendcounts;
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);

  output[ParUtil::Instance()->rank()] = numEnt;
//  for (unsigned int i=0; i<output.size();++i)
//    cout<<"("<<P_pid()<<") output[pid="<<i<<", dim="<<dim<<" = "<<output[i]<<endl;  
#else
  output.push_back(mesh->size(dim));
#endif
}

void M_numEntities(pMesh mesh, int dim, vector<int>& output)
{
#ifdef PARALLEL
  unsigned int numPE = ParUtil::Instance()->size();
  output.resize(numPE);
  int* senddata;
  int* recvdata;

  // send phase begins
  int* sendcounts=new int[numPE];
  for (unsigned int i=0;i<numPE;++i) sendcounts[i]=0;
 

  for (unsigned int pid=0;pid<numPE;++pid)
  {
    if ((unsigned int)ParUtil::Instance()->rank() != pid)
    {
      senddata = (int*)AP_alloc(pid,554,sizeof(int)*(2));
      senddata[0]=ParUtil::Instance()->rank();
      senddata[1]=mesh->size(dim);
      AP_send(senddata);
      sendcounts[pid]++;      
    }
  }
  
  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts);

  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  int message=0;
  int count;
  while(!AP_recv_count(&count)||message<count)
  {
    int from,tag,size,rc;
  // receive phase begins
    rc=AP_recv(MPI_ANY_SOURCE,554,AP_BLOCKING|AP_DROPOUT,
               (void**)&recvdata,&size,&from,&tag);
    if (rc)
    {
      message++;
      output[recvdata[0]] = recvdata[1];
      AP_free(recvdata);
    }  // if(rc)
  } // while
  AP_check_sends(AP_WAITALL);
  delete [] sendcounts;
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);

  output[ParUtil::Instance()->rank()] = mesh->size(dim);
//  for (unsigned int i=0; i<output.size();++i)
//    cout<<"("<<P_pid()<<") output[pid="<<i<<", dim="<<dim<<" = "<<output[i]<<endl;  
#else
  output.push_back(mesh->size(dim));
#endif
}

void M_updateOwnership(pMesh mesh)
{ 
#ifdef PARALLEL
  if (M_NumPE()==1)
    return;
#ifdef _DEBUG
  double t1 = ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n****************************\n");
  ParUtil::Instance()->Msg(ParUtil::INFO,"    M_updateOwnership...\n");
#endif
  pmModel::Instance()->Instance()->updateOwnership();
#ifdef _DEBUG
  double t2 = ParUtil::Instance()->wTime();      
  ParUtil::Instance()->Msg(ParUtil::INFO,
          "      (t = %f sec)\n",t2-t1);
  ParUtil::Instance()->Msg(ParUtil::INFO,"****************************\n\n");	  
#endif
#endif
  return;
}

void DMUM_startMonitoring(pMesh mesh)
{ 
#ifdef DMUM
  mDMUM::Instance()->startMonitor((mMesh*)mesh); 
  if (!P_pid()) system("rm mRep.dat");
#else 
  if (!P_pid())   cout<<"AOMD ERROR: Compile AOMD with DMUM=1\n";
#endif  
}

void DMUM_stopMonitoring(pMesh mesh)
{
#ifdef DMUM
  mDMUM::Instance()->stopMonitor((mMesh*)mesh); 
  mDMUM::Instance()->write(mesh, "mRep.dat");
#else 
  if (!P_pid())   cout<<"AOMD ERROR: Compile AOMD with DMUM=1\n";
#endif
}

void DMUM_resumeMonitoring(pMesh mesh)
{  
#ifdef DMUM
  mDMUM::Instance()->resumeMonitor((mMesh*)mesh); 
#else 
  if (!P_pid())   cout<<"AOMD ERROR: Compile AOMD with DMUM=1\n";
#endif
}

void DMUM_pauseMonitoring(pMesh mesh)
{  
#ifdef DMUM
  mDMUM::Instance()->pauseMonitor((mMesh*)mesh); 
#else 
  if (!P_pid())   cout<<"AOMD ERROR: Compile AOMD with DMUM=1\n";
#endif
}

void DMUM_print(pMesh mesh)
{
#ifdef DMUM
  mDMUM::Instance()->print((mMesh*)mesh); 
#else 
  if (!P_pid()) cout<<"AOMD ERROR: Compile AOMD with DMUM=1\n";
#endif
}

bool DMUM_isOn(pMesh mesh)
{
#ifdef DMUM
  return (mMesh*)mesh->DMUM_on; 
#else
  return false;
#endif
}


#endif   /* ifndef SIM */
