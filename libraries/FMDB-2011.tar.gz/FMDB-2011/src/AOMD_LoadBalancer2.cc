/******************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*********************************************************************************/
#ifdef PARALLEL

#include <stdio.h>
#include <iostream>
#include <assert.h>
#include "AOMD_LoadBalancer.h"
#include "mMigrateUtil.h"
#include "mMesh.h"
#include "mEntity.h"
#include "mVertex.h"
#include "mEdge.h"
#include "mRegion.h"
#include "ParUtil.h"
#include "pmGraphs.h"
#include "mAOMD.h"
#include "AOMD_OwnerManager.h"
#include "AOMD_Internals.h"
#include "autopack.h"
#include "mExchangeData.h"

using std::vector;
using std::set;
using std::cout;
using std::pair;
using std::endl;
using std::list;
	       
namespace AOMD {

const int VERTEX_TRACK_ID = 6469;

int mMesh::loadBalance_oneLevel(AOMD_LoadBalancerCallbacks &cb, int from, int to)
{
  return loadBalance2(cb,from,to);
}

int mMesh::loadBalance2(AOMD_LoadBalancerCallbacks &cb, int from, int to)
{

  cout<<"("<<M_Pid()<<") mesh size(3)="<<size(3)<<endl;
  list<mEntity*> vtToRemove; 
  list<mEntity*> egToRemove;
  list<mEntity*> fcToRemove;
  list<mEntity*> rgToRemove;
  vector<mEntity*> newE;

  ParUtil::Instance()->Barrier(__LINE__,__FILE__); 
  int n = from;

  double t1,t2;
  
  t1=ParUtil::Instance()->wTime();
  
  cout<<"("<<M_Pid()<<") build graph for parmetis\n";
  AOMD_distributed_graph g(this,from,to,&cb,0);
  cout<<"("<<M_Pid()<<") done building graph\n";
  int *partitionVector = new int[g.theGraph->nn];
  cb.partition(g,partitionVector);
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* (%d) %f (sec) getting partitionVector from parmetis\n",ParUtil::Instance()->rank(),t2-t1);
  
  int initial_id = g.vtxdist[ParUtil::Instance()->rank()];
  list<mEntity *> toDelete;
//  CreateMigrationVectors (this,partitionVector,initial_id,from,0,toDelete,cb.nbProcs());
  if (from==3)
    CreateMigrationVectors_oneLevel(this,partitionVector,initial_id,from,0,rgToRemove,
                           ParUtil::Instance()->size());
  else if (from==2)
    CreateMigrationVectors_oneLevel(this,partitionVector,initial_id,from,0,fcToRemove,
                           ParUtil::Instance()->size());
  t1=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) marking entities to move\n",t1-t2);
//  printf("\n\t(%d) CreateMigrationVectors\n",ParUtil::Instance()->rank());

  ParallelReclassifyMeshEntities(n);  

  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* (%d) %f (sec) set common bdry\n",ParUtil::Instance()->rank(),t2-t1);

  int *sendcounts = new int[ParUtil::Instance()->size()];
  t1 = ParUtil::Instance()->wTime();
  for(int dim = 0; dim <= n; dim++)
  {
    ParUtil::Instance()->Barrier(__LINE__,__FILE__);
    for(int i=0;i<ParUtil::Instance()->size();i++)
      sendcounts[i]=0;
    for(mMesh::iter it = begin(dim) ; it!= end(dim) ; ++it)
    {
      mEntity *e = *it;
	  	  
      for(int dest=0;dest<getNbDests(e);dest++)
      {	      
        int part = getDest(e,dest);
	      
	if(part != ParUtil::Instance()->rank())
	{
          void *buf = packMeshEntity(e,part,cb);
	  AP_send(buf);
	  sendcounts[part] ++;
        }
      }
    }
    
    AP_check_sends(AP_NOFLAGS);
    AP_reduce_nsends(sendcounts);
    int message=0;
    int count;

    while (!AP_recv_count(&count) || message<count) 
    {  
      void *msg;
      int from, tag, size, rc;
      rc=AP_recv(MPI_ANY_SOURCE, MPI_ANY_TAG, AP_BLOCKING|AP_DROPOUT,
  	         &msg, &size, &from, &tag);
      if (rc && (tag == TAGVERTEX || tag == TAGNONVERTEX)) 
      {
        message++;
        unpackMeshEntity_oneLevel(msg,from,tag,cb,-1,newE);
        AP_free(msg);
      }
    }
    AP_check_sends(AP_WAITALL); 
    ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  }
  int localMoved;
  if (from==3)
    localMoved = rgToRemove.size();
  else if (from==2)
    localMoved=fcToRemove.size();
  int totalMoved;
  MPI_Allreduce(&localMoved,&totalMoved,1,MPI_INT,MPI_SUM,
                MPI_COMM_WORLD);
 
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) communication to exchange entities\n",t2-t1);
    if (from==3)
    removeEntities(this,from,rgToRemove);
  else
    removeEntities(this,from,fcToRemove);
 
  getEntitiesToRemove(from, vtToRemove, egToRemove, fcToRemove);
  if (from==3)
    removeEntities(this,2,fcToRemove);
 
  removeEntities(this,1,egToRemove);
  removeEntities(this,0,vtToRemove);
 
  t1=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) remove entities\n",t1-t2);
 
  bdryLinkSetup();
//cout<<"("<<M_Pid()<<") bdryLinkSetup \n";
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) bdryLinkSetup\n",t2-t1);
 
   delete [] sendcounts;
  delete [] partitionVector;

  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  unsigned int tagMark = AOMD_Util::Instance()->lookupMeshDataId("_dest");
  for(int i=0;i<4;i++)
    for(mMesh::iterall it = beginall(i) ; it!= endall(i) ; ++it)
      (*it)->deleteData(tagMark);
 
  t1=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) delete attached dest pid\n",t1-t2);
 
  return totalMoved;
}

int mMesh::loadBalance_fast(AOMD_LoadBalancerCallbacks &cb, int from, int to)
{

  cout<<"("<<M_Pid()<<") mesh size(3)="<<size(3)<<endl;
  list<mEntity*> vtToRemove; 
  list<mEntity*> egToRemove;
  list<mEntity*> fcToRemove;
  list<mEntity*> rgToRemove;
  vector<mEntity*> newE;

  ParUtil::Instance()->Barrier(__LINE__,__FILE__); 
  int n = from;
  double t1,t2;
  
  int localRg=numUniqueEntities(3);
  int localFc=numUniqueEntities(2);
  int localEg=numUniqueEntities(1);
  int localVt=numUniqueEntities(0);
  int localEnt=localRg+localFc+localEg+localVt;
  int totalBfEnt;
  MPI_Allreduce(&localEnt,&totalBfEnt,1,MPI_INT,MPI_SUM,
		MPI_COMM_WORLD);
		
		
  t1=ParUtil::Instance()->wTime();
  
 // ********************************************
// STEP 1: BUILD A GRAPH
// ********************************************  

  cout<<"("<<M_Pid()<<") build graph for parmetis\n";
  AOMD_distributed_graph g(this,from,to,&cb,0);
  cout<<"("<<M_Pid()<<") done building graph\n";

// ********************************************
// STEP 2: BUILD A Partition Vector
// ********************************************  
  int *partitionVector = new int[g.theGraph->nn];
  cb.partition(g,partitionVector);
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* (%d) %f (sec) getting partitionVector from parmetis\n",ParUtil::Instance()->rank(),t2-t1);
  
  int initial_id = g.vtxdist[ParUtil::Instance()->rank()];
  list<mEntity *> toDelete;

// ****************************************
// STEP 4: Mark entities to Move
// ****************************************
//  CreateMigrationVectors (this,partitionVector,initial_id,from,0,toDelete,cb.nbProcs());
  if (from==3)
    CreateMigrationVectors_oneLevel(this,partitionVector,initial_id,from,0,rgToRemove,
                           ParUtil::Instance()->size());
  else if (from==2)
    CreateMigrationVectors_oneLevel(this,partitionVector,initial_id,from,0,fcToRemove,
                           ParUtil::Instance()->size());
  t1=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) marking entities to move\n",t1-t2);
//  printf("\n\t(%d) CreateMigrationVectors\n",ParUtil::Instance()->rank());

// ********************************************
// STEP 5: Set CB and collect entities to move
// ******************************************** 
  ParallelReclassifyMeshEntities(n);  

  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* (%d) %f (sec) set common bdry\n",ParUtil::Instance()->rank(),t2-t1);

// ********************************************
// STEP 6: Migrate entities
// ********************************************  
  int *sendcounts = new int[ParUtil::Instance()->size()];
  t1 = ParUtil::Instance()->wTime();
  for(int dim = 0; dim <= n; dim++)
  {
    ParUtil::Instance()->Barrier(__LINE__,__FILE__);
    for(int i=0;i<ParUtil::Instance()->size();i++)
      sendcounts[i]=0;
    for(mMesh::iter it = begin(dim) ; it!= end(dim) ; ++it)
    {
      mEntity *e = *it;
	  	  
      for(int dest=0;dest<getNbDests(e);dest++)
      {	      
        int part = getDest(e,dest);
	      
	if(part != ParUtil::Instance()->rank())
	{
          void *buf = packMeshEntity(e,part,cb);
	  AP_send(buf);
	  sendcounts[part] ++;
        }
      }
    }
    
    AP_check_sends(AP_NOFLAGS);
    AP_reduce_nsends(sendcounts);
    int message=0;
    int count;

    while (!AP_recv_count(&count) || message<count) 
    {  
      void *msg;
      int from, tag, size, rc;
      rc=AP_recv(MPI_ANY_SOURCE, MPI_ANY_TAG, AP_BLOCKING|AP_DROPOUT,
  	         &msg, &size, &from, &tag);
      if (rc && (tag == TAGVERTEX || tag == TAGNONVERTEX)) 
      {
        message++;
        unpackMeshEntity_oneLevel(msg,from,tag,cb,-1,newE);
        AP_free(msg);
      }
    }
    AP_check_sends(AP_WAITALL); 
    ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  }

// ********************************************
// STEP 7: compute # entities migrated
// ********************************************  
  int localMoved;
  if (from==3)
    localMoved = rgToRemove.size();
  else if (from==2)
    localMoved=fcToRemove.size();
  int totalMoved;
  MPI_Allreduce(&localMoved,&totalMoved,1,MPI_INT,MPI_SUM,
                MPI_COMM_WORLD);
 
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) communication to exchange entities\n",t2-t1);

// ********************************************
// STEP 8: remove migrated partition objects
// ********************************************  
  if (from==3)
    removeEntities(this,from,rgToRemove);
  else
    removeEntities(this,from,fcToRemove);

// ********************************************
// STEP 9: collect entities to remove
// ********************************************  
  getEntitiesToRemove(from, vtToRemove, egToRemove, fcToRemove);

// ********************************************
// STEP 10: remove entities
// ********************************************  
  if (from==3)
    removeEntities(this,2,fcToRemove);
 
  removeEntities(this,1,egToRemove);
  removeEntities(this,0,vtToRemove);
 
  t1=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) remove entities\n",t1-t2);

// ********************************************
// STEP 11: common boundary setup
// ********************************************  
  bdryLinkSetup();
//cout<<"("<<M_Pid()<<") bdryLinkSetup \n";
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) bdryLinkSetup\n",t2-t1);
 
  delete [] sendcounts;
  delete [] partitionVector;

// ********************************************
// STEP 12: remove attached pid
// ********************************************  
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  unsigned int tagMark = AOMD_Util::Instance()->lookupMeshDataId("_dest");
  for(int i=0;i<4;i++)
    for(mMesh::iterall it = beginall(i) ; it!= endall(i) ; ++it)
      (*it)->deleteData(tagMark);
 
  t1=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) delete attached dest pid\n",t1-t2);

  localRg=numUniqueEntities(3);
  localFc=numUniqueEntities(2);
  localEg=numUniqueEntities(1);
  localVt=numUniqueEntities(0);
  localEnt=localRg+localFc+localEg+localVt;
  int totalAfEnt;
  MPI_Allreduce(&localEnt,&totalAfEnt,1,MPI_INT,MPI_SUM,
		MPI_COMM_WORLD);
  assert(totalAfEnt==totalBfEnt);	
  ParUtil::Instance()->Msg(ParUtil::INFO,"SUCCEED assert(totalAfEnt==totalBfEnt)\n"); 

  return totalMoved;
}

int mMesh::loadBalance_updateAdj(AOMD_LoadBalancerCallbacks &cb, int from, int to)
{
  int totalMoved = 0;
  ParUtil::Instance()->Barrier(__LINE__,__FILE__); 
  int n = from;
  AOMD_distributed_graph g(this,from,to,&cb,0);
  int *partitionVector = new int[g.theGraph->nn];
  cb.partition(g,partitionVector);

  int initial_id = g.vtxdist[ParUtil::Instance()->rank()];
  list<mEntity *> toDelete;
  CreateMigrationVectors (this,partitionVector,initial_id,from,0,toDelete,cb.nbProcs());
  ParallelReclassifyMeshEntities(n);  
#ifdef PARALLEL /// migration phase uniquely in parallel
  int *sendcounts = new int[ParUtil::Instance()->size()];

  for(int dim = 0; dim <= n; dim++)
  {
    ParUtil::Instance()->Barrier(__LINE__,__FILE__);
    for(int i=0;i<ParUtil::Instance()->size();i++)
      sendcounts[i]=0;
    for(mMesh::iter it = begin(dim) ; it!= end(dim) ; ++it)
    {
      mEntity *e = *it;
	  	  
      for(int dest=0;dest<getNbDests(e);dest++)
      {	      
        int part = getDest(e,dest);
	      
	if(part != ParUtil::Instance()->rank())
	{
          void *buf = packMeshEntity(e,part,cb);
	  AP_send(buf);
	  sendcounts[part] ++;
        }
      }
    }
    
    AP_check_sends(AP_NOFLAGS);
    AP_reduce_nsends(sendcounts);
    int message=0;
    int count;

    while (!AP_recv_count(&count) || message<count) 
    {  
      void *msg;
      int from, tag, size, rc;
      rc=AP_recv(MPI_ANY_SOURCE, MPI_ANY_TAG, AP_BLOCKING|AP_DROPOUT,
  	         &msg, &size, &from, &tag);
      if (rc && (tag == TAGVERTEX || tag == TAGNONVERTEX)) 
      {
        message++;
        unpackMeshEntity(msg,from,tag,cb);
        AP_free(msg);
      }
    }
    AP_check_sends(AP_WAITALL); 
    ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  }

  int localMoved = toDelete.size();
  MPI_Allreduce(&localMoved,&totalMoved,1,MPI_INT,MPI_SUM,
		MPI_COMM_WORLD);
  
  for(list<mEntity *>::const_iterator it = toDelete.begin();
      it != toDelete.end();++it)
  {
    DEL_updateAdj(*it);
  }
  
  modifyState(from,to,true);

  if(from == 3)
  {
    modifyState(2,1,true);
    modifyState(3,1,true);
  }

  cleanup_updateAdj(from);

  modifyState(to,from,false);
  modifyState(to,from,true);

  bdryLinkSetup();
 
  delete [] sendcounts;
  delete [] partitionVector;

  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  unsigned int tagMark = AOMD_Util::Instance()->lookupMeshDataId("_dest");
  for(int i=0;i<4;i++)
    for(mMesh::iterall it = beginall(i) ; it!= endall(i) ; ++it)
      (*it)->deleteData(tagMark); 
#endif
  return totalMoved;
}

} // end of namespace
#endif
