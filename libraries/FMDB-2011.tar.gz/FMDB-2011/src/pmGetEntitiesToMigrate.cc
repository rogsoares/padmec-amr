/******************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*********************************************************************************/

/*<i> ****************************************************************************
 *
 *  AOMD/pmodel/pmMigrateUtil.cc
 *  Created by Seegyoung Seol, on Mon Sep 30 2003, 10:26:37 EDT
 *
 *  File Content: operators that collect entities to migrate for
 *  		   - load balancing
 *		   - coarsening & removing sliver regions
 *		   - snapping
 *
 *************************************************************************** </i>*/
 
#ifdef PARALLEL

#include <stdio.h>
#include <iostream>
#include <assert.h>
#include <list>
#include <set>
#include <map>
#include <vector>
#include "pmMigrateUtil.h"
#include "pmUtility.h"
#include "pmModel.h"
#include "mEntity.h"
#include "mAOMD.h"
#include "AOMD.h"
#include "ParUtil.h"
#include "autopack.h"
#include "AOMD_cint.h"
#include "AOMD.h"
#include "pmModelUtil.h"
#include "mAttachableDataContainer.h"
using std::cout;
using std::endl;
using std::list;
using std::pair;
using std::vector;
using std::map;
using std::set;

namespace AOMD {

// ***********************************************************
void getPOsToMoveFromPartitionVector(mMesh *mesh, int from,
                		int *partitionVector, int delta_id, 
				map<mEntity*, int>& entitiesToMove)
// ***********************************************************
{
  int pid;
  mEntity* ent;
  for(mMesh::iterall it = mesh->beginall(from) ; it!= mesh->endall(from) ; ++it)
  {      
    ent = *it;
    int id = ent->getAttachedInt(AOMD_Util::Instance()->getId()) - delta_id;
    pid = partitionVector[id];
    if (ParUtil::Instance()->rank()!=pid)
      entitiesToMove.insert(entityPidMap::value_type(ent,pid));
  }
}

// ***********************************************************
void unifyEntitiesToMove(mMesh* mesh,list<mEntity*>& entities)
// ***********************************************************
{
  // unify entities container
  mEntity* ent;
  list<mEntity*>::iterator it_ent = entities.begin(); 
  // one round of communication
  int* sendcounts = new int[ParUtil::Instance()->size()];
  for (int i=0; i<ParUtil::Instance()->size(); ++i) sendcounts[i]=0;

  for (; it_ent!=entities.end();++it_ent)
  {
    ent = (*it_ent);
    for (mEntity::RCIter rciter=ent->rcBegin();rciter!=ent->rcEnd();++rciter)
    {  
      void* buf = AP_alloc(rciter->first, 445, sizeof(mEnt_struct));
      mEnt_struct* castbuf = (mEnt_struct*)buf;
      castbuf->entity = rciter->second;
      AP_send(buf);
      sendcounts[rciter->first]++;
    }
  }
 
  // receive phase begins
  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts);
  int message=0;
  int count;
  bool flag;
  int counter=0;
  while(!AP_recv_count(&count) || message<count)
  {
    void* msg;
    int from, tag, size, rc;
    rc = AP_recv(MPI_ANY_SOURCE, 445, AP_BLOCKING|AP_DROPOUT, &msg, &size, &from, &tag);
    if (rc)
    {
      message++;
      mEnt_struct* castbuf = (mEnt_struct*) msg;
      mEntity* recvEnt=castbuf->entity;
      flag=false;
      if ((recvEnt->getLevel()==0 &&
           recvEnt->getOwner()!=ParUtil::Instance()->rank())
           || (recvEnt->getLevel()==1))
        flag=true;
      if (flag)
      {
        entities.push_back(recvEnt);
	counter++;
      }
      AP_free(msg);
    }  // end of if (rc)
  }  // end of while(!AP...)
  entities.unique();
//  cout<<"("<<ParUtil::Instance()->rank()<<") entitiesToMove.add(counter="<<counter<<") \n"; 
  AP_check_sends(AP_WAITALL);
  delete[] sendcounts;
}

// ***********************************************************
void getPOsToMove(mMesh* mesh, 
		list<mEntity*>& entities,int ent_dim,
		map<mEntity*, int>& entitiesToMove)
// ***********************************************************
{
  int mypid=ParUtil::Instance()->rank();

  vector<int> sortedPids;
  getSortedPids_poor_to_rich(mesh,sortedPids);
/*
  if (ParUtil::Instance()->master())
  {  cout<<"\t* POOR TO RICH PIDS: ";
    for (vector<int>::iterator pidIter=sortedPids.begin(); 
        pidIter!=sortedPids.end();++pidIter)
       cout<<"P"<<*pidIter<<" -> ";
    cout<<"\n";
  }
*/
  
  vector<mEntity*>* vertices = new vector<mEntity*>[P_size()];
  vector<mEntity*>::iterator viter;
  list<mEntity*>::iterator vit=entities.begin();
  
  mEntity *v, *r;
  
  int dim=M_globalMaxDim(mesh);
  int owner;
  bool reset;

  int* sendcounts = new int[ParUtil::Instance()->size()];
  for (int i=0; i<ParUtil::Instance()->size(); ++i) sendcounts[i]=0;
  
  unsigned int tagId= MD_lookupMeshDataId("visited"); 
  for (;vit!=entities.end();++vit)
  {
    v=*vit;
    if (v->getAttachedInt(tagId)) continue;
    vertices[v->getOwner()].push_back(v);
    v->attachInt(tagId,1);
  }  

  for (vit=entities.begin();vit!=entities.end();++vit)
    (*vit)->deleteData(tagId);
    
  for (vector<int>::iterator piter=sortedPids.begin();
      piter!=sortedPids.end();++piter)
  {
    owner = *piter;
 //   cout<<"("<<mypid<<") process v owned by P"<<owner<<endl;
    if (owner==mypid)
      continue;
    for (viter=vertices[owner].begin();viter!=vertices[owner].end();++viter)
    {
      v = *viter;
      AOMD::mAdjacencyContainer upward;
      v->getHigherOrderUpward(dim,upward);
      reset=false;
      for (int i=0; i<upward.size();++i)
      {
        r = upward[i];
        if (entitiesToMove.find(r)==entitiesToMove.end())
	  entitiesToMove.insert(entityPidMap::value_type(r,owner));
	else if (entitiesToMove[r]!=owner) // already processed by high priority pid
	{ 
	  reset=true;  
//	  cout<<"("<<mypid 
//	    <<") AOMD INFO: undo migration with V"<<v->getId()
//	    <<" to P"<<owner<<" due to P"<<entitiesToMove[r]<<endl;
	  break; 
	}
      }
      
      if(reset)
      {
        // undo setting regions to migrate
	for (int i=0; i<upward.size();++i)
	
        {
          r = upward[i];
	  if (entitiesToMove.find(r)!=entitiesToMove.end() &&
	      entitiesToMove[r]==owner)
	    entitiesToMove.erase(entityPidMap::key_type(r));  
        }
	// send message to remote copies
        for (mEntity::RCIter rciter=v->rcBegin();rciter!=v->rcEnd();++rciter)
        {  
	  if (rciter->first==owner) continue;
          void* buf = AP_alloc(rciter->first, 5000, sizeof(mEnt_struct));
          mEnt_struct* castbuf = (mEnt_struct*)buf;
          castbuf->entity = rciter->second;
          AP_send(buf);
          sendcounts[rciter->first]++;
        }
      } // if (reset)
    } // for vertices[*piter]
  }  // for sorted Pids
  delete [] vertices;

  // receive phase begins
  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts);
  int message=0;
  int count;
  while(!AP_recv_count(&count) || message<count)
  {
    void* msg;
    int from, tag, size, rc;
    rc = AP_recv(MPI_ANY_SOURCE, 5000, AP_BLOCKING|AP_DROPOUT, &msg, &size, &from, &tag);
    if (rc)
    {
      message++;
      mEnt_struct* castbuf = (mEnt_struct*) msg;
      mEntity* recvEnt=castbuf->entity;
      owner = recvEnt->getOwner();
//      cout<<"("<<mypid 
//	    <<") AOMD INFO: (recv msg) undo migration from V"<<v->getId()
//	    <<"(owner="<<owner<<")"<<endl;
      AOMD::mAdjacencyContainer upward;
      recvEnt->getHigherOrderUpward(dim,upward);

      for (int i=0; i<upward.size();++i)
      {
        r = upward[i];
        if (entitiesToMove.find(r)!=entitiesToMove.end() &&
	        entitiesToMove[r]==owner)
	    entitiesToMove.erase(entityPidMap::key_type(r));
      } 
      AP_free(msg);
    }  // end of if (rc)
  }  // end of while(!AP...)

  AP_check_sends(AP_WAITALL);
  delete[] sendcounts;
}

// called by M_migrationForSnap
// ***********************************************************
void getEntitiesToMove(mMesh* mesh, std::list<mEntity*>& vtsOnCB, 
		      std::list<std::pair<mEntity*,mEntity*> > &vtfcPairs,
		      std::map<mEntity*,int>& entitiesToMove)
// ***********************************************************
{
  // process the list of vertices on CB due to priority
  getPOsToMove(mesh,vtsOnCB,0,entitiesToMove);

  // process the list of pairs 
  std::list<std::pair<mEntity*,mEntity*> >::iterator pit;
  mEntity *v1,*v2,*v3,*face,*edge;
  int pid;
  int mypid=ParUtil::Instance()->rank();
  int dim=M_globalMaxDim(mesh);
  void *iter;
  assert(dim==3);
  
  int* sendcounts = new int[ParUtil::Instance()->size()];
  for (int i=0; i<ParUtil::Instance()->size(); ++i) sendcounts[i]=0;

  // process vertices+faces pair 
  for (pit=vtfcPairs.begin();pit!=vtfcPairs.end();++pit)
  {
    pPList vertices;
    switch( EN_type(pit->second) ) {
    case 2:
      face=(pFace)pit->second;
      vertices=F_vertices(face,1);
      break;
    case 1:
      edge=(pEdge)pit->second;
      vertices=PList_new();
      PList_append(vertices,E_vertex(edge,0));
      PList_append(vertices,E_vertex(edge,1));
      break;
    case 0:
      vertices=PList_new();
      PList_append(vertices,pit->second);
      break;
    default:
      throw;
    }
    pPList cbVtList=PList_new();
    void *iter=0;
    while( v3=(pEntity)PList_next(vertices,&iter) ) 
    {  
      // if any of vertices are on CB, ignore pair
      if (find(vtsOnCB.begin(),vtsOnCB.end(),v3)!=vtsOnCB.end())
	continue;
      if( EN_duplicate((pEntity)v3) )
	PList_append(cbVtList,v3);
    }
    PList_delete(vertices);

    // send message to counterpart
    iter=0;
    while( v3=(pEntity)PList_next(cbVtList,&iter) ) {  

      for (mEntity::RCIter rciter=v3->rcBegin();rciter!=v3->rcEnd();++rciter)
      {
        void* buf = AP_alloc(rciter->first, 5000, sizeof(mEnt_struct));
        mEnt_struct* castbuf = (mEnt_struct*)buf;
        castbuf->entity = rciter->second;
        AP_send(buf);
        sendcounts[rciter->first]++;
      }
    }
    PList_delete(cbVtList);
  }

  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts);
  pRegion rgn;
  int message=0;
  int count;

  while(!AP_recv_count(&count) || message<count)
  {
    void* msg;
    int from, tag, size, rc;
    rc = AP_recv(MPI_ANY_SOURCE, 5000, AP_BLOCKING|AP_DROPOUT, &msg, &size, &from, &tag);
    if (rc)
    {
      message++;
      mEnt_struct* castbuf = (mEnt_struct*) msg;
      pPList rgns=V_regions((pVertex)castbuf->entity);
      iter=0;
      while( rgn=(pRegion)PList_next(rgns,&iter) ) {	
        entitiesToMove.insert(entityPidMap::value_type(rgn,from));
        if (entitiesToMove[rgn] != from)
	  cout<<"AOMD WARNING: destination pid of "<<rgn->getUid()<<" conflicts "<<endl;
      }
      PList_delete(rgns);
      AP_free(msg);
    }  // end of if (rc)
  }  // end of while(!AP...)
 
  AP_check_sends(AP_WAITALL);
  delete[] sendcounts;	
}

// called by M_migrationForSnap
// ***********************************************************
void getPOsToMoveForSnap(mMesh* mesh, std::list<mEntity*>& vtsOnCB, 
		      std::list<std::pair<mEntity*,mEntity*> > &vtfcPairs,
		      std::map<mEntity*,int>& entitiesToMove)
// ***********************************************************
{
  mEntity *vt, *orgVt, *rgn;
  int pid;
  int mypid=ParUtil::Instance()->rank();
  int numPtn=ParUtil::Instance()->size();
  int dim=M_globalMaxDim(mesh);
  void* iter=0;
  assert(dim==3);
  
  // STEP 1: Collect pairs to process considering CASE 2 
  // CASE 2: If vertices/pb_face is found on vtsOnCB container, 
  //         the vtFcPair shoule be given up
  map<mEntity*, vector<mEntity*> > pairToProcess;
  for (std::list<std::pair<mEntity*,mEntity*> >::iterator pit=vtfcPairs.begin();
      pit!=vtfcPairs.end();++pit)
  { 
    switch (pit->second->getLevel())
    {
      case 2: if (find(vtsOnCB.begin(),vtsOnCB.end(),F_vertex((pFace)pit->second,0))
	                !=vtsOnCB.end() &&
		 find(vtsOnCB.begin(),vtsOnCB.end(),F_vertex((pFace)pit->second,1))
	                !=vtsOnCB.end() &&
		 find(vtsOnCB.begin(),vtsOnCB.end(),F_vertex((pFace)pit->second,1))
	                !=vtsOnCB.end())
             {
	       pairToProcess[pit->first].push_back(F_vertex((pFace)pit->second,0));
	       pairToProcess[pit->first].push_back(F_vertex((pFace)pit->second,1));
	       pairToProcess[pit->first].push_back(F_vertex((pFace)pit->second,2));
             }
	     break; // exit switch
      case 1: if (find(vtsOnCB.begin(),vtsOnCB.end(),E_vertex((pEdge)pit->second,0))
	                !=vtsOnCB.end() &&
		 find(vtsOnCB.begin(),vtsOnCB.end(),E_vertex((pEdge)pit->second,1))
	                !=vtsOnCB.end())
	     {
	       pairToProcess[pit->first].push_back(E_vertex((pEdge)pit->second,0));
      	       pairToProcess[pit->first].push_back(E_vertex((pEdge)pit->second,1));
	     }
	     break; // exit switch
       case 0: if (find(vtsOnCB.begin(),vtsOnCB.end(),pit->second)!=vtsOnCB.end())
                 pairToProcess[pit->first].push_back(pit->second);
  	      break; // exit for switch
    } // switch
  } // for pit
#ifdef DEBUG_    
  cout<<"("<<mypid<<") done STEP 1\n";
#endif
  // STEP 2: First, process the list of vertices on CB due to priority 
  //         while considering CASE 1.
  // CASE 1: if conflicts between CB vertices ito dpids, 
  //         adjust them based on poor-to-rich rule to repect the cavity for snapping
  getPOsToMove(mesh,vtsOnCB,0,entitiesToMove);
#ifdef DEBUG_
  cout<<"("<<mypid<<") done STEP 2\n";
#endif  
  // Second, process the list of pairs 

  
  // it contains vertex to process and origin vertex requesting in 
  //  verticesToProcess[dpid] where dpid is the local pid of origin vertex
  vector<pair<mEntity*, mEntity*> > verticesToProcess[numPtn];
  vector<pair<mEntity*, mEntity*> > ::iterator vecpairit;
  vector<mEntity*>::iterator vecit;
  
  // STEP 3: SEND msg (vt, orgVt, localPid) to remote copies of vt
  //         and While RECIEVE, store msg into verticesToProcess[from]
  int* sendcounts = new int[ParUtil::Instance()->size()];
  for (int i=0; i<numPtn; ++i) sendcounts[i]=0;
  for (map<mEntity*, vector<mEntity*> >::iterator mapit=pairToProcess.begin();
      mapit!=pairToProcess.end();++mapit)
  {
    // iterate over vertices
    orgVt = mapit->first;
    for (vecit=mapit->second.begin(); vecit!=mapit->second.end();++vecit)
    {  
      if ((*vecit)->getPClassification()) 
      {
        // if vertex/pb_face is on CB, send message to remote copy
	// asking adj regions of remote copy to this partition
        for (mEntity::RCIter rciter=(*vecit)->rcBegin();rciter!=(*vecit)->rcEnd();++rciter)
        {
          void* buf = AP_alloc(rciter->first, 5600, sizeof(mEnt_struct));
          mEnt2_struct* castbuf = (mEnt2_struct*)buf;
          castbuf->ent1 = rciter->second;
	  castbuf->ent2 = orgVt;
          AP_send(buf);
          sendcounts[rciter->first]++;
	}
      }
    }
  }
#ifdef DEBUG_
  cout<<"("<<mypid<<") done SEND\n";
#endif
  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts);
  int message=0;
  int count;

  while(!AP_recv_count(&count) || message<count)
  {
    void* msg;
    int from, tag, size, rc;
    rc = AP_recv(MPI_ANY_SOURCE, 5600, AP_BLOCKING|AP_DROPOUT, &msg, &size, &from, &tag);
    if (rc)
    {
      message++;
      mEnt2_struct* castbuf = (mEnt2_struct*) msg;
      verticesToProcess[from].push_back(pair<mEntity*, mEntity*>(castbuf->ent1, castbuf->ent2));
      AP_free(msg);
    }  // end of if (rc)
  }  // end of while(!AP...)
  AP_check_sends(AP_WAITALL);
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);

#ifdef DEBUG_  
  cout<<"("<<mypid<<") done STEP 3\n";
#endif  
  // STEP 4: mark V_regions of vt in verticesToProcess[pid] where
  //         pid is processed from poor to rich partitions 
  //         if any rg is marked already by != pid, SEND msg back to (orgVt) on pid
  //         so as to while RECIEVE, cancel migration for orgVt to pid
  pMeshDataId undoMigr_tag=MD_newMeshDataId("undo migration");
  int tag_value;
  // get sorted pids from poor to rich
  vector<int> sortedPids;
  getSortedPids_poor_to_rich(mesh,sortedPids);
  
  for (vector<int>::iterator pidit=sortedPids.begin();
      pidit!=sortedPids.end();++pidit)
  {
    // wait for other processors to get started simultaneously
#ifdef DEBUG_  
    cout<<"("<<mypid<<") START to process verticesToProcess["<<*pidit<<"]\n";
#endif
    ParUtil::Instance()->Barrier(__LINE__,__FILE__);
    
    pid = *pidit;
//    if (pid==mypid) continue;
    // reset sendcounts
    for (int i=0; i<numPtn; ++i) sendcounts[i]=0;
    
    if (pid!=mypid) // no migration needed if pid==mypid
    {
      for (vecpairit=verticesToProcess[pid].begin();
          vecpairit!=verticesToProcess[pid].end();++vecpairit)
      {
        AOMD::mAdjacencyContainer upward;
        (vecpairit->first)->getHigherOrderUpward(dim,upward);
        pPList vrgns=V_regions((pVertex)vecpairit->first);
        bool reset = false;
        for (int i=0; i<upward.size();++i)
        {
          rgn = upward[i];
          if (entitiesToMove.find(rgn)==entitiesToMove.end())
	    entitiesToMove.insert(entityPidMap::value_type(rgn,pid));
          else
	  {
	    int compare = comparePid(mesh, entitiesToMove[rgn],pid);
	    // if already processed by high priority pid, undo pid
	    if (compare==1)
   	    {  
	      reset=true;  
//	  cout<<"("<<mypid 
//	    <<") AOMD INFO: undo migration with V"<<v->getId()
//	    <<" to P"<<owner<<" due to P"<<entitiesToMove[r]<<endl;
	      break; //exit for loop
	    }
	    else if (compare==-1)
	    {
              cout<<"("<<mypid<<" AOMD FATAL: Lower partition P"<<entitiesToMove[rgn]
	          <<" is set prior to P"<<pid<<" for "
		  <<rgn->getUid()<<endl;
  	      throw 1;//entitiesToMove[r] = pid;
	    }
          } // else
        } // for upward	
        if (reset)
        {
          // undo setting regions to migrate
	  for (int i=0; i<upward.size();++i)
	
          {
            rgn = upward[i];
  	  if (entitiesToMove.find(rgn)!=entitiesToMove.end() &&
	        entitiesToMove[rgn]==pid)
	      entitiesToMove.erase(entityPidMap::key_type(rgn));  
          }
	  // send message to orgVt to cancel migration for that
          void* buf = AP_alloc(pid, 5700, sizeof(mEnt_struct));
          mEnt_struct* castbuf = (mEnt_struct*)buf;
          castbuf->entity = vecpairit->second;
          AP_send(buf);
          sendcounts[pid]++;
        } // if (reset)
      } // for vertices[pid]
    } // if (pid!=mypid)
    // receive phase begins
    AP_check_sends(AP_NOFLAGS);
    AP_reduce_nsends(sendcounts);
    message=0;
    vector<mEntity*> undoEntities;
    
    while(!AP_recv_count(&count) || message<count)
    {
      void* msg;
      int from, tag, size, rc;
      rc = AP_recv(MPI_ANY_SOURCE, 5700, AP_BLOCKING|AP_DROPOUT, &msg, &size, &from, &tag);
      if (rc)
      {
        message++;
        mEnt_struct* castbuf = (mEnt_struct*) msg;
        // mark orgVt for undo migration;
        EN_attachDataInt(castbuf->entity, undoMigr_tag, from);
	undoEntities.push_back(castbuf->entity);
        AP_free(msg);
      }  // end of if (rc)
    }  // end of while(!AP...)
    AP_check_sends(AP_WAITALL);
      
    // reset sendcounts
    for (int i=0; i<numPtn; ++i) sendcounts[i]=0;
    for (vector<mEntity*>::iterator undoit = undoEntities.begin();
         undoit!=undoEntities.end(); ++undoit)
    {
      // iterate over vertices
      orgVt = *undoit;
      EN_getDataInt(orgVt, undoMigr_tag, &tag_value);
      // undo migration for this
      for (vecit=pairToProcess[orgVt].begin(); vecit!=pairToProcess[orgVt].end();++vecit)
      {  
        if ((*vecit)->getPClassification()) // send message
        {
          for (mEntity::RCIter rciter=(*vecit)->rcBegin();rciter!=(*vecit)->rcEnd();++rciter)
          {
            if (rciter->first == tag_value) continue;
	    void* buf = AP_alloc(rciter->first, 5800, sizeof(mEnt_struct));
            mEnt_struct* castbuf = (mEnt_struct*)buf;
            castbuf->entity = rciter->second;
            AP_send(buf);
            sendcounts[rciter->first]++;
          }
        }
      }
      EN_deleteData(orgVt, undoMigr_tag);
    } // for undoEntities

    AP_check_sends(AP_NOFLAGS);
    AP_reduce_nsends(sendcounts);
    message=0;
  
    while(!AP_recv_count(&count) || message<count)
    {
      void* msg;
      int from, tag, size, rc;
      rc = AP_recv(MPI_ANY_SOURCE, 5800, AP_BLOCKING|AP_DROPOUT, &msg, &size, &from, &tag);
      if (rc)
      {
        message++;
        mEnt_struct* castbuf = (mEnt_struct*) msg;
        AOMD::mAdjacencyContainer upward;
        castbuf->entity->getHigherOrderUpward(dim,upward);
        for (int i=0; i<upward.size();++i)
        {
          rgn = upward[i];
          if (entitiesToMove.find(rgn)!=entitiesToMove.end() && 
            entitiesToMove[rgn]==from)
            entitiesToMove.erase(entityPidMap::key_type(rgn));  
        }
        AP_free(msg);
      }  // end of if (rc)
    }  // end of while(!AP...)
    AP_check_sends(AP_WAITALL);
  }  // for pids from poor to rich

  MD_deleteMeshDataId(undoMigr_tag);
  delete[] sendcounts;

}

} // end of namespace
#endif /* PARALLEL */
