/**************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*****************************************************************************/

/*<i> ****************************************************************************
 *
 *  AOMD/src/mDebugUtil.cc
 *  Created by Seegyoung Seol, on Mon Dec 08 2003, 10:26:37 EDT
 *
 *  File Content:debug utility function definitions
 *
 *************************************************************************** </i>*/
 
#include <assert.h>
#include <iostream>
#include "mDebugUtil.h"
#include "mMesh.h"
#include "mEntity.h"
#include "mPoint.h"
#include "mVertex.h"
#include "mEdge.h"
#include "mFace.h"
#include "mTet.h"
#include "mHex.h"
#include "mPrism.h"
#include "mException.h"
#include "mAOMD.h"
#include "AOMD_Internals.h"
#include "AOMD_cint.h"
#include "ParUtil.h"
//#include "MeshTools.h"

#ifdef PARALLEL
#include"autopack.h"
#include "AOMD_OwnerManager.h"
#include "mCommonBdry.h"
#include "pmModel.h"
#include "pmUtility.h"
#endif

#include "modeler.h"

#include <stdlib.h>  
#include <math.h> 
#include <algorithm> 
#include <vector> 
#include <string> 
using std::cout;
using std::sort;
using std::set;
using std::list;
using std::string;
using std::vector;
using std::pair;
using std::endl;

namespace AOMD {

// ***********************************************************
bool verify_mesh(mMesh* mesh)
// ***********************************************************
{
  pmEntity* pe;
  mEntity* vertex;
  mEntity* edge;
  mEntity* face;
  mEntity* region;
  int gLevel;
  int manifold=1;
  int numAdjE;
  int numAdjF;
  int numAdjR;
  int mypid=P_pid();
  int meshDim = M_globalMaxDim(mesh);
  int ret=1; /* true */
  
#ifdef PARALLEL  // data for communication
  int numPtn = P_size();
  int sendcount=0;
  int recvcount=0;
  int numRC, pid;
  int* sendcounts=new int[numPtn];
  for (int i=0;i<numPtn;++i) sendcounts[i]=0;
#endif 


  // check vertices
  for (mMesh::iterall it=mesh->beginall(0); it!=mesh->endall(0);++it)
  {
    vertex = *it;
    numAdjE=V_numEdges(vertex);
    if (meshDim==3 && numAdjE<3)
    {  
      cout<<"("<<mypid<<") AOMD WARNING: "<<numAdjE<<" adj. edges with "<<vertex->getUid()<<endl;
      vertex->print();
      if (numAdjE==0) manifold=0;
    }
    if (meshDim==2 && numAdjE==0)
    {  
      cout<<"("<<mypid<<") AOMD WARNING: no adj. edges with "<<vertex->getUid()<<endl;
      vertex->print();
      manifold=0;
    }

    pe = vertex->getPClassification();
#ifndef PARALLEL 
    assert(!pe);
#else 
    numRC = vertex->getNumRemoteCopies();     
    if (!pe) // non-CB vertex
    {  
      if (numRC!=0) vertex->printRCs();
      assert(numRC==0);
      continue;
    }
    else  // CB vertex
    {
      if (numRC+1!=pe->getNumBPs())
      {
	vertex->printRCs();
	vertex->printBPs();
      }
      assert(numRC+1==pe->getNumBPs());
      for (mEntity::RCIter rciter = vertex->rcBegin();
          rciter!=vertex->rcEnd(); ++rciter)
      {
        pid = rciter->first;
        void* buf = AP_alloc(pid, 460, sizeof(int2_mEnt2_struct));
        int2_mEnt2_struct* castbuf = (int2_mEnt2_struct*)buf;
        castbuf->ent1 = vertex;
        castbuf->ent2 = rciter->second;
        castbuf->i=GEN_type(vertex->getClassification());
	castbuf->j=GEN_tag(vertex->getClassification());
        AP_send(buf);
	sendcount++;
        sendcounts[pid]++;
      } // for rciter
    } // else
#endif    
  }
  
  // check edges
  for (mMesh::iterall it=mesh->beginall(1); it!=mesh->endall(1);++it)
  {
    edge = *it;
    numAdjF = E_numFaces(edge);
    
    if (meshDim==3)
    {
      switch (numAdjF)
      { 
        case 0:
               cout<<"("<<mypid<<") AOMD WARNING: "<<E_numFaces(edge)<<" adj. faces with "<<edge->getUid()<<endl;
               edge->print();
	       manifold=0;
	       break;
        case 1: if (!EN_duplicate(edge))	       
               {
	         cout<<"("<<mypid<<") AOMD WARNING: "<<E_numFaces(edge)<<" adj. faces with "<<edge->getUid()<<endl;
                 edge->print();
	         manifold=0;
	       }
	       break;
        default: break;
      } 
      gLevel=GEN_type(edge->getClassification());
      if (gLevel==1 || gLevel==2)
      {
        int bf_counter=0; // number of boundary faces adjacent
        for (int i=0; i<numAdjF; ++i)
        {
	  face = edge->get(2,i);
  	  if (GEN_type(face->getClassification())==2)
	    bf_counter++;
        }
        if (bf_counter!=2 && !EN_duplicate(edge))
        {
	  edge->print();
  	  cout<<"("<<mypid<<") AOMD WARNING: non-manifold model? # adj. bounding faces="<<bf_counter<<endl;
        }
        if (!EN_duplicate(edge))
	  assert(bf_counter==2);
	else 
	{ 
//	  assert(bf_counter==1);
	}
      } 
    }
    else if (meshDim==2) // edge in 2D
    {
      if (numAdjF==0)
      {  
        cout<<"("<<mypid<<") AOMD WARNING: no adj. faces with "<<edge->getUid()<<endl;
        edge->print();
      }
    
      gLevel=GEN_type(edge->getClassification());
      switch(gLevel)
      {
        case 1: // model edge
   	        if (numAdjF!=1) 
		{
  		  cout<<"("<<mypid<<") AOMD WARNING: "<<numAdjF<<" faces with ";
		  edge->print();
		  manifold=0;
	        }
		break;
        case 2:  if (edge->getPClassification()) // CB edge
	          assert(numAdjF==1);
		else  // non-CB edge
		  assert(numAdjF==2);
	      break;
        default:  cout<<"("<<mypid<<") AOMD ERROR: mesh edge is wrong classified\n";
	        cout<<"Mesh Dim = "<<meshDim<<endl;
                edge->print();
                ret = 0;     
      } // switch
    } // else
    
    pe = edge->getPClassification();
#ifndef PARALLEL 
    assert(!pe);
#else 
    numRC = edge->getNumRemoteCopies();     
    if (!pe) // non-CB vertex
    {  
      if (numRC!=0) edge->printRCs();
      assert(numRC==0);
      continue;
    }
    else  // CB vertex
    {
      if (numRC+1!=pe->getNumBPs())
      {
	edge->printRCs();
	edge->printBPs();
      }
      assert(numRC+1==pe->getNumBPs());
      for (mEntity::RCIter rciter = edge->rcBegin();
          rciter!=edge->rcEnd(); ++rciter)
      {
        pid = rciter->first;
        void* buf = AP_alloc(pid, 460, sizeof(int2_mEnt2_struct));
        int2_mEnt2_struct* castbuf = (int2_mEnt2_struct*)buf;
        castbuf->ent1 = edge;
        castbuf->ent2 = rciter->second;
        castbuf->i=GEN_type(edge->getClassification());
	castbuf->j=GEN_tag(edge->getClassification());
        AP_send(buf);
	sendcount++;
        sendcounts[pid]++;
      } // for rciter
    } // else
#endif     
  } // edges
 
  // check faces
  for (mMesh::iterall it=mesh->beginall(2); it!=mesh->endall(2);++it)
  {
    face = *it;
#ifdef MTOOL
    IntersectionData idata;
    for (int k=0; k<3; ++k)
    {
       vtx = face->get(0,k);
       pPList vfaces=V_faces(vtx);
       iter=0;
       while ((adjfc=(mEntity*)PList_next(vfaces, &iter)))
       {
         if (face==adjfc) continue;
         idata = M_intersectionData_new() ;
	 if (1==M_intersectFaces(face, 0, adjfc, 0, &idata))
	   cout<<"AOMD FATAL: intersecing Faces "<<face->getUid()
	       <<" and "<<adjfc->getUid()<<endl;
         M_intersectionData_delete(idata);	       
       }
       PList_delete(vfaces);
    }
#endif    
    numAdjR = F_numRegions(face);
   
    if (meshDim==3)
    {
      gLevel=GEN_type(face->getClassification());
      switch(gLevel)
      {
        case 2: // face on model face
               if (numAdjR!=1)
	       { cout<<"("<<mypid<<") # adj. regions with "<<face->getUid()<<": "
 	             <<numAdjR<<endl;
	         manifold=0;
               }
	       break;
        case 3: // interior face
               if (EN_duplicate(face)) // CB face
	       {
  	         if (numAdjR!=1) face->print();
	         assert(numAdjR==1);
  	       } 
	       else// non-CB face
	       {  
	         if (F_numRegions(face)!=2) 
		   face->print();
  	         assert(F_numRegions(face)==2);
// check if two regions are on the same side;
                 mEntity* region0 = face->get(3,0);
		 mEntity* region1 = face->get(3,1);
                 pVertex vertex0 = findVertexOppositeFace(region0, face);
                 pVertex vertex1 = findVertexOppositeFace(region1, face);
                 double value0 = computeSignedDistance(vertex0, face);
                 double value1 = computeSignedDistance(vertex1, face);

                 if (fabs(value0)>1E-5 && fabs(value1)>1E-5 && value0*value1>0.0 ) 
                   cout << "AOMD FATAL: 2 rgns "<<region0->getUid()<<" and "
		        << region1->getUid()<<" are on the same side\n";
// end of the check		 
	       }
               break;
        default: cout<<"("<<mypid<<") AOMD ERROR: mesh face is wrong classified. ";
               face->print();
	       ret = 0;     
      }
    } // face in 3D
    else if (meshDim==2)
    {
      if (numAdjR!=0)
      {  
        cout<<"("<<mypid<<") AOMD ERROR: adj. regions with "<<face->getUid()<<" in 2D mesh\n";
        ret = 0;
      }
      assert(F_numRegions(face)==0);
      assert(GEN_type(face->getClassification())==2);
    } // face in 2D

    pe = face->getPClassification();
#ifndef PARALLEL 
    assert(!pe);
#else 
    numRC = face->getNumRemoteCopies();     
    if (!pe) // non-CB vertex
    {  
      if (numRC!=0) face->printRCs();
      assert(numRC==0);
      continue;
    }
    else  // CB vertex
    {
      if (numRC+1!=pe->getNumBPs())
      {
	face->printRCs();
	face->printBPs();
      }
      assert(numRC+1==pe->getNumBPs());
      for (mEntity::RCIter rciter = face->rcBegin();
          rciter!=face->rcEnd(); ++rciter)
      {
        pid = rciter->first;
        void* buf = AP_alloc(pid, 460, sizeof(int2_mEnt2_struct));
        int2_mEnt2_struct* castbuf = (int2_mEnt2_struct*)buf;
        castbuf->ent1 = face;
        castbuf->ent2 = rciter->second;
        castbuf->i=GEN_type(face->getClassification());
	castbuf->j=GEN_tag(face->getClassification());
        AP_send(buf);
	sendcount++;
        sendcounts[pid]++;
      } // for rciter
    } // else
#endif         
  }
  
   // check regions
  for (mMesh::iterall it=mesh->beginall(3); it!=mesh->endall(3);++it)
  {
    region = *it;
    assert(!(region->getPClassification()));
    assert(GEN_type(region->getClassification())==3);
#ifdef DEBUG
    if (R_Volume(region)<0.0)
    {
      cout<<"AOMD FATAL: Negative volume region "<<region->getUid()<<" found!\n   => ";
      region->print();
    }
#endif
    assert(R_Volume(region)>0.0);      
  }

#ifdef PARALLEL
// check partition boundary
  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts);
  int message=0;
  int count;
 
  while(!AP_recv_count(&count) || message<count)
  {
    void* msg;
    int from, tag, size, rc;
    rc = AP_recv(MPI_ANY_SOURCE, 460, AP_BLOCKING|AP_DROPOUT, &msg, &size, &from, &tag);
    if (rc)
    {
      message++;
      recvcount++;
      int2_mEnt2_struct* castbuf = (int2_mEnt2_struct*) msg;
      if (GEN_type(castbuf->ent2->getClassification())!=castbuf->i)
        castbuf->ent2->print();
      assert(GEN_type(castbuf->ent2->getClassification())==castbuf->i);
      if (GEN_tag(castbuf->ent2->getClassification())!=castbuf->j)
        castbuf->ent2->print();
      assert(GEN_tag(castbuf->ent2->getClassification())==castbuf->j);
      assert(castbuf->ent2->getRemoteCopy(from)==castbuf->ent1);
      AP_free(msg);
    }  // end of if (rc)
  }  // end of while(!AP...)
 
  AP_check_sends(AP_WAITALL);
  delete[] sendcounts;
#endif
  if (P_getMinInt(manifold)==0)
    ParUtil::Instance()->Msg(ParUtil::INFO,"\n* Is Your Model Non-Manifold?\n");
  
  int globalRetVal;
  globalRetVal = P_getMinInt(ret);
  if (globalRetVal==1) 
    return true;
  else 
    return false;
} // verify_mesh  

int mMesh::numUniqueEntities(int type)
{
  if (ParUtil::Instance()->size()==1)
    return size(type);
  int mypid=ParUtil::Instance()->rank();
  int numEnt=0;
  for (iterall it=beginall(type); it!=endall(type); ++it)
    if ((*it)->getOwner()==mypid)
      numEnt++;
  return numEnt;
}

void mMesh::printAll()
{
  for (int i=0; i<=getDim();++i)
    print(i);
}

void mMesh::print(int dim)
{
#ifdef PARALLEL
  if (ParUtil::Instance()->master())
    cout<<endl;
    
//  ParUtil::Instance()->Barrier(__LINE__,__FILE__); 
  pmModel* pmodel = pmModel::Instance();
  for (pmModel::PEIter peiter=pmodel->peBegin(); peiter!=pmodel->peEnd();++peiter)
    (*peiter)->print();
//  ParUtil::Instance()->Barrier(__LINE__,__FILE__); 
  if (ParUtil::Instance()->master())
    cout<<endl;
#endif

//  for (int dim=0;dim<=getDim();++dim)
    for (iterall it = beginall(dim); it!=endall(dim);++it)
      (*it)->print();
}

void mMesh::printNumEntities()
{
  for (int i=0; i<=3;++i)
  {
    vector<int> output;
    M_numEntitiesOwned(this,i,output);
    if (P_pid()==0)
    {
      int sum=0;
      for (int j=0; j<P_size();++j)
        sum+=output[j];  
      cout<<"# dim["<<i<<"] = "<<sum<<" (";
      for (int j=0; j<P_size();++j)
      {  cout<<output[j];
         if (j!=P_size()-1)
	   cout<<",";
      }
      cout<<")"<<endl;
    }
  }
}

void mMesh::printNumEntities_NonCfm()
{
#ifdef PARALLEL
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n***  M_PrintNumEntities  ***\n");	  
//  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  cout<<"   ("<<M_Pid()<<") numVt="<<numUniqueEntities(0)<<"\n";
  cout<<"   ("<<M_Pid()<<") numEg="<<numUniqueEntities(1)<<"\n"; 
  cout<<"   ("<<M_Pid()<<") numFc="<<numUniqueEntities(2)<<"\n"; 
  cout<<"   ("<<M_Pid()<<") numRg="<<numUniqueEntities(3)<<"\n"; 
//  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  ParUtil::Instance()->Msg(ParUtil::INFO,"*****************************\n");	  
#else
  cout<<"\n***  M_PrintNumEntities  ***\n";
  cout<<"   numVt = "<<numUniqueEntities(0)<<endl;
  cout<<"   numEg = "<<numUniqueEntities(1)<<endl;
  cout<<"   numFc = "<<numUniqueEntities(2)<<endl;
  cout<<"   numRg = "<<numUniqueEntities(3)<<endl;
  cout<<"*****************************\n";

#endif
}

void mVertex::print() const
{
#ifndef PARALLEL
      cout<<"en_info: "<<getUid()
          <<"["<<p(0)<<","<<p(1)<<","<<p(2)<<"], "
	  <<"(iD "<<iD
 	  <<", mem "<<this
	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
	  <<", gId "<<GEN_id(theClassification)
          <<")\n";
#else
    if (thePClassification)
    { 
      cout<<"("<<ParUtil::Instance()->rank()<<") en_info: "<<getUid()
          <<"["<<p(0)<<","<<p(1)<<","<<p(2)<<"], "
          <<"(iD "<<iD
   	  <<", mem "<<this
 	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
	  <<", gId "<<GEN_id(theClassification)
	  <<", peId "<<thePClassification->getId()
	  <<", numBPs="<<tempBPs.size()
	  <<", numRCs="<<theRemoteCopies.size()
          <<") onCB\n";
    }
    else
    {
      cout<<"("<<ParUtil::Instance()->rank()<<") en_info: "<<getUid()
          <<"["<<p(0)<<","<<p(1)<<","<<p(2)<<"], "
          <<"(iD "<<iD
	  <<", mem "<<this
 	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
 	  <<", gId "<<GEN_id(theClassification)
	  <<", numBPs="<<tempBPs.size()	  
	  <<", numRCs="<<theRemoteCopies.size()	  
          <<")\n";
    }
#endif
}

void mEdge::print()const
{
#ifndef PARALLEL
      cout<<"en_info: "<<getUid()
          <<"(iD "<<iD
	  <<", mem "<<this
 	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
          <<")\n";
#else
    //if (getUid().compare(string("E196_206"))!=0)
    //  return;
    if (thePClassification)
    { 
      cout<<"("<<ParUtil::Instance()->rank()<<") en_info: "<<getUid()
          <<"(iD "<<iD
	  <<", mem "<<this
 	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
	  <<", peId "<<thePClassification->getId()
	  <<", numBPs="<<tempBPs.size()	  
	  <<", numRCs="<<theRemoteCopies.size()	  
          <<") onCB\n";
    }
    else
    {
      cout<<"("<<ParUtil::Instance()->rank()<<") en_info: "<<getUid()
          <<"(iD "<<iD
	  <<", mem "<<this
 	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
	  <<", numBPs="<<tempBPs.size()	  	  
	  <<", numRCs="<<theRemoteCopies.size()	  
          <<")\n";
    }
#endif
}

void mFace::print()const
{
#ifndef PARALLEL
      cout<<"en_info: "<<getUid()
          <<"(iD "<<iD
	  <<", mem "<<this
 	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
          <<")\n";
#else
    //bool flag=false;
    //if (getUid().find("196")!=string::npos && getUid().find("206")!=string::npos)
    //  flag=true;
    // if(!flag) return;
    if (thePClassification)
    { 
      cout<<"("<<ParUtil::Instance()->rank()<<") en_info: "<<getUid()
          <<"(iD "<<iD
	  <<", mem "<<this
 	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
	  <<", peId "<<thePClassification->getId()
	  <<", numBPs="<<tempBPs.size()	  	  
	  <<", numRCs="<<theRemoteCopies.size()	  
          <<") onCB\n";
    }
    else
    {
      cout<<"("<<ParUtil::Instance()->rank()<<") en_info: "<<getUid()
          <<"(iD "<<iD
	  <<", mem "<<this
 	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
	  <<", numBPs="<<tempBPs.size()	  	  
	  <<", numRCs="<<theRemoteCopies.size()	  
          <<")\n";
    }
#endif
}

void mTet::print()const
{
#ifndef PARALLEL
      cout<<"en_info: "<<getUid()
          <<"(iD "<<iD
	  <<", mem "<<this
 	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
          <<")\n";
#else    
    if (thePClassification)
    { 
      cout<<"("<<ParUtil::Instance()->rank()<<") en_info: "<<getUid()
          <<"(iD "<<iD
	  <<", mem "<<this
 	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
	  <<", peId "<<thePClassification->getId()
	  <<", numBPs="<<tempBPs.size()	  	  
	  <<", numRCs="<<theRemoteCopies.size()	  
          <<") onCB\n";
    }
    else
    {
      cout<<"("<<ParUtil::Instance()->rank()<<") en_info: "<<getUid()
          <<"(iD "<<iD
	  <<", mem "<<this
 	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
	  <<", numBPs="<<tempBPs.size()	  	  
	  <<", numRCs="<<theRemoteCopies.size()	  
          <<")\n";
    }
#endif
}


void mHex::print()const
{
#ifndef PARALLEL
      cout<<"en_info: "<<getUid()
          <<"(iD "<<iD
	  <<", mem "<<this
 	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
          <<")\n";
#else
    if (thePClassification)
    { 
      cout<<"("<<ParUtil::Instance()->rank()<<") en_info: "<<getUid()
          <<"(iD "<<iD
	  <<", mem "<<this
 	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
	  <<", peId "<<thePClassification->getId()
	  <<", numBPs="<<tempBPs.size()	  	  
	  <<", numRCs="<<theRemoteCopies.size()	  
          <<") onCB\n";
    }
    else
    {
      cout<<"("<<ParUtil::Instance()->rank()<<") en_info: "<<getUid()
          <<"(iD "<<iD
	  <<", mem "<<this
 	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
	  <<", numBPs="<<tempBPs.size()	  	  
	  <<", numRCs="<<theRemoteCopies.size()	  
          <<")\n";
    }
#endif
}

void mPrism::print()const
{
#ifndef PARALLEL
      cout<<"en_info: "<<getUid()
          <<"(iD "<<iD
	  <<", mem "<<this
 	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
          <<")\n";
#else
    if (thePClassification)
    { 
      cout<<"("<<ParUtil::Instance()->rank()<<") en_info: "<<getUid()
          <<"(iD "<<iD
	  <<", mem "<<this
 	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
	  <<", peId "<<thePClassification->getId()
	  <<", numBPs="<<tempBPs.size()	  	  
	  <<", numRCs="<<theRemoteCopies.size()	  
          <<") onCB\n";
    }
    else
    {
      cout<<"("<<ParUtil::Instance()->rank()<<") en_info: "<<getUid()
          <<"(iD "<<iD
	  <<", mem "<<this
 	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
	  <<", numBPs="<<tempBPs.size()	  	  
	  <<", numRCs="<<theRemoteCopies.size()	  
          <<")\n";
    }
#endif
}
} // namespace
