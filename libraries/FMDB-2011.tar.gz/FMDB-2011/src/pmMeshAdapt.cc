/**************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*****************************************************************************/

/*<i> ****************************************************************************
 *
 *  AOMD/pmodel/pmUtility.cc
 *  Created by Seegyoung Seol, on Mon Dec 08 2003, 10:26:37 EDT
 *
 *  File Content: partition model utility functions
 *
 *************************************************************************** </i>*/

#ifdef PARALLEL

#include <stdio.h>
#include <iostream>
#include <assert.h>
#include <vector>
#include <list>
#include <set>
#include "pmMeshAdapt.h"
#include "pmModel.h"
#include "pmUtility.h"
#include "ParUtil.h"
#include "autopack.h"
#include "AOMD_cint.h"

using std::vector;
using std::list;
using std::cout;
using std::endl;
using std::set;

namespace AOMD {

int deleteDimReduction(mMesh* mesh, vector<mEntity*>* rmE)
{
  int numPtn = ParUtil::Instance()->size();
  if (numPtn==1) return 0;
  int mypid = ParUtil::Instance()->rank();

  int meshDim = M_globalMaxDim(mesh);
  if (meshDim<3)  return 0;

// STEP I: collect faces to delete
  set<mEntity*> entToDelete[3];
  mEntity* ent;
  for (mMesh::iterall it=mesh->beginall(2); it!=mesh->endall(2);++it)
  {
    ent = *it;
    if (F_numRegions(ent)==0)
    {
//      assert(ent->getPClassification());
//      cout<<"("<<mypid<<") AOMD WARNING: run dim reduction with "<<ent->getUid()<<"\n";
      entToDelete[2].insert(ent);
      for (int i=0; i<ent->size(1);++i) // for all adj edge
      {
        mEntity* eg = ent->get(1,i);
	bool toDelete=true;
        for (int j=0; j<eg->size(2);++j) // all adj faces
        {
          if (F_numRegions(eg->get(2,j))>0)
  	  {
	    toDelete=false; // if any adj face has region
	    break;
	  }
        }
        if (toDelete) 
	  entToDelete[1].insert(eg);
      }  // adj edge
    }  // fc to delete
  }
  
  for (set<mEntity*>::iterator eit=entToDelete[1].begin();
        eit!=entToDelete[1].end();++eit)
  { 
    ent = *eit;
    for (int i=0; i<2;++i)
    {
      mEntity* vt = ent->get(0,i);
      bool toDelete=true;
      for (int j=0; j<vt->size(1);++j) // all adj edges
      {
        mEntity* eg=vt->get(1,j);
	for (int k=0; k<eg->size(2);++k)
	{
	  if (F_numRegions(eg->get(2,k))>0)
  	  {  
	    toDelete=false;
	    break;
	  }
	}
      }
      if (toDelete) 
        entToDelete[0].insert(vt);
    }
  }
  
  if (P_getMaxInt(entToDelete[2].size())==0) // no face to delete
    return 0;
//  cout<<"("<<mypid<<") "<<fcToDelete.size()<<" face(s) need to be deleted\n";
  
// STEP II: prepare for communication
  
  int* sendcounts=new int[numPtn];
  for (int i=0;i<numPtn;++i) sendcounts[i]=0;
  
  mEntity::RCIter rciter;
  mEntity* downEnt;
  
  for (int i=2; i>=0;--i)
  {
    for (set<mEntity*>::iterator eit=entToDelete[i].begin();
          eit!=entToDelete[i].end();++eit)
    {
      ent=*eit;
      // STEP III: send message to delete the copy of face to delete
      for (rciter=ent->rcBegin(); rciter!=ent->rcEnd();++rciter)
      {
        void* buf = AP_alloc(rciter->first,1000,sizeof(mEnt_struct));
        mEnt_struct* castbuf = (mEnt_struct*)buf;
        castbuf->entity = rciter->second;
        AP_send(buf);
        sendcounts[rciter->first]++;
      } // for RCIter
    }
  }

// STEP IV: recieve entity and update its pclassification and remoteCopies
  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts);
  int message=0;    
  int count;
  while(!AP_recv_count(&count)||message<count)
  {
    void* msg;
    int from,tag,size,rc;
  // receive phase begins
    rc=AP_recv(MPI_ANY_SOURCE,1000,AP_BLOCKING|AP_DROPOUT,(void**)&msg,&size,&from,&tag);
    if (rc)
    {
      message++;
      mEnt_struct* castbuf = (mEnt_struct*)msg;
      ent = castbuf->entity;
      // delete remote copy
      int numRC = ent->getNumRemoteCopies();
      ent->deleteRemoteCopy(from);
      assert(numRC==ent->getNumRemoteCopies()+1);
      // update PClassification
      set<int> bps;
      ent->getPidsExist(bps);
      pmEntity* pe = pmModel::Instance()->getPartitionEntity(bps);
      if (pe)
        assert(ent->getNumRemoteCopies()==pe->getNumBPs()-1);
      ent->setPClassification(pe);
//      cout<<"("<<mypid<<") update PClassification of "<<ent->getUid()<<endl;
      AP_free(msg);
    }  // if(rc)
  }
  AP_check_sends(AP_WAITALL);
  delete [] sendcounts;
  
  // STEP IIV: delete face, edges, vertices
  for (int i=2;i>=0;--i)
  {
    for (set<mEntity*>::iterator eit=entToDelete[i].begin();
        eit!=entToDelete[i].end();++eit)
    {
      rmE[i].push_back(*eit);
      if (i>0) 
        M_removeFace(mesh,(*eit)); 
      else     
        M_removeVertex(mesh,(*eit)); 
    }
  }

  int numDeleted=P_getSumInt(entToDelete[2].size());
  if (P_pid()==0)
     cout<<"      # faces deleted = "<<numDeleted<<endl;
  return numDeleted;
}

//*************************************************************
void unifyTaggedEntities(unsigned int attachTag, std::list<mEntity*> &LIST)
//*************************************************************
{
//  for (list<mEntity*>::iterator eit=LIST.begin();eit!=LIST.end();++eit)
//    cout<<"("<<ParUtil::Instance()->rank()<<") unifyTaggedEntities :"
//         <<(*eit)->getUid()<<"\n";
  // send phase begins
  int numPtn = ParUtil::Instance()->size();
  if (numPtn==1) return;
  
  int* sendcounts=new int[numPtn];
  for (int i=0;i<numPtn;++i) sendcounts[i]=0;

  list<mEntity*>::iterator lit=LIST.begin();
  mEntity* ent;
  for(; lit!=LIST.end();++lit)
  {
    ent=*lit;
    if (!ent->getPClassification())
      continue;
    for (mEntity::RCIter rciter=ent->rcBegin(); rciter!=ent->rcEnd();++rciter)
    {
      void* buf = AP_alloc(rciter->first,9977,sizeof(mEnt_struct));
      mEnt_struct* castbuf = (mEnt_struct*)buf;
      castbuf->entity = rciter->second;
      AP_send(buf);
      sendcounts[rciter->first]++;
    } // for RCItet
  }  // for LIST
  
  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts);
  int message=0;    
  int count;
  while(!AP_recv_count(&count)||message<count)
  {
    void* msg;
    int from,tag,size,rc;
  // receive phase begins
    rc=AP_recv(MPI_ANY_SOURCE,9977,AP_BLOCKING|AP_DROPOUT,(void**)&msg,&size,&from,&tag);
    if (rc)
    {
      message++;
      mEnt_struct* castbuf = (mEnt_struct*)msg;
      if(!castbuf->entity->getAttachedInt(attachTag))
      {
        castbuf->entity->attachInt(attachTag,1);
        LIST.push_back(castbuf->entity);
//	cout<<"("<<ParUtil::Instance()->rank()
//	    <<") unifyTaggedEntities : LIST.push_back("
//         <<castbuf->entity->getUid()<<"\n";
      }
      AP_free(msg);
    }  // if(rc)
  }
  AP_check_sends(AP_WAITALL);
  delete [] sendcounts;
//  cout<<"("<<ParUtil::Instance()->rank()<<") AFTER  unifyTaggedEntities\n";
/*  
  for (list<mEntity*>::iterator eit=LIST.begin();eit!=LIST.end();++eit)
    cout<<"("<<ParUtil::Instance()->rank()<<") unifyTaggedEntities :"
         <<(*eit)->getUid()<<"\n";
*/	 
}

// every program should call this function before creating vertices 
// on CB and use getAttachedDataInt(aomdtag) as an vertex id on CB 
//*************************************************************
void attachUniqueId(mMesh* mesh, unsigned int aomdtag)
//*************************************************************
{ 
  int numPtn = ParUtil::Instance()->size();
  if (numPtn==1) return;
  
  int mypid = ParUtil::Instance()->rank();
  int* sendcounts = new int[numPtn];
  for (int i=0; i<numPtn; ++i) sendcounts[i]=0;
  
  int localMaxId, globalMaxId;
  int localMinId, globalMinId;

  localMinId =mesh->getIdGenerator().getMaxValue();
  globalMinId = localMinId;
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  MPI_Allreduce(&localMinId,&globalMinId,1,MPI_INT,MPI_MAX,MPI_COMM_WORLD);
  mesh->pmSetNewVertexId(globalMinId-numPtn+mypid+1);

  // count how many of mesh edges on VEC are owned by the actual processor
  mEntity* ent;
  mMesh::iterall eit=mesh->beginall(1);
  for (;eit!=mesh->endall(1);++eit)
  {
    ent = *eit;
    if (ent->getPClassification() && 
        ent->getOwner()==ParUtil::Instance()->rank())
    {
      int id=mesh->getNewVertexId();
//      cout<<"("<<M_Pid()<<") got a new vtId "<<id<<endl;
      ent->attachInt(aomdtag, id);
      // iterate over remote copies
      for (mEntity::RCIter rciter=ent->rcBegin(); rciter!=ent->rcEnd();++rciter)
      { 
        // send phase begins to find the entity in the counterpart
	// and assign the same id		
	void* buf = AP_alloc(rciter->first, 445, sizeof(int_mEnt_struct));
/*	cout<<"("<<P_pid()<<") ComputeUId::attach vtId "<<id<<" to "<<ent->getUid()
	    <<" in P"<<rciter->first<<endl;
*/	    
	int_mEnt_struct* castbuf = (int_mEnt_struct*)buf;
	castbuf->entity = rciter->second;
	castbuf->i = id;
	AP_send(buf);
	sendcounts[rciter->first]++;
      } // for RCIter
    } // if (Owner)
  }  // for eiter
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  // receive phase begins
  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts);
  int message=0;
  int count;
  while(!AP_recv_count(&count) || message<count)
  {
    void* msg;
    int from, tag, size, rc;
    rc = AP_recv(MPI_ANY_SOURCE, 445, AP_BLOCKING|AP_DROPOUT, &msg, &size, &from, &tag);
    if (rc)
    {
      message++;
      int_mEnt_struct* castbuf = (int_mEnt_struct*) msg;
      castbuf->entity->attachInt(aomdtag, castbuf->i);
//      cout<<"("<<P_pid()<<") attach vtId "
//          <<castbuf->i<<" to "<<castbuf->entity->getUid()<<endl;
      AP_free(msg);	
    }  // end of if (rc)
  }  // end of while(!AP...)
    
  AP_check_sends(AP_WAITALL);
  delete[] sendcounts; 

  // update maximumValue of mIdGenerator
  localMaxId =mesh->getIdGenerator().getMaxValue();
  globalMaxId = localMaxId;
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  MPI_Allreduce(&localMaxId,&globalMaxId,1,MPI_INT,MPI_MAX,MPI_COMM_WORLD);
  mesh->pmSetNewVertexId(globalMaxId-numPtn+mypid+1);

//  cout<<"("<<M_Pid()<<") ComputeUniqueId::theIdGenerator.getNewVertexId()="<<
//  mesh->getNewVertexId()<<endl;
} // end of computeVtIDonPB(..)


} // end of namespace
#endif
