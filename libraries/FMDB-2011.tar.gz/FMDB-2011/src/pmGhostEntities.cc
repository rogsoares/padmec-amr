/**************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*****************************************************************************/

/*<i> ****************************************************************************
 *
 *  AOMD/pmodel/pmGhostEntities.cc
 *  Created by Seegyoung Seol, on Thur Sep 16 2004, 10:26:37 EDT
 *
 *  File Content: functions supporting ghost entity migration procedure
 *
 *************************************************************************** </i>*/
#ifdef PARALLEL

#include <stdio.h>
#include <iostream>
#include <assert.h>

#include "pmMigrateUtil.h"
#include "pmUtility.h"
#include "pmModel.h"
#include "mAOMD.h"
#include "mMesh.h"
#include "mEntity.h"
#include "mException.h"
#include "mVertex.h"
#include "ParUtil.h"
#include "autopack.h"
#include "AOMDInternals.h"
#include "pmMigrationCallbacks.h"
#include "AOMD_Internals.h"
#include "AOMD_cint.h"
#include "modeler.h"

#include <list>
#include <vector>
#include <set>
#include <string>
#include <map>

using std::list;
using std::vector;
using std::set;
using std::cout;
using std::endl;
using std::string;
using std::find;
using std::map;

namespace AOMD {

// **********************************************
//     structure used for communication
// **********************************************
 
struct packedGhostVertex
{
  int iD;
  int gTag;
  int gType;
  double coord[3];
};

struct packedGhostNonVertex
{
  int type;
  int gTag;
  int gType;
};

void getGhostEnts(mMesh*, int,
       set<mEntity*>*, set<mEntity*>*, set<mEntity*>*, set<mEntity*>*);

void getGhostEntsToExpand(mMesh*, int, vector<mEntity*>&, int,
       set<mEntity*>*, set<mEntity*>*, set<mEntity*>*, set<mEntity*>*);
		       
void getGhostEntsToExpand_3D(mMesh*, vector<mEntity*>&, int,
       set<mEntity*>*, set<mEntity*>*, set<mEntity*>*, set<mEntity*>*);

void getGhostEntsToExpand_2D(mMesh*, vector<mEntity*>&, int,
		       set<mEntity*>*, set<mEntity*>*,
		       set<mEntity*>*, set<mEntity*>*);
		       
void exchangeGhostEnts(mMesh*, int, pmMigrationCallbacks&, set<mEntity*>*, int);

void* packGhostMEntity(mEntity*, int, pmMigrationCallbacks &);
void* packGhostMVertex(mEntity*, int, pmMigrationCallbacks &);
void* packGhostMNonVertex(mEntity*, int, pmMigrationCallbacks &);

void unpackGhostMEntity(mMesh*, int, void *, int, int, pmMigrationCallbacks &);

		       
// *****************************************
int migrateGhostEntities(mMesh* mesh, 
                      pmMigrationCallbacks& cb)
// *****************************************			
{
//  cout<<"("<<P_pid()<<") START migrateGhostEntities\n";
  double t1, t2, ts, te;
  int meshDim = M_dimension(mesh);
  
  set<mEntity*> **entitiesToCopy =new set<mEntity*>* [4];
  for (int i=0; i<4; ++i)
    entitiesToCopy[i] = new set<mEntity*>[ParUtil::Instance()->size()];

//  set<mEntity*> entitiesToCopy[4][ParUtil::Instance()->size()];

// ********************************************
// STEP 1: collect entities to migrate
// ********************************************    
#ifdef DEBUG
  t1 = ParUtil::Instance()->wTime();
  ts = t1;
#endif  
  // entitiesToSend 
  getGhostEnts(mesh, meshDim, entitiesToCopy[0], entitiesToCopy[1], 
                     entitiesToCopy[2], entitiesToCopy[3]);
  
  int i, j, localMove=0;
  for (i=0; i<ParUtil::Instance()->size();++i)
  {
    if (i==P_pid())
      assert(entitiesToCopy[meshDim][i].size()==0);

    localMove+=entitiesToCopy[meshDim][i].size();
  }
    
  int totalMove;
  MPI_Allreduce(&localMove,&totalMove,1,MPI_INT,MPI_SUM,MPI_COMM_WORLD);
  if (totalMove==0)
  {
#ifdef DEBUG
    if (P_pid()==0) cout<<"\n* NO entity migration needed\n";
#endif
    return 0;
  }
  
#ifdef DEBUG
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) getGhostEnts \n",t2-t1);
//  cout<<"\t*getGhostEnts "<<t2-t1<<"(sec)\n";

// ********************************************
// STEP 2: exchange entities to copy
// ********************************************    
  t1 = ParUtil::Instance()->wTime();
#endif
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);

  for (int i=0; i<=meshDim;++i)
    exchangeGhostEnts(mesh, meshDim, cb, entitiesToCopy[i], i);
#ifdef DEBUG
  t2=ParUtil::Instance()->wTime();
  te=t2;

  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) exchangeGhostCopies \n",t2-t1);
//  cout<<"\t*exchangeGhostCopies "<<t2-t1<<"(sec)\n";
  if (ParUtil::Instance()->rank()==0)
    ParUtil::Instance()->Msg(ParUtil::INFO,"\t# Moved = %d (TIME = %f sec))\n",
                             totalMove, te-ts);
#endif 

// deallocate the memory
  for (i=0; i<4; ++i)
    for (j=0; j<ParUtil::Instance()->size();++j)
      entitiesToCopy[i][j].clear(); 

//  for (i=0; i<=4; i++)
//    delete [] entitiesToCopy[i];
  delete [] entitiesToCopy;
//  cout<<"END migrateGhost...\n";
  
  return totalMove;
}

// ***********************************************************
void getGhostEnts(mMesh* mesh, int meshDim,
		       set<mEntity*>* vToCopy,
		       set<mEntity*>* eToCopy,
		       set<mEntity*>* fToCopy,
		       set<mEntity*>* rToCopy)
// ***********************************************************
{
  mEntity* vt;
  mEntity* rg;
   
  int mypid=ParUtil::Instance()->rank();
  
  typedef vector<mEntity*>::iterator vecIter;
  typedef set<mEntity*>::iterator setIter;

  vector<mEntity*> vtOnCB;
  M_getCBEntities(mesh, 0, vtOnCB);

  set<mEntity*> family;
  vector<set<mEntity*> > regionsToProcess;
  regionsToProcess.resize(P_size());
  vector<int> pidsExist;  
  int dest_pid;
  for (vecIter vit=vtOnCB.begin(); vit != vtOnCB.end(); ++vit)
  {
    vt = *vit;
// STEP 1: compute patch
    set<mEntity*> patch;
    void* iter = 0;
   
    pPList vregions = PList_new();
    if (meshDim==3) vregions = V_regions(vt); 
    else if (meshDim==2) vregions = V_faces(vt);
    
    while ((rg=(mEntity*)PList_next(vregions,&iter)))
      patch.insert(rg);
    PList_delete(vregions);        
  
// STEP 2: get a list of regions to send to each processor
    for (setIter rit = patch.begin(); rit!=patch.end();++rit)  
    {
      for (mEntity::RCIter rciter=vt->rcBegin();rciter!=vt->rcEnd();++rciter)
      {
        dest_pid= rciter->first;
	if (find(regionsToProcess[dest_pid].begin(),
	        regionsToProcess[dest_pid].end(), *rit)
	    == regionsToProcess[dest_pid].end())
	  regionsToProcess[dest_pid].insert(*rit);
      }
    }
    
// STEP 3: determine the entities to send 
    for (int pid=0; pid<P_size();++pid)
    {
      if (pid==mypid) continue;
      for (setIter rit = regionsToProcess[pid].begin();
            rit != regionsToProcess[pid].end(); ++rit)
      {
        // get family
	family.clear();
	getFamily(*rit, family);
        for (setIter famiter = family.begin(); famiter!=family.end();++famiter)
	{
          pEntity ent = *famiter;
	  if (ent->getLevel()==3)
	    rToCopy[pid].insert(ent);
	  else
	  { 
	    pidsExist.clear();
	    ent->getPidsExist(pidsExist);
	    if (find(pidsExist.begin(), pidsExist.end(), pid)==pidsExist.end())
	    {
    	      switch (ent->getLevel())
	      {
	        case 0: vToCopy[pid].insert(ent); break;
	        case 1: eToCopy[pid].insert(ent); break;
	        case 2: fToCopy[pid].insert(ent); break;
	        default: break;
	      }
	    }
          } //else
        } // for famIter
      } // for riter
    } // for pid
  }  // for vit
}

// **********************************************
void exchangeGhostEnts(mMesh* mesh, int meshDim, 
                     pmMigrationCallbacks &cb,
		     set<mEntity*>* entitiesToSend, int entDims)		     
// **********************************************
{
  mEntity* ent;
  set<int>::iterator piter;
  int pid, i;
  int mypid=ParUtil::Instance()->rank();
  int numPE = ParUtil::Instance()->size();
  
  set<mEntity*>::const_iterator eit;
  
  int *sendcounts = new int[ParUtil::Instance()->size()];
  for (i=0;i<numPE;i++) sendcounts[i]=0;

  ParUtil::Instance()->Barrier(__LINE__,__FILE__);

  for (pid=0; pid<numPE;++pid)
  {
    if (pid==mypid || entitiesToSend[pid].empty()) continue;
    for(eit=entitiesToSend[pid].begin(); eit!=entitiesToSend[pid].end();++eit)
    {
      ent = *eit;
      // decide processor to send
      void *buf = packGhostMEntity(ent,pid,cb);
      AP_send(buf);
      sendcounts[pid] ++;
    }
  }
  
  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts);
  int message=0;
  int count;
  
  while (!AP_recv_count(&count) || message<count) 
  {  
    void *msg;
    int from, tag, size, rc;
    rc=AP_recv(MPI_ANY_SOURCE, MPI_ANY_TAG, AP_BLOCKING|AP_DROPOUT,
               &msg, &size, &from, &tag);
    if (rc && (tag == TAGVERTEX || tag == TAGNONVERTEX)) 
    {
      message++;
      unpackGhostMEntity(mesh,meshDim,msg,from,tag,cb);
      AP_free(msg);
    }
  }
  AP_check_sends(AP_WAITALL); 
  delete[] sendcounts;   
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
}  

// **********************************************
void * packGhostMEntity(mEntity *ent, int pid, 
		  pmMigrationCallbacks &cb)
// **********************************************
{
  if (ent->getLevel()==0)
    return packGhostMVertex(ent, pid, cb);
  else
    return packGhostMNonVertex(ent, pid, cb);
}
    
// **********************************************
void* packGhostMVertex(mEntity *ent, int pid, pmMigrationCallbacks &cb)
// **********************************************
{    
  char *buf;
  char *buf_user;
  int user_size;
  int entity_size;

  /* User may have some data to send to the other process 
     These data are of size user_size */
  buf_user = (char*)cb.getUserData(ent,pid,user_size);
  if(!buf_user)user_size = 0;

  entity_size = sizeof(packedGhostVertex);

  buf=(char*)AP_alloc(pid, TAGVERTEX, entity_size + user_size);
      
// fixed length data
  packedGhostVertex castbuf; 
  castbuf.iD = ent->getId();
  castbuf.gTag = GEN_tag(ent->getClassification());
  castbuf.gType = GEN_type(ent->getClassification());
  Trellis_Util::mPoint p(((mVertex*)ent)->point());
  for(int i=0;i<3;i++) castbuf.coord[i] = p(i);
  memcpy(buf,&castbuf,sizeof(packedGhostVertex)); 

  if(user_size)
  {
    memcpy (&buf[entity_size],buf_user,user_size);
    cb.deleteUserData(buf_user);
  }
  
  return buf;
  
}

// **********************************************
void * packGhostMNonVertex(mEntity *ent, int pid, 
		  pmMigrationCallbacks &cb)
// **********************************************
{    
// int mypid=ParUtil::Instance()->rank();
  char *buf;
  char *buf_user;
  int user_size;
  int entity_size;

  /* User may have some data to send to the other process 
     These data are of size user_size */
  buf_user = (char*)cb.getUserData(ent, pid,user_size);
  if(!buf_user)user_size = 0;

  int entDim = ent->getLevel();
  int numDE=0;
  switch(entDim)
  {
    case 1: numDE=2; break;
    case 2: numDE=3; break;
    case 3: numDE=4; break;
    default: break;
  }

  entity_size = sizeof(packedGhostNonVertex) + numDE*sizeof(int);
 
  buf=(char*)AP_alloc(pid, TAGNONVERTEX, entity_size + user_size);
 
  // fixed length data
  packedGhostNonVertex castbuf;
  castbuf.type = ent->getType();
  castbuf.gTag = GEN_tag(ent->getClassification());
  castbuf.gType = GEN_type(ent->getClassification());
  memcpy(buf,&castbuf,sizeof(packedGhostNonVertex));
    
  int* DEs = (int*)malloc(numDE*sizeof(int));
  for (int i=0; i<numDE;++i)
     DEs[i] = ent->get(0,i)->getId();
  memcpy(&buf[sizeof(packedGhostNonVertex)],DEs,numDE*sizeof(int));
  free(DEs);

  if (user_size)
  {
    memcpy (&buf[entity_size],buf_user,user_size);
    cb.deleteUserData(buf_user);
  }
  
  return buf;
  
}

// **********************************************
void unpackGhostMEntity(mMesh* mesh, int meshDim, 
		       void *vbuf, int pid, int itag,
                       pmMigrationCallbacks &cb)
// **********************************************
{
  char *buf = (char*)vbuf;
  int entity_size;
  
  mEntity* ent=0;
 
  if (itag == TAGVERTEX)
  {
    packedGhostVertex castbuf;
    memcpy(&castbuf,buf,sizeof(packedGhostVertex));
    mVertex* v1 = mesh->getVertex(castbuf.iD);
    if (v1) return;
// STEP 1: create entity
    ent = mesh->createVertex_noUpdateId(castbuf.iD,castbuf.coord[0],castbuf.coord[1],castbuf.coord[2],
                                  mesh->getGEntity(castbuf.gTag,castbuf.gType));
    entity_size = sizeof(packedGhostVertex);
//    cout<<"("<<P_pid()<<") create "<<ent->getUid()<<endl;
  }
  else if(itag == TAGNONVERTEX)
  {
    entity_size=sizeof(packedGhostNonVertex);
    packedGhostNonVertex castbuf;
    memcpy(&castbuf,buf,sizeof(packedGhostNonVertex));
    pGEntity g = mesh->getGEntity(castbuf.gTag,castbuf.gType);

// STEP 1: create an entity
    int numDE;
    switch (castbuf.type)
    {
      case mEntity::EDGE: 
      {
        numDE=2;
	int* DEs = new int[numDE]; 
        memcpy(DEs,&buf[sizeof(packedGhostNonVertex)],sizeof(int)*numDE);
	mVertex *v1 = mesh->getVertex(DEs[0]);
	mVertex *v2 = mesh->getVertex(DEs[1]);
	assert(v1&&v2);
	// check if the edge exists already
	if (E_exist(v1,v2)) return;
	ent = M_createE(mesh, v1, v2, g); 
//        cout<<"("<<P_pid()<<") create "<<ent->getUid()
//	    <<"("<<EN_getUid(v1)<<", "<<EN_getUid(v2)<<")\n";
        delete[] DEs;
      } break;

      case mEntity::TRI: 
      {
        numDE=3;
	int* DEs = new int[3]; 
        memcpy(DEs,&buf[sizeof(packedGhostNonVertex)],sizeof(int)*3);
        mVertex* v1 = mesh->getVertex(DEs[0]);
        mVertex* v2 = mesh->getVertex(DEs[1]);
        mVertex* v3 = mesh->getVertex(DEs[2]);
        // check if the face exists already
        assert(v1&&v2&&v3);
	if (F_exist(0,(mEntity*)v1,(mEntity*)v2,(mEntity*)v3,(mEntity*)0))
  	  return;
        mEntity* edges[3];
        edges[0]=(mEntity*)E_exist(v1,v2);
        edges[1]=(mEntity*)E_exist(v2,v3);
        edges[2]=(mEntity*)E_exist(v1,v3);
	assert(edges[0] && edges[1] && edges[2]);
        ent = M_createF(mesh, 3, edges, 0, g);
        delete[] DEs;
      } break;

      case mEntity::TET: 
      {
        numDE=4;
	int* DEs = new int[numDE]; 
        memcpy(DEs,&buf[sizeof(packedGhostNonVertex)],sizeof(int)*numDE);
        mVertex* v1 = mesh->getVertex(DEs[0]);
        mVertex* v2 = mesh->getVertex(DEs[1]);
        mVertex* v3 = mesh->getVertex(DEs[2]);
        mVertex* v4 = mesh->getVertex(DEs[3]);
        assert(v1&&v2&&v3&&v4);
	// check if the face exists already
        if (R_exist(0,(mEntity*)v1,(mEntity*)v2,(mEntity*)v3,
	              (mEntity*)v4, (mEntity*)0, (mEntity*)0))
	  return;
	
	mEntity* faces[4];
        faces[0]=(mEntity*)F_exist(0,(mEntity*)v1,(mEntity*)v2,(mEntity*)v3,(mEntity*)0);
        faces[1]=(mEntity*)F_exist(0,(mEntity*)v1,(mEntity*)v2,(mEntity*)v4,(mEntity*)0);
        faces[2]=(mEntity*)F_exist(0,(mEntity*)v2,(mEntity*)v3,(mEntity*)v4,(mEntity*)0);
        faces[3]=(mEntity*)F_exist(0,(mEntity*)v1,(mEntity*)v3,(mEntity*)v4,(mEntity*)0);
	assert(faces[0] && faces[1] && faces[2] && faces[3]);
        ent=(mEntity*)M_createR(mesh, 4, faces, 0, g);
        delete[] DEs;
      } break;
      
      default :
        throw new mException(__LINE__,__FILE__,
                             "unpacking not done for this type of mesh entity");
    }
    entity_size+=sizeof(int)*numDE;
  }
  mesh->ghostEntities[ent->getLevel()].push_back(ent);
    
// STEP 6: process user attached data
  cb.recieveUserData(ent,pid,itag,&buf[entity_size]);

}

void removeGhostEntities(mMesh* mesh)
{
  vector<mEntity*>::iterator vit;
  for (vit = mesh->ghostEntities[3].begin(); vit!=mesh->ghostEntities[3].end(); ++vit)
    M_removeRegion(mesh, *vit); 
  
  for (vit = mesh->ghostEntities[2].begin(); vit!=mesh->ghostEntities[2].end(); ++vit)
    M_removeFace(mesh, *vit); 

  for (vit = mesh->ghostEntities[1].begin(); vit!=mesh->ghostEntities[1].end(); ++vit)
    M_removeEdge(mesh, *vit); 

  for (vit = mesh->ghostEntities[0].begin(); vit!=mesh->ghostEntities[0].end(); ++vit)
    M_removeVertex(mesh, *vit); 

  for (int i=0; i<4; ++i)
    mesh->ghostEntities[i].clear();
}

int getPatch(mEntity* ent, set<pEntity>& patch)
{
  void* iter = 0;
  mEntity* rg;
  mEntity* rg2;
  mEntity* fc;
  pPList vregions = V_regions(ent); 
  while ((rg=(mEntity*)PList_next(vregions,&iter)))
  {
    patch.insert(rg);
    pPList tmpList = R_faces(rg,1);
    void* iter2 = 0;
    while ((fc=(mEntity*)PList_next(tmpList,&iter2)))
    {
      pPList tmpList2 = F_regions(fc);
      void* iter3=0;
      while ((rg2=(mEntity*)PList_next(tmpList2,&iter3)))
      {
        patch.insert(rg2);
      }
      PList_delete(tmpList2);       
    }
    PList_delete(tmpList);
  } // while rg
  PList_delete(vregions);        
  return patch.size();
}

int expandGhostEntities(mMesh* mesh, pmMigrationCallbacks &cb, 
			vector<mEntity*>& vtsToExpand, int dimToExpand)
{
//  cout<<"("<<P_pid()<<") START expandGhostEntities\n";
  double t1, t2, ts, te;
  int meshDim = M_dimension(mesh);
  
  set<mEntity*> **entitiesToCopy =new set<mEntity*>* [4];
  for (int i=0; i<4; ++i)
    entitiesToCopy[i] = new set<mEntity*>[ParUtil::Instance()->size()];

//  set<mEntity*> entitiesToCopy[4][ParUtil::Instance()->size()];

// ********************************************
// STEP 1: collect entities to migrate
// ********************************************    
#ifdef DEBUG
  t1 = ParUtil::Instance()->wTime();
  ts = t1;
#endif  
  // entitiesToSend 
  getGhostEntsToExpand(mesh, meshDim, vtsToExpand, dimToExpand,
  		           entitiesToCopy[0], entitiesToCopy[1], 
                           entitiesToCopy[2], entitiesToCopy[3]);
  
  int i, j, localMove=0;
  for (i=0; i<ParUtil::Instance()->size();++i)
  {
    if (i==P_pid())
      assert(entitiesToCopy[meshDim][i].size()==0);

    localMove+=entitiesToCopy[meshDim][i].size();
  }
    
  int totalMove;
  MPI_Allreduce(&localMove,&totalMove,1,MPI_INT,MPI_SUM,MPI_COMM_WORLD);
  if (totalMove==0)
  {
#ifdef DEBUG
    if (P_pid()==0) cout<<"\n* NO entity migration needed\n";
#endif
    return 0;
  }
  
#ifdef DEBUG
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) getGhostEnts \n",t2-t1);
//  cout<<"\t*getGhostEnts "<<t2-t1<<"(sec)\n";

// ********************************************
// STEP 2: exchange entities to copy
// ********************************************    
  t1 = ParUtil::Instance()->wTime();
#endif
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);

  for (int i=0; i<=meshDim;++i)
    exchangeGhostEnts(mesh, meshDim, cb, entitiesToCopy[i], i);
#ifdef DEBUG
  t2=ParUtil::Instance()->wTime();
  te=t2;

  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) exchangeGhostCopies \n",t2-t1);
//  cout<<"\t*exchangeGhostCopies "<<t2-t1<<"(sec)\n";
  if (ParUtil::Instance()->rank()==0)
    ParUtil::Instance()->Msg(ParUtil::INFO,"\t# Moved = %d (TIME = %f sec))\n",
                             totalMove, te-ts);
#endif 

// deallocate the memory
  for (i=0; i<4; ++i)
    for (j=0; j<ParUtil::Instance()->size();++j)
      entitiesToCopy[i][j].clear(); 

//  for (i=0; i<=4; i++)
//    delete [] entitiesToCopy[i];
  delete [] entitiesToCopy;

  return totalMove;
}					       

// ***********************************************************
void getGhostEntsToExpand(mMesh* mesh, int meshDim, vector<mEntity*>& vtsToExpand, 
                         int dimToExpand,
  		         set<mEntity*>* vToCopy,
		         set<mEntity*>* eToCopy,
		         set<mEntity*>* fToCopy,
		         set<mEntity*>* rToCopy)
// ***********************************************************
{
  if (meshDim==2)
    getGhostEntsToExpand_2D(mesh, vtsToExpand, dimToExpand, vToCopy, eToCopy,
                             fToCopy, rToCopy);
  else if (meshDim==3)
    getGhostEntsToExpand_3D(mesh, vtsToExpand, dimToExpand, vToCopy, eToCopy,
                             fToCopy, rToCopy);
}

// ***********************************************************
void getGhostEntsToExpand_3D(mMesh* mesh, vector<mEntity*>& vtsToExpand, int dimToExpand,
    		            set<mEntity*>* vToCopy, set<mEntity*>* eToCopy,
		            set<mEntity*>* fToCopy, set<mEntity*>* rToCopy)
// ***********************************************************			    
{			   			     
  mEntity *vt, *fc, *rg;
  int mypid=ParUtil::Instance()->rank();
  
  typedef vector<mEntity*>::iterator vecIter;
  typedef set<mEntity*>::iterator setIter;

  set<mEntity*> family;
  vector<set<mEntity*> > regionsToProcess;
  regionsToProcess.resize(P_size());
  vector<int> pidsExist;  
  int dest_pid;
  vector<mEntity*> patch;
  vector<mEntity*> expandPatch;
  vector<mEntity*> flist;
  void *iter;

  pMeshDataId patch_tag=MD_newMeshDataId("patch");
  pMeshDataId face_tag=MD_newMeshDataId("face processed");
  int tag_value;
  
  map<mEntity*, set<int> > face_to_bounce;
 
  // iterate over vertices to process 
  for (vecIter vit=vtsToExpand.begin(); vit != vtsToExpand.end(); ++vit)
  {
    vt = *vit;
//    cout<<"("<<P_pid()<<") process "<<EN_getUidStr(vt)<<endl;
// STEP 1: compute patch
    patch.clear();
    flist.clear();
    expandPatch.clear();
    iter = 0;
   
    pPList vregions = V_regions(vt); 
    
    while ((rg=(mEntity*)PList_next(vregions,&iter)))
    {
      if (!EN_isGhost(mesh, rg))
      {
        patch.push_back(rg);
	EN_attachDataInt(rg, patch_tag, 1); // mark rg
      }
    }
    PList_delete(vregions);        
//    cout<<"("<<P_pid()<<") STEP 1 done\n";  
// STEP 2: get a list of faces to process
    for (vecIter rit = patch.begin(); rit!=patch.end();++rit)  
    {
      pPList rfaces = PList_new();
      switch (dimToExpand)  
      {
        case 0: rfaces = R_vertices(*rit, 1); break;
        case 1: rfaces = R_edges(*rit, 1); break;
        case 2: rfaces = R_faces(*rit, 1); break;
      }
      iter=0;
      while ((fc=(mEntity*)PList_next(rfaces,&iter)))
      {
        EN_getDataInt(fc, face_tag, &tag_value);
	if (tag_value!=1)
	{
	  EN_attachDataInt(fc, face_tag, 1);
	  flist.push_back(fc);
	}
      }
      PList_delete(rfaces);        
    } // for rit
//    cout<<"("<<P_pid()<<") STEP 2 done\n";

// STEP 3: get the expanded patch list and collect the list of faces on CB     
    for (vecIter fit = flist.begin(); fit!=flist.end(); ++fit)
    {
      pPList fregions = PList_new();
      switch (dimToExpand)
      {
        case 0: fregions = V_regions(*fit); break;
        case 1: fregions = E_regions(*fit); break;
        case 2: fregions = F_regions(*fit); break;
      }

      while ((rg = (mEntity*)PList_next(fregions,&iter)))
      {
        EN_getDataInt(rg, patch_tag, &tag_value);
	if (tag_value==1 || EN_isGhost(mesh, rg)) continue;
	expandPatch.push_back(rg);
      }
      PList_delete(fregions); 
      if ((*fit)->getPClassification()) // fc is on CB
      {
        for (mEntity::RCIter rciter=vt->rcBegin();rciter!=vt->rcEnd();++rciter)
	  face_to_bounce[*fit].insert(rciter->first);
      }
      EN_deleteData(*fit, face_tag); // unmark fc      
    }
    
//    cout<<"("<<P_pid()<<") STEP 3 done\n";
    
    for (vecIter rit = patch.begin(); rit!=patch.end();++rit)  
      EN_deleteData(*rit, patch_tag); // unmark rg      

// STEP 4: put expanded patch list into region container to send  
    for (vecIter rit = expandPatch.begin(); rit!=expandPatch.end();++rit)  
    {
      for (mEntity::RCIter rciter=vt->rcBegin();rciter!=vt->rcEnd();++rciter)
      {
        dest_pid= rciter->first;
	if (find(regionsToProcess[dest_pid].begin(),
	        regionsToProcess[dest_pid].end(), *rit)
	    == regionsToProcess[dest_pid].end())
	  regionsToProcess[dest_pid].insert(*rit);
      }
    }
  } // for vt
//  cout<<"("<<P_pid()<<") STEP 4 done\n";
  
// STEP 5: send face info to process into the remote copy
  P_barrier();
  
  int* sendcounts = new int[ParUtil::Instance()->size()];
  for (int i=0; i<ParUtil::Instance()->size(); ++i) sendcounts[i]=0;

  for (map<mEntity*, set<int> >::iterator fmapit = face_to_bounce.begin();
      fmapit != face_to_bounce.end(); ++fmapit)
  {
    fc = fmapit->first;
    int num_dpids = fmapit->second.size();
//    cout<<"\t("<<P_pid()<<") "<<EN_getUidStr(fc)<<" num_dpis = "<<num_dpids
//        <<"\n  ";

    int buf_size=sizeof(int_mEnt_struct) + num_dpids*sizeof(int);
    
    for (mEntity::RCIter rciter=fc->rcBegin();rciter!=fc->rcEnd();++rciter)
    {   
      char* buf = (char*)AP_alloc(rciter->first, 4458, buf_size);
      int_mEnt_struct castbuf;
      castbuf.i = num_dpids;
      castbuf.entity = rciter->second;
      memcpy(buf,&castbuf,sizeof(int_mEnt_struct));
      int* dpids = (int*)malloc(num_dpids*sizeof(int));
      int i=0;
      for (set<int>::iterator sit =  fmapit->second.begin(); sit!= fmapit->second.end(); ++sit)
      {
        dpids[i++] = *sit;
      }
      memcpy(&buf[sizeof(int_mEnt_struct)],dpids,num_dpids*sizeof(int));
      delete[] dpids;
      AP_send((void*)buf);
      sendcounts[rciter->first]++;
    }
  } // for face_to_bounce

//  cout<<"\n("<<P_pid()<<") AP_SEND done\n";
     
  // receive phase begins
  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts);
  int message=0;
  int count;
  while(!AP_recv_count(&count) || message<count)
  {
    void* msg;
    int from, tag, size, rc;
    rc = AP_recv(MPI_ANY_SOURCE, 4458, AP_BLOCKING|AP_DROPOUT, &msg, &size, &from, &tag);
    if (rc)
    {
      message++;
      char* buf = (char*) msg;
      int_mEnt_struct castbuf;
      memcpy(&castbuf,buf,sizeof(int_mEnt_struct));
      fc = castbuf.entity;
      int* dpids = new int[castbuf.i];
      memcpy(dpids,&buf[sizeof(int_mEnt_struct)],sizeof(int)*castbuf.i);
      iter = 0;
      pPList fregions = PList_new();
      switch(dimToExpand)
      {
        case 0: fregions = V_regions(fc); break;
        case 1: fregions = E_regions(fc); break;
        case 2: fregions = F_regions(fc); break;
      }

      while ((rg=(mEntity*)PList_next(fregions,&iter)))
      {
        if (EN_isGhost(mesh, rg)) continue;
        for ( int i=0; i<castbuf.i; ++i)
        { 
          dest_pid = dpids[i];
          if (dest_pid==mypid) continue;
          if (find(regionsToProcess[dest_pid].begin(),
                   regionsToProcess[dest_pid].end(), rg)
              == regionsToProcess[dest_pid].end())
            regionsToProcess[dest_pid].insert(rg);
        }
      } // while rg
      PList_delete(fregions);
      delete[] dpids;
      AP_free(msg);
    }  // end of if (rc)
  }  // end of while(!AP...)
  AP_check_sends(AP_WAITALL);
  delete[] sendcounts;
  MD_deleteMeshDataId(patch_tag);
  MD_deleteMeshDataId(face_tag);

// STEP 6: determine all levels of entities to send
  for (int pid=0; pid<P_size();++pid)
  {
    if (pid==mypid) continue;
    for (setIter rit = regionsToProcess[pid].begin();
         rit != regionsToProcess[pid].end(); ++rit)
    {
      // get family
      family.clear();
      getFamily(*rit, family);
      for (setIter famiter = family.begin(); famiter!=family.end();++famiter)
      {
        pEntity ent = *famiter;
        if (ent->getLevel()==3)
          rToCopy[pid].insert(ent);
        else
        {
          pidsExist.clear();
          ent->getPidsExist(pidsExist);
          if (find(pidsExist.begin(), pidsExist.end(), pid)==pidsExist.end())
          {
            switch (ent->getLevel())
            {
              case 0: vToCopy[pid].insert(ent); break;
              case 1: eToCopy[pid].insert(ent); break;
              case 2: fToCopy[pid].insert(ent); break;
            } // switch
          } // if
        } //else
      } // for famIter
    } // for riter
  } // for pid
}

void getGhostEntsToExpand_2D(mMesh* mesh, vector<mEntity*>& vtsToExpand, int dimToExpand,
    		            set<mEntity*>* vToCopy, set<mEntity*>* eToCopy,
		            set<mEntity*>* fToCopy, set<mEntity*>* rToCopy)
{
  std::cerr<<"getGhostEntsToExpand_2D not implemented  yet\n";
  throw 1;
}	
} // end of namespace
#endif /* PARALLEL */
