/******************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*********************************************************************************/
#ifdef PARALLEL

#include <stdio.h>
#include <iostream>
#include <assert.h>
#include "AOMD_LoadBalancer.h"
#include "mMigrateUtil.h"
#include "mMesh.h"
#include "mEntity.h"
#include "mVertex.h"
#include "mEdge.h"
#include "mRegion.h"
#include "ParUtil.h"
#include "pmGraphs.h"
#include "mAOMD.h"
#include "AOMD_OwnerManager.h"
#include "AOMD_Internals.h"
#include "AOMD_cint.h"
#include "autopack.h"
#include "mExchangeData.h"

using std::vector;
using std::set;
using std::cout;
using std::pair;
using std::list;
using std::endl;
	       
namespace AOMD {

// ***********************************************************
int mMesh::doEntityMigration(
            AOMD_LoadBalancerCallbacks& cb,
            int dimToKnow, 
	    vector<mEntity*>& rmE, 
            vector<mEntity*>& newE)
// ***********************************************************
{
  int from = M_globalMaxDim(this);
  int to = from-1;
//  int numENBefore=size(dimToKnow);
  list<mEntity*> vtToRemove;
  list<mEntity*> egToRemove;
  list<mEntity*> fcToRemove;
  list<mEntity*> rgToRemove;

   
  vector<mEntity*> newEg;
  vector<mEntity*> newFc;
  double t1, t2;
  
  t1=ParUtil::Instance()->wTime();
  AOMD_distributed_graph g(this,from,to,&cb,0);
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  
  int* partitionVector = new int[g.theGraph->nn];
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) build graph\n",t2-t1);
  t1=ParUtil::Instance()->wTime();
  computePartitionVector(this,partitionVector);

  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) compute partitionVector\n",t2-t1);
//  printf("\n\t(%d) * %f (sec) compute partitionVector\n",ParUtil::Instance()->rank(),t2-t1);
  int i=0;
  int numToMove=0;
  for (iterall iter=beginall(from); iter!=endall(from) ; ++iter,++i)
  {
    if (ParUtil::Instance()->rank() != partitionVector[i])
    {
//#ifdef DEBUG
//       cout<<"("<<M_Pid()<<") partition["<<(*iter)->getUid()<<"] = "
//        <<partitionVector[i]<<endl;
//#endif
	numToMove++;
    }
  }
  
  int globalNumToMove = P_getMaxInt(numToMove);
  if (globalNumToMove==0)
    return 0;
//  printf("\n\t(%d) globalNumTOMove=%d\n",ParUtil::Instance()->rank(),globalNumToMove);
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);

  int initial_id = g.vtxdist[ParUtil::Instance()->rank()];
  t2=ParUtil::Instance()->wTime();
 // list<mEntity *> toDelete;
 // CreateMigrationVectors (this,partitionVector,initial_id,from,0,toDelete,
 //                        ParUtil::Instance()->size());
  if (from==3)
    CreateMigrationVectors_oneLevel(this,partitionVector,initial_id,from,0,rgToRemove,
                           ParUtil::Instance()->size());
  else if (from==2)
    CreateMigrationVectors_oneLevel(this,partitionVector,initial_id,from,0,fcToRemove,
                           ParUtil::Instance()->size());
  t1=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) marking entities to move\n",t1-t2);
//  printf("\n\t(%d) CreateMigrationVectors\n",ParUtil::Instance()->rank());
  ParallelReclassifyMeshEntities(from);  
//  printf("\n\t(%d) ParallelReclassifyMeshEntities\n",ParUtil::Instance()->rank());
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) set common bdry \n",t2-t1);
  t1 = ParUtil::Instance()->wTime();
 /// migration phase uniquely in parallel
  int *sendcounts = new int[ParUtil::Instance()->size()];

  for(int dim = 0; dim <= from; dim++)
  {
    ParUtil::Instance()->Barrier(__LINE__,__FILE__);
    for(int i=0;i<ParUtil::Instance()->size();i++)
      sendcounts[i]=0;
    for(mMesh::iter it = begin(dim) ; it!= end(dim) ; ++it)
    {
      mEntity *e = *it;
	  	  
      for(int dest=0;dest<getNbDests(e);dest++)
      {	      
        int part = getDest(e,dest);
	      
	if(part != ParUtil::Instance()->rank())
	{
          void *buf = packMeshEntity(e,part,cb);
	  AP_send(buf);
	  sendcounts[part] ++;
        }
      }
    }

    AP_check_sends(AP_NOFLAGS);
    AP_reduce_nsends(sendcounts);
    int message=0;
    int count;

    while (!AP_recv_count(&count) || message<count) 
    {  
      void *msg;
      int from, tag, size, rc;
      rc=AP_recv(MPI_ANY_SOURCE, MPI_ANY_TAG, AP_BLOCKING|AP_DROPOUT,
  	         &msg, &size, &from, &tag);
      if (rc && (tag == TAGVERTEX || tag == TAGNONVERTEX)) 
      {
        message++;
        //unpackMeshEntity2(msg,from,tag,cb,
        //                  dimToKnow,newE,newEg,newFc);
        unpackMeshEntity_oneLevel(msg,from,tag,cb,
                                  dimToKnow,newE);

        AP_free(msg);
      }
    }
    AP_check_sends(AP_WAITALL); 
    ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  }
//cout<<"("<<M_Pid()<<") send/receive ends"<<endl;
  int localMoved;
  if (from==3)
    localMoved = rgToRemove.size();
  else if (from==2)
    localMoved=fcToRemove.size();
  int totalMoved;
  MPI_Allreduce(&localMoved,&totalMoved,1,MPI_INT,MPI_SUM,
		MPI_COMM_WORLD);

  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) communication to exchange entities\n",t2-t1);

//  cout<<"("<<M_Pid()<<") dimToKnow="<<dimToKnow<<endl;

  list<mEntity*>::iterator biter, eiter;
  if (dimToKnow==3)
  {
    biter=rgToRemove.begin(); eiter=rgToRemove.end();
    for (;biter!=eiter;++biter)
      rmE.push_back(*biter);
  }
  
  if (from==3)
     removeEntities(this,from,rgToRemove);
  else
    removeEntities(this,from,fcToRemove);

  getEntitiesToRemove(from, vtToRemove, egToRemove, fcToRemove);
  
  if (dimToKnow>=0)
  {
    switch(dimToKnow)
    {
      case 0: biter=vtToRemove.begin(); eiter = vtToRemove.end();break;
      case 1: biter=egToRemove.begin(); eiter=egToRemove.end();break;
      case 2: biter=fcToRemove.begin(); eiter= fcToRemove.end(); break;
      default: break;
    }
    for (;biter!=eiter;++biter)
      rmE.push_back(*biter);
  }

  if (from==3)
    removeEntities(this,2,fcToRemove);
 
  removeEntities(this,1,egToRemove);
  removeEntities(this,0,vtToRemove);

  t1=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) remove entities\n",t1-t2);

  bdryLinkSetup();
//cout<<"("<<M_Pid()<<") bdryLinkSetup \n";
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) bdryLinkSetup\n",t2-t1);
 
   delete [] sendcounts;
  delete [] partitionVector;

  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  unsigned int tagMark = AOMD_Util::Instance()->lookupMeshDataId("_dest");
  for(int i=0;i<4;i++)
    for(mMesh::iterall it = beginall(i) ; it!= endall(i) ; ++it)
      (*it)->deleteData(tagMark); 

  t1=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) delete attached dest pid\n",t1-t2);

  return totalMoved;
}

// ***********************************************************
/*int mMesh::doEntityMigration(
            AOMD_LoadBalancerCallbacks& cb,
            int dimToKnow, 
	    vector<mEntity*>& rmE, 
            vector<mEntity*>& newE)
	    */
// ***********************************************************
/*{
ParUtil::Instance()->Msg(ParUtil::INFO,"\n*** doEntityMigration ***\n"); 
  int from = M_getMaxDim(this);
  int to = from-1;
//  int numENBefore=size(dimToKnow);
  list<mEntity*> vtToRemove;
  list<mEntity*> egToRemove;
  list<mEntity*> fcToRemove;
  list<mEntity*> rgToRemove;

   
  vector<mEntity*> newEg;
  vector<mEntity*> newFc;
  double t1, t2;
  double accT1=0.0, accT2=0.0;

  int localRg=numUniqueEntities(3);
  int localFc=numUniqueEntities(2);
  int localEg=numUniqueEntities(1);
  int localVt=numUniqueEntities(0);
  int localEnt=localRg+localFc+localEg+localVt;
  int totalBfEnt;
  MPI_Allreduce(&localEnt,&totalBfEnt,1,MPI_INT,MPI_SUM,
		MPI_COMM_WORLD);

// ********************************************
// STEP 1: BUILD A GRAPH
// ********************************************    
  t1=ParUtil::Instance()->wTime();
  AOMD_distributed_graph g(this,from,to,&cb,0);
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  
// ********************************************
// STEP 2: BUILD A Partition Vector
// ********************************************  
  int* partitionVector = new int[g.theGraph->nn];
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) build graph\n",t2-t1);
  t1=ParUtil::Instance()->wTime();
  computePartitionVector(this,partitionVector);

// ********************************************
// STEP 3: Check if migration needed
// ********************************************  
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) compute partitionVector\n",t2-t1);
//  printf("\n\t(%d) * %f (sec) compute partitionVector\n",ParUtil::Instance()->rank(),t2-t1);
  int i=0;
  int numToMove=0;
  for (iterall iter=beginall(from); iter!=endall(from) ; ++iter,++i)
  {
    if (ParUtil::Instance()->rank() != partitionVector[i])
    {
//#ifdef DEBUG
//       cout<<"("<<M_Pid()<<") partition["<<(*iter)->getUid()<<"] = "
//        <<partitionVector[i]<<endl;
//#endif
	numToMove++;
    }
  }
  
  int globalNumToMove = M_getMaxNum(numToMove);
  if (globalNumToMove==0)
    return 0;
//  printf("\n\t(%d) globalNumTOMove=%d\n",ParUtil::Instance()->rank(),globalNumToMove);
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);

// ********************************************
// STEP 4: Mark entities to Move
// ********************************************  
  int initial_id = g.vtxdist[ParUtil::Instance()->rank()];
  t2=ParUtil::Instance()->wTime();
 // list<mEntity *> toDelete;
 // CreateMigrationVectors (this,partitionVector,initial_id,from,0,toDelete,
 //                        ParUtil::Instance()->size());
  if (from==3)
    CreateMigrationVectors_oneLevel(this,partitionVector,initial_id,from,0,rgToRemove,
                           ParUtil::Instance()->size());
  else if (from==2)
    CreateMigrationVectors_oneLevel(this,partitionVector,initial_id,from,0,fcToRemove,
                           ParUtil::Instance()->size());
  t1=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) marking entities to move\n",t1-t2);
//  printf("\n\t(%d) CreateMigrationVectors\n",ParUtil::Instance()->rank());

// ********************************************
// STEP 5: Set CB and collect entities to move
// ********************************************  
  ParallelReclassifyMeshEntities(from);  
//  printf("\n\t(%d) ParallelReclassifyMeshEntities\n",ParUtil::Instance()->rank());
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) set CB \n",t2-t1);
  t1 = ParUtil::Instance()->wTime();
// ********************************************
// STEP 6: Migrate entities
// ******************************************** 
 /// migration phase uniquely in parallel
  int *sendcounts = new int[ParUtil::Instance()->size()];

  for(int dim = 0; dim <= from; dim++)
  {
    ParUtil::Instance()->Barrier(__LINE__,__FILE__);
    for(int i=0;i<ParUtil::Instance()->size();i++)
      sendcounts[i]=0;
    for(mMesh::iter it = begin(dim) ; it!= end(dim) ; ++it)
    {
      mEntity *e = *it;
	  	  
      for(int dest=0;dest<getNbDests(e);dest++)
      {	      
        int part = getDest(e,dest);
	      
	if(part != ParUtil::Instance()->rank())
	{
          void *buf = packMeshEntity(e,part,cb);
	  AP_send(buf);
	  sendcounts[part] ++;
        }
      }
    }

    AP_check_sends(AP_NOFLAGS);
    AP_reduce_nsends(sendcounts);
    int message=0;
    int count;

    while (!AP_recv_count(&count) || message<count) 
    {  
      void *msg;
      int from, tag, size, rc;
      rc=AP_recv(MPI_ANY_SOURCE, MPI_ANY_TAG, AP_BLOCKING|AP_DROPOUT,
  	         &msg, &size, &from, &tag);
      if (rc && (tag == TAGVERTEX || tag == TAGNONVERTEX)) 
      {
        message++;
        //unpackMeshEntity2(msg,from,tag,cb,
        //                  dimToKnow,newE,newEg,newFc);
        unpackMeshEntity_oneLevel(msg,from,tag,cb,
                                  dimToKnow,newE);

        AP_free(msg);
      }
    }
    AP_check_sends(AP_WAITALL); 
    ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  }

// ********************************************
// STEP 7: compute #partition objects migrated
// ******************************************** 
//cout<<"("<<M_Pid()<<") send/receive ends"<<endl;
  int localMoved;
  if (from==3)
    localMoved = rgToRemove.size();
  else if (from==2)
    localMoved=fcToRemove.size();
  int totalMoved;
  MPI_Allreduce(&localMoved,&totalMoved,1,MPI_INT,MPI_SUM,
		MPI_COMM_WORLD);

  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) communication to exchange entities\n",t2-t1);

//  cout<<"("<<M_Pid()<<") dimToKnow="<<dimToKnow<<endl;
  
  list<mEntity*>::iterator biter, eiter;
  if (dimToKnow==3)
  {
    biter=rgToRemove.begin(); eiter=rgToRemove.end();
    for (;biter!=eiter;++biter)
      rmE.push_back(*biter);
  }
  t1 = ParUtil::Instance()->wTime();
  accT2+=t1-t2;

// ********************************************
// STEP 8: remove partition objects
// ******************************************** 
  t1 =  ParUtil::Instance()->wTime(); 
  if (from==3)
     removeEntities(this,from,rgToRemove);
  else
    removeEntities(this,from,fcToRemove);
  t2 = ParUtil::Instance()->wTime();
  accT1+=t2-t1;
// ********************************************
// STEP 9: collect entities to remove
// ******************************************** 
  t1 = ParUtil::Instance()->wTime();
  getEntitiesToRemove(from, vtToRemove, egToRemove, fcToRemove);
  t2 = ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) collect entities to remove\n");
  
  if (dimToKnow>=0)
  {
    switch(dimToKnow)
    {
      case 0: biter=vtToRemove.begin(); eiter = vtToRemove.end();break;
      case 1: biter=egToRemove.begin(); eiter=egToRemove.end();break;
      case 2: biter=fcToRemove.begin(); eiter= fcToRemove.end(); break;
      default: break;
    }
    for (;biter!=eiter;++biter)
      rmE.push_back(*biter);
  }
  t1 = ParUtil::Instance()->wTime();
  accT2+=t1-t2;
// ********************************************
// STEP 10: remove entities unused
// ******************************************** 

  if (from==3)
    removeEntities(this,2,fcToRemove);
 
  removeEntities(this,1,egToRemove);
  removeEntities(this,0,vtToRemove);
  t2 = ParUtil::Instance()->wTime();
  accT1+=t2-t1;
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) remove entities\n",accT1);
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) gather remove entities to return\n",accT2);

// ********************************************
// STEP 11: setup common boundaries
// ******************************************** 
  t1=ParUtil::Instance()->wTime();
  bdryLinkSetup();
//cout<<"("<<M_Pid()<<") bdryLinkSetup \n";
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) CB link setup\n",t2-t1);
 
   delete [] sendcounts;
  delete [] partitionVector;

// ********************************************
// STEP 12: remove attached pids
// ******************************************** 

  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  unsigned int tagMark = AOMD_Util::Instance()->lookupMeshDataId("_dest");
  for(int i=0;i<4;i++)
    for(mMesh::iterall it = beginall(i) ; it!= endall(i) ; ++it)
      (*it)->deleteData(tagMark); 

  t1=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) delete attached dest pid\n",t1-t2);

  return totalMoved;
}
*/
// ***********************************************************
int mMesh::doEntityMigration_fast(
            AOMD_LoadBalancerCallbacks& cb,
            int dimToKnow, 
	    vector<mEntity*>& rmE, 
            vector<mEntity*>& newE)
// ***********************************************************
{
ParUtil::Instance()->Msg(ParUtil::INFO,"\n*** doEntityMigration 2***\n"); 
  int from = M_globalMaxDim(this);
  int to = from-1;
//  int numENBefore=size(dimToKnow);
  list<mEntity*> vtToRemove;
  list<mEntity*> egToRemove;
  list<mEntity*> fcToRemove;
  list<mEntity*> rgToRemove;

   
  vector<mEntity*> newEg;
  vector<mEntity*> newFc;
  double t1, t2;
  double accT1=0.0, accT2=0.0;

  int localRg=numUniqueEntities(3);
  int localFc=numUniqueEntities(2);
  int localEg=numUniqueEntities(1);
  int localVt=numUniqueEntities(0);
  int localEnt=localRg+localFc+localEg+localVt;
  int totalBfEnt;
  MPI_Allreduce(&localEnt,&totalBfEnt,1,MPI_INT,MPI_SUM,
		MPI_COMM_WORLD);

// ********************************************
// STEP 1: BUILD A GRAPH
// ********************************************    
  t1=ParUtil::Instance()->wTime();
  AOMD_distributed_graph g(this,from,to,&cb,0);
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  
// ********************************************
// STEP 2: BUILD A Partition Vector
// ********************************************  
  int* partitionVector = new int[g.theGraph->nn];
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) build graph\n",t2-t1);
  t1=ParUtil::Instance()->wTime();
  computePartitionVector(this,partitionVector);

// ********************************************
// STEP 3: Check if migration needed
// ********************************************  
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) compute partitionVector\n",t2-t1);
//  printf("\n\t(%d) * %f (sec) compute partitionVector\n",ParUtil::Instance()->rank(),t2-t1);
  int i=0;
  int numToMove=0;
  for (iterall iter=beginall(from); iter!=endall(from) ; ++iter,++i)
  {
    if (ParUtil::Instance()->rank() != partitionVector[i])
    {
//#ifdef DEBUG
//       cout<<"("<<M_Pid()<<") partition["<<(*iter)->getUid()<<"] = "
//        <<partitionVector[i]<<endl;
//#endif
	numToMove++;
    }
  }
  
  int globalNumToMove = P_getMaxInt(numToMove);
  if (globalNumToMove==0)
    return 0;
//  printf("\n\t(%d) globalNumTOMove=%d\n",ParUtil::Instance()->rank(),globalNumToMove);
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);

// ********************************************
// STEP 4: Mark entities to Move
// ********************************************  
  int initial_id = g.vtxdist[ParUtil::Instance()->rank()];
  t2=ParUtil::Instance()->wTime();
 // list<mEntity *> toDelete;
 // CreateMigrationVectors (this,partitionVector,initial_id,from,0,toDelete,
 //                        ParUtil::Instance()->size());
  if (from==3)
    CreateMigrationVectors_oneLevel(this,partitionVector,initial_id,from,0,rgToRemove,
                           ParUtil::Instance()->size());
  else if (from==2)
    CreateMigrationVectors_oneLevel(this,partitionVector,initial_id,from,0,fcToRemove,
                           ParUtil::Instance()->size());
  t1=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) marking entities to move\n",t1-t2);
//  printf("\n\t(%d) CreateMigrationVectors\n",ParUtil::Instance()->rank());

// ********************************************
// STEP 5: Set CB and collect entities to move
// ********************************************  
  ParallelReclassifyMeshEntities(from);  
//  printf("\n\t(%d) ParallelReclassifyMeshEntities\n",ParUtil::Instance()->rank());
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) set CB \n",t2-t1);
  t1 = ParUtil::Instance()->wTime();
// ********************************************
// STEP 6: Migrate entities
// ******************************************** 
 /// migration phase uniquely in parallel
  int *sendcounts = new int[ParUtil::Instance()->size()];

  for(int dim = 0; dim <= from; dim++)
  {
    ParUtil::Instance()->Barrier(__LINE__,__FILE__);
    for(int i=0;i<ParUtil::Instance()->size();i++)
      sendcounts[i]=0;
    for(mMesh::iter it = begin(dim) ; it!= end(dim) ; ++it)
    {
      mEntity *e = *it;
	  	  
      for(int dest=0;dest<getNbDests(e);dest++)
      {	      
        int part = getDest(e,dest);
	      
	if(part != ParUtil::Instance()->rank())
	{
          void *buf = packMeshEntity(e,part,cb);
	  AP_send(buf);
	  sendcounts[part] ++;
        }
      }
    }

    AP_check_sends(AP_NOFLAGS);
    AP_reduce_nsends(sendcounts);
    int message=0;
    int count;

    while (!AP_recv_count(&count) || message<count) 
    {  
      void *msg;
      int from, tag, size, rc;
      rc=AP_recv(MPI_ANY_SOURCE, MPI_ANY_TAG, AP_BLOCKING|AP_DROPOUT,
  	         &msg, &size, &from, &tag);
      if (rc && (tag == TAGVERTEX || tag == TAGNONVERTEX)) 
      {
        message++;
        unpackMeshEntity_oneLevel(msg,from,tag,cb,
                                  dimToKnow,newE);

        AP_free(msg);
      }
    }
    AP_check_sends(AP_WAITALL); 
    ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  }

// ********************************************
// STEP 7: compute #partition objects migrated
// ******************************************** 
//cout<<"("<<M_Pid()<<") send/receive ends"<<endl;
  int localMoved;
  if (from==3)
    localMoved = rgToRemove.size();
  else if (from==2)
    localMoved=fcToRemove.size();
  int totalMoved;
  MPI_Allreduce(&localMoved,&totalMoved,1,MPI_INT,MPI_SUM,
		MPI_COMM_WORLD);

  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) communication to exchange entities\n",t2-t1);

//  cout<<"("<<M_Pid()<<") dimToKnow="<<dimToKnow<<endl;
  
  list<mEntity*>::iterator biter, eiter;
  if (dimToKnow==3)
  {
    biter=rgToRemove.begin(); eiter=rgToRemove.end();
    for (;biter!=eiter;++biter)
      rmE.push_back(*biter);
  }
  t1 = ParUtil::Instance()->wTime();
  accT2+=t1-t2;

// ********************************************
// STEP 8: remove partition objects
// ******************************************** 
  t1 =  ParUtil::Instance()->wTime(); 
  if (from==3)
     removeEntities(this,from,rgToRemove);
  else
    removeEntities(this,from,fcToRemove);
  t2 = ParUtil::Instance()->wTime();
  accT1+=t2-t1;
// ********************************************
// STEP 9: collect entities to remove
// ******************************************** 
  t1 = ParUtil::Instance()->wTime();
  getEntitiesToRemove(from, vtToRemove, egToRemove, fcToRemove);
  t2 = ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) collect entities to remove\n");
  
  if (dimToKnow>=0)
  {
    switch(dimToKnow)
    {
      case 0: biter=vtToRemove.begin(); eiter = vtToRemove.end();break;
      case 1: biter=egToRemove.begin(); eiter=egToRemove.end();break;
      case 2: biter=fcToRemove.begin(); eiter= fcToRemove.end(); break;
      default: break;
    }
    for (;biter!=eiter;++biter)
      rmE.push_back(*biter);
  }
  t1 = ParUtil::Instance()->wTime();
  accT2+=t1-t2;
// ********************************************
// STEP 10: remove entities unused
// ******************************************** 

  if (from==3)
    removeEntities(this,2,fcToRemove);
 
  removeEntities(this,1,egToRemove);
  removeEntities(this,0,vtToRemove);
  t2 = ParUtil::Instance()->wTime();
  accT1+=t2-t1;
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) remove entities\n",accT1);
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) gather remove entities to return\n",accT2);

// ********************************************
// STEP 11: setup common boundaries
// ******************************************** 
  t1=ParUtil::Instance()->wTime();
  bdryLinkSetup();
//cout<<"("<<M_Pid()<<") bdryLinkSetup \n";
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) CB link setup\n",t2-t1);
 
   delete [] sendcounts;
  delete [] partitionVector;

// ********************************************
// STEP 12: remove attached pids
// ******************************************** 

  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  unsigned int tagMark = AOMD_Util::Instance()->lookupMeshDataId("_dest");
  for(int i=0;i<4;i++)
    for(mMesh::iterall it = beginall(i) ; it!= endall(i) ; ++it)
      (*it)->deleteData(tagMark); 

  t1=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) delete attached dest pid\n",t1-t2);

  return totalMoved;
}
  
int mMesh::migrateToOneProc(int dimToMove,std::list<mEntity*>& entities,
                              AOMD_LoadBalancerCallbacks &cb,
                              int dimToKnow,
                              std::vector<mEntity*>& rmE,
                              std::vector<mEntity*>& newE)
{
  if (ParUtil::Instance()->size()==1)
    return 0;

  unifyEntities(entities);
  //it computes the entities to move and its destination pid
  //cout<<"("<<M_Pid()<<") unifyEntities()::entities.size()="<<entities.size()<<endl;
  
  setEntitiesToMove(this,entities,dimToMove);
  //cout<<"("<<M_Pid()<<") setEntitiesToMove\n"<<endl;

  return this->doEntityMigration(cb,dimToKnow, rmE, newE);
}

} // end of namespace

#endif
