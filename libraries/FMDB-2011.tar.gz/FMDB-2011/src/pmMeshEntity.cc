/**************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*****************************************************************************/

/*<i> ****************************************************************************
 *
 *  AOMD/pmodel/pmMeshEntity.cc
 *  Created by Seegyoung Seol, on Mon Dec 08 2003, 10:26:37 EDT
 *
 *  File Content: mEntity operators dealing with PClassification
 *
 *************************************************************************** </i>*/


#include <iostream>
#include <map>
#include <set>
#include <algorithm>
#include <assert.h>
#include <vector>

#include "mEntity.h"
#include "pmEntity.h"
#include "pmModel.h"
#include "ParUtil.h"

using std::copy;
using std::map;
using std::cout;
using std::endl;
using std::set;
using std::vector;

namespace AOMD {

int mEntity::getOwner()
{
#ifdef PARALLEL
  if (thePClassification)
    return thePClassification->getOwner();
  else 
    return ParUtil::Instance()->rank();
#else
  return 0;
#endif    
}


void mEntity::setPClassification(pmEntity* pe)
{
#ifdef PARALLEL
  thePClassification = pe;
#endif  
}

pmEntity* mEntity::getPClassification()
{
#ifdef PARALLEL
  return thePClassification;
#else
  return (pmEntity*)0;
#endif
}

#ifdef PARALLEL

void mEntity::printPC()
{
  cout<<"("<<ParUtil::Instance()->rank()<<") PC of "<<getUid()<<": ";
  getPClassification()->print();
}
void mEntity::printBPs()
{
  cout<<"("<<ParUtil::Instance()->rank()<<") BP of "<<getUid()<<": ";
  for (mEntity::BPIter bpiter=bpBegin(); bpiter!=bpEnd();++bpiter)
    cout<<*bpiter<<",";
  cout<<endl;  
}


void mEntity::printRCs()
{
  cout<<"("<<ParUtil::Instance()->rank()<<") RC of "<<getUid()<<": ";
  for (mEntity::RCIter rciter=rcBegin(); rciter!=rcEnd();++rciter)
    cout<<"(P"<<rciter->first<<","<<rciter->second<<"), ";
  cout<<endl;  
}

void mEntity::setPClassificationWithBPs()
{
  if (tempBPs.size()<=1)
    thePClassification = (pmEntity*)0;
  else
    thePClassification=pmModel::Instance()->getPartitionEntity(tempBPs); 
}

void mEntity::getPidsExist(std::set<int>& pids)
{
  pids.insert(ParUtil::Instance()->rank());
  for (mEntity::RCIter rcIter=rcBegin(); rcIter!=rcEnd();++rcIter)
    pids.insert(rcIter->first);
}

int mEntity::getMinPidExist()
{
  vector<int> pids;
  getPidsExist(pids);
  vector<int>::iterator minit=std::min_element(pids.begin(),pids.end());
  return *minit;
}

void mEntity::getPidsExist(std::vector<int>& pids)
{
  pids.push_back(ParUtil::Instance()->rank());
  for (mEntity::RCIter rcIter=rcBegin(); rcIter!=rcEnd();++rcIter)
    pids.push_back(rcIter->first);
}


mEntity* mEntity::getRemoteCopy(int pid)
{
  mEntity* remoteEnt = (mEntity*)0;
  map<int,mEntity*>::iterator mapit = theRemoteCopies.find(pid);
  if (mapit!=theRemoteCopies.end())
    remoteEnt = mapit->second;
  return remoteEnt;   
}

void mEntity::getRemoteCopies(map<int, mEntity*>& remoteCopies)
{
  assert(remoteCopies.empty());
  for (RCIter it=rcBegin(); it!=rcEnd(); ++it)
    remoteCopies.insert(remoteCopyMap::value_type(it->first, it->second));
}

void mEntity::addRemoteCopy(int pid, mEntity* remoteEnt)
{
//  int mypid=ParUtil::Instance()->rank();
//  cout<<"\t("<<mypid<<") "<<getUid()<<"->addRemoteCopy("<<pid<<")\n";
  theRemoteCopies.insert(remoteCopyMap::value_type(pid, remoteEnt));
}

void mEntity::deleteRemoteCopy(int pid)
{
//  int mypid=ParUtil::Instance()->rank();
//  cout<<"\t("<<mypid<<") "<<getUid()<<"->deleteRemoteCopy("<<pid<<")\n";
  theRemoteCopies.erase(remoteCopyMap::key_type(pid));
}

void mEntity::deleteRemoteCopy(mEntity::RCIter rciter) 
{ theRemoteCopies.erase(rciter); }

void mEntity::clearRemoteCopies()
{
  theRemoteCopies.clear();
//  assert(theRemoteCopies.empty());
}

#endif /* PARALLEL */

} /* end of namespace */ 
