/**************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*****************************************************************************/

/*****************************************************************************
 *
 *  cint/PAOMD_Internals.cc
 *  Created by Eunyoung Seol, on Thur Jun 12 2003, 10:26:37 EDT
 *
 *  C interface definition for PAOMD
 *
 ****************************************************************************/
 
#ifndef SIM

#include "AOMD_Internals.h"
#include "AOMD_cint.h"
#include "AOMDfwd.h"
#include "AOMD_Defs.h"
#include "ParUtil.h"
#include "mParallelUtility.h"
#include "mEntity.h"
#include "mMesh.h"
#include "mEdge.h"
#include "mVector.h"
#include "mPoint.h"
#include "mVertex.h"
#include "pmModelUtil.h"
#include "pmMeshAdapt.h"
#ifdef PARALLEL
#include "pmUtility.h"
#include "autopack.h"
#include "AOMD_ZoltanLoadBalancer.h"
#endif

#include <iostream>
#include <list>
#include <vector>

using namespace AOMD;
using std::cout;
using std::endl;
using std::vector;

// **********************************
// mesh loading
// **********************************


void M_setRepresentationFlag(mMesh* mesh, int i)
{
  mesh->setRepresentationFlag(i);
}


int M_getMaxDim(pMesh mesh){
  int dim = mesh->getDim();
  int maxDim = M_getMaxNum(dim);  
  return maxDim;
}
  
  int M_NumUniqueVertices(pMesh pmesh)
{
 return pmesh->numUniqueEntities(0);
}

int M_NumUniqueEdges(pMesh pmesh)
{
 return pmesh->numUniqueEntities(1);
}  

int M_NumUniqueFaces(pMesh pmesh)
{
 return pmesh->numUniqueEntities(2);
}  

int M_NumUniqueRegions(pMesh pmesh)
{
 return pmesh->numUniqueEntities(3);
}  

// **********************************
// common boundary entity
// **********************************


pEntity EN_getRemoteCopy(pMesh mesh,pEntity ent,int pid)
{
#ifdef PARALLEL
  return ent->getRemoteCopy(pid); 
#else
  return (pEntity)0;
#endif  
}

void EN_getRemoteCopies(pMesh mesh,pEntity ent,
                        std::vector<std::pair<pEntity,int> >& remoteCopies)
{
#ifdef PARALLEL
for (mEntity::RCIter rciter=ent->rcBegin();rciter!=ent->rcEnd();++rciter)
  remoteCopies.push_back(std::pair<mEntity*,int> 
                                (rciter->second,rciter->first));
//  cout<<"("<<P_pid()<<") AOMD::EN_getRemoteCopies "<<ent->getUid()
//    <<": #rc ="<<remoteCopies.size()<<endl;
#endif
}

void EN_addRemoteCopy(pMesh mesh, pEntity ent, int remotePid, pEntity remoteCopy)
{
#ifdef PARALLEL
  ent->addRemoteCopy(remotePid,remoteCopy);
#endif
}
  
void EN_deleteRemoteCopy(pMesh mesh, pEntity ent)
{
#ifdef PARALLEL
  if (P_numPE()>1)
    ent->clearRemoteCopies();
#endif
}

AOMD::pmEntity* EN_getCommonBdry(pEntity ent)
{
  return EN_getPClassification(ent);
}

void EN_setCommonBdry(pEntity ent, AOMD::pmEntity* cb)
{
//  assert(ent->getLevel()!=3);
  EN_setPClassification(ent,cb);
}

// **********************************
// entity info
// **********************************
int EN_ownerProc(pEntity ent)
{
  return ent->getOwner();
}
  
bool EN_onPB(pMesh pmesh,pEntity ent)		// return true if the entity is on PB
{
#ifdef PARALLEL
  if (M_numRemoteCopies(pmesh,ent) > 0)
    return true;
  else 
    return false;
#else
  return false;
#endif
}

bool EN_onCB(pEntity ent)		// return true if the entity is on PB
{
  return EN_duplicate(ent);
  
}

const char* EN_getUid(pEntity ent)	// return unique id
{
  return ent->getUid().data();
}

int EN_getId(pEntity ent)		// return id
{
  return ent->getId();
}


void EN_setId(pEntity ent, int id)
{
  ent->setId(id);
}

bool EN_canDeleteAttachedData(pEntity ent,int proc)
{
#ifdef PARALLEL
  if (M_NumPE()==1)
    return false;
  else
    return canDeleteAttachedData(ent,proc);
#else
 return false;
#endif
}
// **********************************
// Mesh migration
// **********************************
void M_setEntityOwnership(pMesh pm)
{
#ifdef PARALLEL
  if (M_NumPE()==1)
    return;

  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  double t1 = ParUtil::Instance()->wTime();

  ParUtil::Instance()->Msg(ParUtil::INFO,"\n****************************\n");
  ParUtil::Instance()->Msg(ParUtil::INFO,"    updateEntityOwnership...\n");
// NEW
  M_updateOwnership(pm);
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  double t2 = ParUtil::Instance()->wTime();      
  ParUtil::Instance()->Msg(ParUtil::INFO,
          "      (t = %f sec)\n",t2-t1);
  ParUtil::Instance()->Msg(ParUtil::INFO,"****************************\n\n");	  
#endif
  return;
}

int M_LoadBalance2(pMesh pm,AOMD_LoadBalancerCallbacks& cb)
{
#ifdef PARALLEL
  if (M_NumPE()==1)
    return 0; 
    ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  double t1 = ParUtil::Instance()->wTime();
  //M_checkCBValidity(pm);
  //ParUtil::Instance()->Msg(ParUtil::INFO,"\n****************************\n");
  //ParUtil::Instance()->Msg(ParUtil::INFO,"    M_checkCBValidity...\n");
  //pm->checkCBValidity();
  //ParUtil::Instance()->Msg(ParUtil::INFO,"****************************\n\n");
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n****************************\n");
  ParUtil::Instance()->Msg(ParUtil::INFO,"    LoadBalance2...\n");
  int from = M_getMaxNum(pm->getDim());
  int to = from -1;
  
  int numMoved = pm->loadBalance2(cb,from,to);
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  double t2 = ParUtil::Instance()->wTime();      
  ParUtil::Instance()->Msg(ParUtil::INFO,
          "      (t = %f sec)\n",t2-t1);
  ParUtil::Instance()->Msg(ParUtil::INFO,"****************************\n\n");	  

  return numMoved;
#else
  return 0;
#endif
}


int M_migrateToOneProc(pMesh pm,int dimToMove,std::list<mEntity*> entList,
                    AOMD_LoadBalancerCallbacks &cb,
                    int dimToKnow,
                    std::vector<pEntity>&rmE,
                    std::vector<pEntity>& newE)
{
#ifdef PARALLEL
  if (M_NumPE()==1)
    return 0;
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  double t1 = ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n****************************\n");
  ParUtil::Instance()->Msg(ParUtil::INFO,"    Migration(");
  int numMigr = pm->migrateToOneProc(dimToMove,entList,cb,dimToKnow,rmE,newE);
  ParUtil::Instance()->Msg(ParUtil::INFO,"numMigr=%d)\n", numMigr);
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  double t2 = ParUtil::Instance()->wTime();      

  ParUtil::Instance()->Msg(ParUtil::INFO,
          "      (t = %f sec)\n",t2-t1);
  ParUtil::Instance()->Msg(ParUtil::INFO,"****************************\n\n");	  
  return numMigr;
#else
  return 0;
#endif
}

// **********************************
// conforming meshAdapt-specific
// **********************************
void M_bdryLinkSetupWithMeshMod(pMesh pm, int min, int max)
{
#ifdef PARALLEL
  if (M_NumPE()>1)
  {
    double t1 = ParUtil::Instance()->wTime();      
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n****************************\n");
  ParUtil::Instance()->Msg(ParUtil::INFO,"    BdryLinkSetup...\n");
    pm->bdryLinkSetupWithMeshMod(min,max);
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  double t2 = ParUtil::Instance()->wTime();      
  ParUtil::Instance()->Msg(ParUtil::INFO,
          "      (t = %f sec)\n",t2-t1);
  ParUtil::Instance()->Msg(ParUtil::INFO,"****************************\n\n");	  
  }
#endif
}


void M_unifyTaggedEdges(pMesh mesh, pMeshDataId tag, std::list<pEntity>& edges)
{
#ifdef PARALLEL
  M_unifyTaggedEntities(tag, edges);
#endif
}


void M_computeUniqueId(pMesh mesh, pMeshDataId tag,int* min, int* max)
{
#ifdef PARALLEL
  if (P_size()==1) return;
    
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  double t1 = ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n****************************\n");
  ParUtil::Instance()->Msg(ParUtil::INFO,"    attach Unique Id...\n");
  attachUniqueId(mesh,tag);
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  double t2 = ParUtil::Instance()->wTime();      
  ParUtil::Instance()->Msg(ParUtil::INFO,
          "      (t = %f sec)\n",t2-t1);
  ParUtil::Instance()->Msg(ParUtil::INFO,"****************************\n\n");
#endif
}

// **********************************
//general parallel util
// **********************************
void M_sync()		//synchronization
{
  P_barrier();
}

int M_Pid()
{
  return P_pid();
}

int M_NumPE()
{
  return P_size();
}

void P_sync()           //synchronization
{
  P_barrier();
}
 
int P_numPE()
{
  return P_size();
}
// Unify the information max and min through all processors
void M_unify(double* max, double* min)
{
#ifdef PARALLEL
  double globalMin=*min, globalMax=*max;
  MPI_Allreduce(max,&globalMax,1,MPI_DOUBLE,MPI_MAX,MPI_COMM_WORLD);
  MPI_Allreduce(min,&globalMin,1,MPI_DOUBLE,MPI_MIN,MPI_COMM_WORLD);
  *max=globalMax;  *min=globalMin;
#endif
}

void M_MergeArray(std::vector<int>& vec)
{
#ifdef PARALLEL
  mergeArray(vec);
#endif
} 

int M_getMaxNum(int num)
{
  if (M_NumPE()==1)
    return num;
#ifdef PARALLEL
  int localMax = num;
  int globalMax = num;
  MPI_Allreduce(&localMax,&globalMax,1,MPI_INT,MPI_MAX,MPI_COMM_WORLD);
  return globalMax;
#endif
}

// **********************************
// debug functions
// **********************************

  
  bool M_PrintAdjacencyInfo(pMesh pm,int dim,int adjDim)
  {
   for (mMesh::iterall it = pm->beginall(dim); it!=pm->endall(dim);++it)
   { 
      pEntity e = *it;
      int numAdjEnt = e->size(adjDim);     
      cout<<"("<<M_Pid()<<") M_Test: "<<e->getUid()<<": ";
      for (int i=0;i<numAdjEnt;++i)
      {  
        pEntity adjEnt = e->get(adjDim,i);
        if (!adjEnt) 
        { cout<<"ERROR! ";
          cout<<"("<<M_Pid()<<") "<<i<<"'th adjEnt is not accessible\n";
          return false;
        }
        else
          cout<<adjEnt->getUid()<<", "; 
      } 
      cout<<endl;
   }
   cout<<"("<<M_Pid()<<") M_TestAdjacency("<<dim<<","<<adjDim<<") DONE!\n"; 
   return true;
}

// this will print the mesh entity information 
void M_PrintEntityInfo(pEntity pe)
{
  pe->print();
}

// this will print all the mesh entities information including 
// 	- classification
// 	- common boundary

// Note this funtion cannot be called for test/pAOMD3/main.cc
void M_PrintNumEntitiesInfo(pMesh theMesh)
{
  theMesh->printNumEntities();
}  

// **********************************
// miscellaneous - asked by skocak, May 01, 2002
// **********************************
void M_AssignUniqueRange (pMesh pm, 
	  		       pMeshDataId tag1,
			       pMeshDataId tag2, 
			       std::vector<pEntity> &l1,
			       std::vector<int> &l2, 
			       int initialId)
{
#ifdef PARALLEL
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  double t1 = ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n****************************\n");
  ParUtil::Instance()->Msg(ParUtil::INFO,"    M_AssignUniqueRange\n");
  assignUniqueRange(pm,l1,l2,tag1,tag2,initialId);
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  double t2 = ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,
          "      (t = %f sec)\n",t2-t1);
  ParUtil::Instance()->Msg(ParUtil::INFO,"****************************\n\n");
#endif
  return;
}

#endif   /* ifndef SIM */
