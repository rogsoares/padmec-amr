/******************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*********************************************************************************/

/*<i> ****************************************************************************
 *
 *  AOMD/cint/PARALLEL.cc
 *  Created by Seegyoung Seol, on Mon Dec 15 2003, 10:26:37 EDT
 *
 *  File Content: AOMD c-iterface for PARALLEL
 *
 *************************************************************************** </i>*/
 
#ifndef SIM
#include <algorithm>

#include "AOMD_cint.h"
#include "ParUtil.h"

#ifdef PARALLEL
#include "autopack.h"
#include "pmUtility.h"
#include "pmModel.h"
#endif

using namespace AOMD;
using std::cout;
using std::endl;
using std::vector;

double P_getMaxDbl(double num)
{
  if (P_size()==1)
    return num;
#ifdef PARALLEL
  double localMax = num;
  double globalMax = num;
  MPI_Allreduce(&localMax,&globalMax,1,MPI_DOUBLE,MPI_MAX,MPI_COMM_WORLD);
  return globalMax;
#endif
}

double P_getMinDbl(double num)
{
  if (P_size()==1)
    return num;
#ifdef PARALLEL
  double localMin = num;
  double globalMin = num;
  MPI_Allreduce(&localMin,&globalMin,1,MPI_DOUBLE,MPI_MIN,MPI_COMM_WORLD);
  return globalMin;
#endif
}

double P_getSumDbl(double num)
{
  if (P_size()==1)
    return num;
#ifdef PARALLEL
  double localSum = num;
  double globalSum = num;
  MPI_Allreduce(&localSum,&globalSum,1,MPI_DOUBLE,MPI_SUM,MPI_COMM_WORLD);
  return globalSum;
#endif
}

double P_wtime()
{return AOMD::ParUtil::Instance()->wTime(); }

void P_unifyMinMax(double* max, double* min)
{
#ifdef PARALLEL
  double globalMin=*min, globalMax=*max;
  MPI_Allreduce(max,&globalMax,1,MPI_DOUBLE,MPI_MAX,MPI_COMM_WORLD);
  MPI_Allreduce(min,&globalMin,1,MPI_DOUBLE,MPI_MIN,MPI_COMM_WORLD);
  *max=globalMax;  *min=globalMin;
#endif
}

void P_mergeArray(std::vector<int>& vec)
{
#ifdef PARALLEL
  mergeArray(vec);
#endif
} 

int P_getMaxInt(int num)
{
  if (P_size()==1)
    return num;
#ifdef PARALLEL
  int localMax = num;
  int globalMax = num;
  MPI_Allreduce(&localMax,&globalMax,1,MPI_INT,MPI_MAX,MPI_COMM_WORLD);
  return globalMax;
#endif
}

int P_getMinInt(int num)
{
  if (P_size()==1)
    return num;
#ifdef PARALLEL
  int localMin = num;
  int globalMin = num;
  MPI_Allreduce(&localMin,&globalMin,1,MPI_INT,MPI_MIN,MPI_COMM_WORLD);
  return globalMin;
#endif
}

int P_getSumInt(int num)
{
  if (P_size()==1)
    return num;
#ifdef PARALLEL
  int localSum = num;
  int globalSum = num;
  MPI_Allreduce(&localSum,&globalSum,1,MPI_INT,MPI_SUM,MPI_COMM_WORLD);
  return globalSum;
#endif
}


void P_barrier()           //synchronization
{
#ifdef PARALLEL
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
#endif
}

int P_size()
{
#ifdef PARALLEL
  return ParUtil::Instance()->size() ;
#else
  return 1;
#endif
}
 
int P_pid()
{
#ifdef PARALLEL
  return ParUtil::Instance()->rank();
#else
  return 0;
#endif
}

void P_getGlobal(int in, vector<int>& output)
{
#ifdef PARALLEL
  unsigned int numPE = ParUtil::Instance()->size();
  output.resize(numPE);
  int* senddata;
  int* recvdata;

  // send phase begins
  int* sendcounts=new int[numPE];
  for (unsigned int i=0;i<numPE;++i) sendcounts[i]=0;
 

  for (unsigned int pid=0;pid<numPE;++pid)
  {
    if ((unsigned int)ParUtil::Instance()->rank() != pid)
    {
      senddata = (int*)AP_alloc(pid,554,sizeof(int)*(2));
      senddata[0]=ParUtil::Instance()->rank();
      senddata[1]=in;
      AP_send(senddata);
      sendcounts[pid]++;      
    }
  }
  
  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts);

  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  int message=0;
  int count;
  while(!AP_recv_count(&count)||message<count)
  {
    int from,tag,size,rc;
  // receive phase begins
    rc=AP_recv(MPI_ANY_SOURCE,554,AP_BLOCKING|AP_DROPOUT,
               (void**)&recvdata,&size,&from,&tag);
    if (rc)
    {
      message++;
      output[recvdata[0]] = recvdata[1];
      AP_free(recvdata);
    }  // if(rc)
  } // while
  AP_check_sends(AP_WAITALL);
  delete [] sendcounts;
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);

  output[ParUtil::Instance()->rank()] = in;
//  for (unsigned int i=0; i<output.size();++i)
//    cout<<"("<<P_pid()<<") output[pid="<<i<<", dim="<<dim<<" = "<<output[i]<<endl;  
#else
  output.push_back(in);
#endif
}
 
#endif   /* ifndef SIM */
