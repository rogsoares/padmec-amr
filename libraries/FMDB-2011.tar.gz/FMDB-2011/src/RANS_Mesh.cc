/**************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*****************************************************************************/
#include "RANS_Mesh.h"
#include "AOMD_Internals.h"
#include "mAOMD.h"
#include "mMesh.h"
#include "mVertex.h"
#include "mEdge.h"
#include "mFace.h"
#include "mHex.h"
#include "LagrangeMapping.h"
#include "Integrator.h"
#include <math.h>

#include "modeler.h"

using namespace AOMD;

static mMesh *MESH = 0;
static mVertex **NODES = 0;
static mEdge   **EDGES = 0;
static mFace   **FACES = 0;
static mRegion **HEXES = 0;

void loadmesh_ ( char * fortname)
{

  char filename[256];

  int i=0;
  /// Bidouille en attendant mieux
  while(1)
    {
      filename[i] = fortname[i];
      if (i >= 3 && 
	  filename[i-3] == '.' &&
	  filename[i-2] == 'm' &&
	  filename[i-1] == 's' &&
	  filename[i-0] == 'h')
	{
	  filename[i+1] ='\0';
	  break;
	}
      i++;
      
    }

  if (MESH) 
    {
      fprintf (stderr, "RANS_Mesh ERROR : a mesh has already been loaded, delete it first\n");
      return;
    }
  MESH = new mMesh;
  AOMD_Util::Instance()->import(filename,MESH);  
  M_SetRepresentationToOneLevel((pMesh)MESH);  

  int count = 0;
  NODES = new mVertex*[MESH->size(0)];
  for (mMesh::iter it = MESH->begin(0);
       it != MESH->end(0);
       ++it)
    {
      (*it)->attachInt (AOMD_Util::Instance()->getId(),count);
      NODES[count++] = (mVertex*) *it;
    }

  count = 0;
  EDGES = new mEdge*[MESH->size(1)];
{
  for (mMesh::iter it = MESH->begin(1);
       it != MESH->end(1);
       ++it)
    {
      (*it)->attachInt (AOMD_Util::Instance()->getId(),count);
      EDGES[count++] = (mEdge*) *it;
    }
}
  count = 0;
  FACES = new mFace*[MESH->size(2)];
{
  for (mMesh::iter it = MESH->begin(2);
       it != MESH->end(2);
       ++it)
    {
      (*it)->attachInt (AOMD_Util::Instance()->getId(),count);
      FACES[count++] = (mFace*) *it;
    }
}
  if (MESH->getDim() == 2) return;

  count = 0;
  HEXES = new mRegion*[MESH->size(3)];
{
  for (mMesh::iter it = MESH->begin(3);
       it != MESH->end(3);
       ++it)
    {
      (*it)->attachInt (AOMD_Util::Instance()->getId(),count);
      HEXES[count++] = (mRegion*) *it;
    }
}
}

inline void ASSERTMESH (const char *name)
{
  if (!MESH)
    {
      fprintf (stderr, "RANS_Mesh ERROR in %s : No Mesh Has been loaded\n",name);    
      exit(-1);
    }
}

void numnod_ ( int *NumNodes ) {ASSERTMESH("NumberOfNodes");*NumNodes = MESH->size(0);}
void numedg_ ( int *NumNodes ) {ASSERTMESH("NumberOfEdges");*NumNodes = MESH->size(1);}
void numfac_ ( int *NumNodes ) {ASSERTMESH("NumberOfFaces");*NumNodes = MESH->size(2);}
void numhex_ ( int *NumNodes ) {ASSERTMESH("NumberOfHexes");*NumNodes = MESH->size(3);}

void xyznod_ ( int *iNode , double X[3] )
{
  ASSERTMESH("CoordinatesOfNodes");
  Trellis_Util::mPoint p = NODES[*iNode]->point();
  X[0] = p(0);
  X[1] = p(1);
  X[2] = p(2);
}

void nodhex_ ( int *iHex, int Nodes[8] )
{
  ASSERTMESH(" NodesOfHex");
  mRegion *reg = HEXES[*iHex];
  for (int i=0; i< reg->size(0);i++)
    Nodes[i] = reg->get(0,i)->getAttachedInt(AOMD_Util::Instance()->getId());
}

void edghex_ ( int *iHex, int Edges[12] )
{
  ASSERTMESH(" NodesOfHex");
  mRegion *reg = HEXES[*iHex];
  for (int i=0; i< reg->size(1);i++)
    Edges[i] = reg->get(1,i)->getAttachedInt(AOMD_Util::Instance()->getId());
}

void fachex_ ( int *iHex, int Faces[6] )
{
  ASSERTMESH(" FacesOfHex");
  mRegion *reg = HEXES[*iHex];
  for (int i=0; i< reg->size(2);i++)
    Faces[i] = reg->get(2,i)->getAttachedInt(AOMD_Util::Instance()->getId());
}

void nodfac_ ( int *iFace, int Nodes[4] )
{
  ASSERTMESH(" NodesOfFace");
  mFace *face = FACES[*iFace];
  for (int i=0; i< face->size(0);i++)
    Nodes[i] = face->get(0,i)->getAttachedInt(AOMD_Util::Instance()->getId());
}

void edgfac_ ( int *iFace, int Edges[4] )
{
  ASSERTMESH(" EdgesOfFace");
  mFace *face = FACES[*iFace];
  for (int i=0; i< face->size(1);i++)
    Edges[i] = face->get(1,i)->getAttachedInt(AOMD_Util::Instance()->getId());
}

void facfac_ ( int *iFace, int Faces[4] )
{
  int Edges[4];
  int lFaces[2];
  ASSERTMESH(" FacesOfFace");
  mFace *face = FACES[*iFace];
{
  for (int i=0; i< face->size(1);i++)
    Edges[i] = face->get(1,i)->getAttachedInt(AOMD_Util::Instance()->getId());
}
{
  for (int i=0; i< face->size(1);i++)
    {
      facedg_(&Edges[i],lFaces);
      if (lFaces[0] == *iFace)
	Faces[i] = lFaces[1];
      else
	Faces[i] = lFaces[0];
    }
	}
}

void hexhex_ ( int *iHex, int Hexes[8] )
{
  int Faces[6];
  int lHexes[2];
  ASSERTMESH(" HexOfHex");
  mRegion *hex = HEXES[*iHex];
  for (int i=0; i< hex->size(2);i++)
    Faces[i] = hex->get(2,i)->getAttachedInt(AOMD_Util::Instance()->getId());
{
  for (int i=0; i< hex->size(2);i++)
    {
      hexfac_(&Faces[i],lHexes);
      if (lHexes[0] == *iHex)
	Hexes[i] = lHexes[1];
      else
	Hexes[i] = lHexes[0];
    }
}
}

void hexfac_ ( int *iFace, int Hexes[2] )
{
  ASSERTMESH(" HexesOfFace");
  mFace *face = FACES[*iFace];
  /// put -face zone if there is only one neighbor
  Hexes[1] = - GEN_tag(face->getClassification());
  for (int i=0; i< face->size(3);i++)
    Hexes[i] = face->get(3,i)->getAttachedInt(AOMD_Util::Instance()->getId());
}

void nodedg_ ( int *iEdge, int Nodes[2] )
{
  ASSERTMESH(" NodesOfEdge");
  mEdge *edge = EDGES[*iEdge];
  for (int i=0; i< edge->size(0);i++)
    Nodes[i] = edge->get(0,i)->getAttachedInt(AOMD_Util::Instance()->getId());
}

void facedg_ ( int *iEdge, int Faces[2] )
{
  ASSERTMESH(" FacesOfEdge");
  mEdge *edge = EDGES[*iEdge];
  /// put -edge zone if there is only one neighbor
  Faces[1] = - GEN_tag(edge->getClassification());
  for (int i=0; i< edge->size(2);i++)
    Faces[i] = edge->get(2,i)->getAttachedInt(AOMD_Util::Instance()->getId());
}

void nedgnod_ ( int *iNode, int *numEdges )
{
  ASSERTMESH(" NumEdgesOfNode");
  mVertex *vertex = NODES[*iNode];
  mAdjacencyContainer ents;  
  vertex->getHigherOrderUpward(1,ents);
  *numEdges = ents.size();
}

void edgnod_    ( int *iNode, int *Edges    )
{
  ASSERTMESH(" EdegsOfNode");
  mVertex *vertex = NODES[*iNode];
  mAdjacencyContainer ents;  
  vertex->getHigherOrderUpward(1,ents);
  for (int i=0;i<ents.size();i++)
    Edges[i] = ents[i]->getAttachedInt(AOMD_Util::Instance()->getId());
}

void nfacnod_ ( int *iNode, int *numFaces )
{
  ASSERTMESH(" NumFacesOfNode");
  mVertex *vertex = NODES[*iNode];
  mAdjacencyContainer ents;  
  vertex->getHigherOrderUpward(2,ents);
  *numFaces = ents.size();
}

void facnod_    ( int *iNode, int *Faces    )
{
  ASSERTMESH(" FacesOfNode");
  mVertex *vertex = NODES[*iNode];
  mAdjacencyContainer ents;  
  vertex->getHigherOrderUpward(2,ents);
  for (int i=0;i<ents.size();i++)
    Faces[i] = ents[i]->getAttachedInt(AOMD_Util::Instance()->getId());
}

void nhexnod_ ( int *iNode, int *numHexes )
{
  ASSERTMESH(" NumHexesOfNode");
  mVertex *vertex = NODES[*iNode];
  mAdjacencyContainer ents;  
  vertex->getHigherOrderUpward(3,ents);
  *numHexes = ents.size();
}

void hexnod_    ( int *iNode, int *Hexes    )
{
  ASSERTMESH(" FacesOfNode");
  mVertex *vertex = NODES[*iNode];
  mAdjacencyContainer ents;  
  vertex->getHigherOrderUpward(3,ents);
  for (int i=0;i<ents.size();i++)
    Hexes[i] = ents[i]->getAttachedInt(AOMD_Util::Instance()->getId());
}

void surfac_ ( int *iFace, double *s)
{
  double pos[3],weight,detJac;
  ASSERTMESH(" HexesOfFace");
  mFace *face = FACES[*iFace];

  Trellis_Util::LagrangeMapping m ((pEntity)face);
  Trellis_Util::GaussIntegrator myIntegrator (m.getEntity());

  int nbPt =  myIntegrator.nbIntegrationPoints(1);
  *s = 0.0;
  for (int iPt=0 ; iPt<nbPt; ++iPt)
    {
      myIntegrator.iPoint(iPt, 1, pos[0], pos[1], pos[2], weight);
      detJac = m.detJac(pos[0],pos[1],pos[2]);
      *s += weight * detJac;
    }
}

void volume_ ( int *iHex, double *v)
{
  double pos[3],weight,detJac;
  ASSERTMESH(" VolumeOfHex");
  mRegion *reg = HEXES[*iHex];

  Trellis_Util::LagrangeMapping m ((pEntity)reg);
  Trellis_Util::GaussIntegrator myIntegrator (m.getEntity());

  int nbPt =  myIntegrator.nbIntegrationPoints(1);
  *v = 0.0;
  for (int iPt=0 ; iPt<nbPt; ++iPt)
    {
      myIntegrator.iPoint(iPt, 1, pos[0], pos[1], pos[2], weight);
      detJac = m.detJac(pos[0],pos[1],pos[2]);
      *v += weight * detJac;
    }
   *v = fabs(*v);
}

void nvect2d_ ( int *iEdge, int *iFace, double *n)
{
  ASSERTMESH(" NormalVector2D");
  mFace *face = FACES[*iFace];
  mEdge *edge = EDGES[*iEdge];
  Trellis_Util::mVector NV;

  Trellis_Util::LagrangeMapping m ((pEntity)face);
  m.normalVector ((pEntity)edge , 0.,0.,0.,NV);

  
  n[0] = NV(0);
  n[1] = NV(1);
  n[2] = NV(2);  
}

void nvect3d_ ( int *iFace, int *iHex, double *n)
{
  ASSERTMESH(" NormalVector3D");
  double x,y,z,u,v,w;
  mFace *face = FACES[*iFace];
  mRegion *reg = HEXES[*iHex];
  Trellis_Util::mVector NV;

  Trellis_Util::LagrangeMapping m ((pEntity)reg);
  Trellis_Util::LagrangeMapping m2 ((pEntity)face);
  m2.eval(0,0,0,x,y,z);
  m.invert(x,y,z,u,v,w);
  m.normalVector ((pEntity)face,u,v,w,NV);
  
  n[0] = NV(0);
  n[1] = NV(1);
  n[2] = NV(2);  
}

void zonfac_ ( int *iFace , int *iZone )
{
  ASSERTMESH(" ZoneOfFace");
  mFace *face = FACES[*iFace];
  *iZone = - GEN_tag(face->getClassification());
}

void zonedg_ ( int *iEdge , int *iZone )
{
  ASSERTMESH(" ZoneOfEdge");
  mEdge *edge = EDGES[*iEdge];
  *iZone = - GEN_tag(edge->getClassification());
}

void zonenod_ ( int *iNod , int *iZone )
{
  ASSERTMESH(" ZoneOfNod");
  mVertex *v = NODES[*iNod];
  *iZone = GEN_tag(v->getClassification());
}


void opface_ (int *iHex, int *iFace1, int *iFace2)
{
  ASSERTMESH(" OppFace");

  const int opp[6] = {5,3,4,1,2,0};

  mFace *face1 = FACES[*iFace1];
  mRegion *reg = HEXES[*iHex];
  
  for (int i=0;i<6;i++)
    if (face1 == reg->get(2,i)) *iFace2 = reg->get(2,opp[i])->getAttachedInt(AOMD_Util::Instance()->getId());
}

void opedge_ (int *iFace, int *iEdge1, int *iEdge2)
{
  ASSERTMESH(" OppEdge");

  const int opp[4] = {2,3,0,1};

  mEdge *edge1 = EDGES[*iEdge1];
  mFace *face = FACES[*iFace];
  
  for (int i=0;i<4;i++)
    if (edge1 == face->get(1,i)) *iEdge2 = face->get(1,opp[i])->getAttachedInt(AOMD_Util::Instance()->getId());
}

void otherhex_(int *iHex, int *iFace1, int *iHex2)
{
  ASSERTMESH(" OppFace");

  mFace *face1 = FACES[*iFace1];
  if (*iHex < 0)
  {
	*iHex2 = face1->get(3,0)->getAttachedInt(AOMD_Util::Instance()->getId());
	return;
  }

  mEntity *reg = HEXES[*iHex];
  
  if (face1->size(3) == 1) *iHex2 = - GEN_tag(face1->getClassification());
  else if (face1->get(3,0) == reg) *iHex2 = face1->get(3,1)->getAttachedInt(AOMD_Util::Instance()->getId());
  else if (face1->get(3,1) == reg) *iHex2 = face1->get(3,0)->getAttachedInt(AOMD_Util::Instance()->getId());    
  else fprintf (stderr, "RANS_Mesh ERROR in %s : face %d does not belong to hex %d\n","otherhex_",
		*iFace1,*iHex);        
}

void hexfachex_(int *iHex1, int *iHex2 , int *iFace)
{
  mRegion *reg1 = (mRegion*) HEXES[*iHex1];
  mRegion *reg2 = (mRegion*) HEXES[*iHex2];

  mFace *f = reg1->commonFace(reg2);

  if (!f)	
	 fprintf (stderr, "RANS_Mesh ERROR in %s : Those 2 hexes have no common face\n","hexfachex");    

  *iFace = GEN_tag(f->getClassification());
}

void coghex_(int *iHex, double *x)
{
  double u,v,w;
  ASSERTMESH(" CogHex");
  mRegion *reg = HEXES[*iHex];
  Trellis_Util::LagrangeMapping m ((pEntity)reg);
  m.COG(u,v,w);
  m.eval(u,v,w,x[0],x[1],x[2]);
}

void cogfac_(int *iFac, double *x)
{
  double u,v,w;
  ASSERTMESH(" CogFac");
  mFace *fac = FACES[*iFac];
  Trellis_Util::LagrangeMapping m ((pEntity)fac);
  m.COG(u,v,w);
  m.eval(u,v,w,x[0],x[1],x[2]);
}
