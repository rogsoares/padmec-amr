/******************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*********************************************************************************/

/*<i> ****************************************************************************
 *
 *  AOMD/parallel/pmMigrateUtil.cc
 *  Created by Eunyoung Seol, on Mon Sep 30 2003, 10:26:37 EDT
 *
 *  File Content: function definition what are used for migration
 *
 *************************************************************************** </i>*/

#include <stdio.h>
#include <iostream>
#include <assert.h>
#include "mMigrateUtil.h"
#include "pmModelUtil.h"


#include "AOMD_OwnerManager.h"
#include "AOMD_LoadBalancer.h"
#include "mAttachableDataContainer.h"
#include "mMesh.h"
#include "mEntity.h"
#include "mException.h"
#include "mEdge.h"
#include "mVertex.h"
#include "mRegion.h"
#include "ParUtil.h"
#include "AOMD_Internals.h"
#include "AOMD_cint.h"
#ifdef PARALLEL
#include "autopack.h"
#include "mExchangeData.h"
#endif
#include "pmGraphs.h"
#include "mAOMD.h"
#include <list>

using std::list;
using std::pair;
using std::vector;

namespace AOMD {

//this one give the pid that is poor
int getPid_withBalance(mMesh* mesh, mEntity* ent, vector<int>& poor_to_rich_pids)
{
#ifdef PARALLEL
  AOMD_OwnerManager* o = mesh->theOwnerManager;
  AOMD_OwnerManager::iter it = o->begin(ent);
  AOMD_OwnerManager::iter itend = o->end(ent);
  
  int owner=ParUtil::Instance()->rank();
  vector<int> allPids;
  vector<int>::iterator pidIter=poor_to_rich_pids.begin();
  
  allPids.push_back(ParUtil::Instance()->rank());

  for (;it != itend;++it) {
    allPids.push_back((*it).second.pid());
  }
  
  for (;pidIter!=poor_to_rich_pids.end();++pidIter)
  {
    if (std::find(allPids.begin(),allPids.end(),*pidIter)!=allPids.end())
    {  
      owner=*pidIter;
      break;
    }
  }
//  cout<<"\t* ("<<M_Pid()<<") pid_withBalance of "<<ent->getUid()<<" : "<<owner<<endl;
  return (owner);
#else
  return 0;
#endif
}


#ifdef PARALLEL
// ***********************************************************
void setEntitiesToMoveFromVertices_withBalance(mMesh* mesh, 
                   list<mEntity*>& entities)
// ***********************************************************
{
  // get the entities to move and their owner processor
  unsigned int tagMark=AOMD_Util::Instance()->lookupMeshDataId("_pid");
  int dim=M_globalMaxDim(mesh);
  mEntity* ent;
  mEntity* vt;
  int owner;
  vector<int> poor_to_rich_pids;
  
  getSortedPids_poor_to_rich(mesh,poor_to_rich_pids);
  
  list<mEntity*>::iterator vit=entities.begin();
  for (; vit!=entities.end();++vit)
  {
    mEntity* v = *vit;
    AOMD::mAdjacencyContainer upward;
    v->getHigherOrderUpward (dim,upward);
    int owner = getPid_withBalance(mesh, v, poor_to_rich_pids);
    assert(owner == v->getCommonBdry()->getOwner());
    for (int i=0; i<upward.size();++i)
    {
      mRegion* r = (mRegion*) upward[i];
      if (r->getData(tagMark))
      {  
        if (r->getAttachedInt(tagMark)>owner)
        {
          r->deleteData(tagMark);
          r->attachInt(tagMark,owner);
        }
      }
      else
      {
        r->attachInt(tagMark,owner);
      }
    } //upward
  } // vit
}
#endif

} // end of namespace
