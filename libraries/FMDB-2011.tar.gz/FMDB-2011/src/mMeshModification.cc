/******************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*********************************************************************************/

/*****************************************************************************
 *
 *  partition2/pmMeshModification.cc
 *  Created by Eunyoung Seol, on Mon Mar 04 2002, 10:26:37 EDT
 *
 *  File Content: parallel mesh modification support functions
 *                such as, computeUniqueId(), bdryLinkSetupWithMeshMod()
 *
 ****************************************************************************/

#ifdef PARALLEL

#include "mParallelUtility.h"
#include "ParUtil.h"
#include "mExchangeData.h"
#include "mIdGenerator.h"
#include "AOMD_OwnerManager.h"
#include "mAttachableDataContainer.h"
#include "mMesh.h"
#include "mEntity.h"
#include "ParUtil.h"
#include "AOMD_Internals.h"
#include "AOMD_cint.h"

#include "autopack.h"
#include "mAOMD.h"

#include <stdio.h>
#include <iostream>
#include <assert.h>
#include <vector>
#include <algorithm>

using std::cout;
using std::endl;
using std::vector;
using std::string;
using std::find;

namespace AOMD {

// every program should call this function before creating vertices 
// on PB and use getAttachedDataInt(aomdtag) as an vertex id on PB 
//*************************************************************
void computeUniqueId(mMesh* theMesh, unsigned int aomdtag, int* minId, int* maxId)
//*************************************************************
{ 
  if (ParUtil::Instance()->size()==1)
    return;

  int localMaxId, globalMaxId;
  int localMinId, globalMinId;

  localMinId =theMesh->getIdGenerator().getMaxValue();
  globalMinId = localMinId;
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  MPI_Allreduce(&localMinId,&globalMinId,1,MPI_INT,MPI_MAX,MPI_COMM_WORLD);
  *minId = globalMinId+1;
  theMesh->pmSetNewVertexId(globalMinId - ParUtil::Instance()->size()
                          +ParUtil::Instance()->rank()+1);

  // count how many of mesh entities on VEC are owned by the actual processor
  AOMD_OwnerManager* o = theMesh->theOwnerManager;
  AOMD_OwnerManager::iter it, itend;
   
  int* sendcounts = new int[ParUtil::Instance()->size()];
  for (int i=0; i<ParUtil::Instance()->size(); ++i) sendcounts[i]=0;

  mMesh::iterall eit=theMesh->beginall(1);
  for (;eit!=theMesh->endall(1);++eit)
  {
    mEntity* entity = *eit;
    if (EN_onCB(entity) && 
        entity->getOwner()==ParUtil::Instance()->rank())
    {
      int id=theMesh->getNewVertexId();
//      cout<<"("<<M_Pid()<<") got a new vtId "<<id<<endl;
      entity->attachInt(aomdtag, id);
      // iterate over on AOMD_SharedInfo
      it= o->begin(entity);
      itend = o->end(entity);
	
      while(it!= itend) 
      { 
        // send phase begins to find the entity in the counterpart
	// and assign the same id		
	void* buf = AP_alloc((*it).second.pid(), 445, sizeof(rp_int));
//	cout<<"("<<M_Pid()<<") ComputeUId::attach vtId "<<id<<" to "<<entity->getUid()
//	    <<" in P"<<(*it).second.pid()<<endl;
	rp_int* castbuf = (rp_int *)buf;
	AOMD_SharedInfo si = (*it).second;
	castbuf->entity = si.getRemotePointer();
	castbuf->i = id;
	AP_send(buf);
	sendcounts[(*it).second.pid()]++;
	++it;
      } // while
    } // if (Owner)
  }  // for
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  // receive phase begins
  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts);
  int message=0;
  int count;
  while(!AP_recv_count(&count) || message<count)
  {
    void* msg;
    int from, tag, size, rc;
    rc = AP_recv(MPI_ANY_SOURCE, 445, AP_BLOCKING|AP_DROPOUT, &msg, &size, &from, &tag);
    if (rc)
    {
      message++;
      rp_int* castbuf = (rp_int*) msg;
      castbuf->entity->attachInt(aomdtag, castbuf->i);
//      cout<<"("<<M_Pid()<<") attach vtId "
//          <<castbuf->i<<" to "<<castbuf->entity->getUid()<<endl;
      AP_free(msg);	
    }  // end of if (rc)
  }  // end of while(!AP...)
    
  AP_check_sends(AP_WAITALL);
  delete[] sendcounts; 

  // update maximumValue of mIdGenerator
  localMaxId =theMesh->getIdGenerator().getMaxValue();
  globalMaxId = localMaxId;
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  MPI_Allreduce(&localMaxId,&globalMaxId,1,MPI_INT,MPI_MAX,MPI_COMM_WORLD);
// set *minId and *maxId
  *maxId = globalMaxId;
  theMesh->pmSetNewVertexId(globalMaxId - ParUtil::Instance()->size()
                          +ParUtil::Instance()->rank()+1);

//  cout<<"("<<M_Pid()<<") ComputeUniqueId::theIdGenerator.getNewVertexId()="<<
//  theMesh->getNewVertexId()<<endl;
} // end of computeVtIDonPB(..)

//*************************************************************
void getVerticesOnPB(mMesh* theMesh, int minOnPB, int maxOnPB, 
                    vector<int>& vtOnPB)
//*************************************************************
{
  int id;
  for (mMesh::iterall it = theMesh->beginall(0);
       it!=theMesh->endall(0); ++it)
  {
    id = (*it)->getId();    
    if (M_numRemoteCopies(theMesh, *it)>0 || ((id>= minOnPB)&&(id<=maxOnPB)))
     vtOnPB.push_back(id);
  } 
//  cout<<"getVerticesOnPB::vtOnPB.size()="<<vtOnPB.size()<<endl;
}

//*************************************************************
static void attachDestPid (mEntity *e, bool mark, unsigned int mk,int part)
//*************************************************************
{
  if(!mark)
    {
      if(e->getData(mk))
        e->deleteData(mk);
    }
  else
    {
      mAttachableIntVector *avec;
      if(e->getData(mk))
	{
	  avec = (mAttachableIntVector*)e->getData(mk);
	}
      else
	{
	  avec = new mAttachableIntVector;
	  e->attachData(mk,avec);
	}
      for(int i=0;i<avec->v.size();i++)if(avec->v[i] == part)return;
//      cout<<"On proc "<<M_Pid()<<" "<<e->getUid()
//          <<" adds a new pid "<<part<<endl;
      avec->v.push_back(part);
    }
}

/*
  e is going to be migrated
  markAllSubs tag entities that are going to be migrated
  e is initially an entity that is to be migrated, we look
  after all sub-entities and tag them also.
*/

//*************************************************************
static void markEntity(mEntity *e, int part)
//*************************************************************
{
  unsigned int tagMark = AOMD_Util::Instance()->lookupMeshDataId("_dest");
  attachDestPid(e, true, tagMark, part);
}


//void bdryLinkSetupWithMeshMod(mMesh* theMesh, int minOnPB, int maxOnPB)
///*************************************************************
void resetDests(mMesh* theMesh, int minOnPB, int maxOnPB)
//*************************************************************
{
  if (ParUtil::Instance()->size()==1)
    return;
  vector<int> vtOnPB;
  getVerticesOnPB(theMesh,minOnPB,maxOnPB,vtOnPB);

  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  
  int* senddata;
  int* recvdata;
  int numPE = ParUtil::Instance()->size();
  int* sendcounts=new int[numPE];
  for (int i=0; i<ParUtil::Instance()->size(); ++i) sendcounts[i]=0;

  for (int d = 0; d<3; ++d)
  {
    for (mMesh::iter it=theMesh->begin(d); it!=theMesh->end(d); ++it)
    {
      mEntity* e = *it;
      markEntity(e,ParUtil::Instance()->rank());
      bool isOnPB=true;
      int numVt = e->size(0);

      if (d>0) //edge, face, region
      {
        int numVt = e->size(0);
        for (int i=0;i<numVt;++i)
	  if (find(vtOnPB.begin(), vtOnPB.end(), e->get(0,i)->getId()) 
	      == vtOnPB.end())      
    	  { isOnPB = false; break; }
        
      }
      else //vertex
        if (find(vtOnPB.begin(), vtOnPB.end(), 
	    e->getId()) == vtOnPB.end()) 
	    isOnPB=false;

      if (isOnPB) // entity is on PB, thus exchande the info
      {
        if (d==0)
	{
          for (int pid=0; pid<numPE;++pid)
          {
            if (ParUtil::Instance()->rank() != pid)
            {
              senddata = (int*)AP_alloc(pid,554,sizeof(int)*(2));
	      senddata[0]=1;
              senddata[1]=e->getId();
              AP_send(senddata);
              sendcounts[pid]++;
            }
          }
	
	} // vertex is on PB
	else
	{
          for (int pid=0; pid<numPE;++pid)
          {
            if (ParUtil::Instance()->rank() != pid)
            {
              senddata = (int*)AP_alloc(pid,554,sizeof(int)*(1+numVt));
	      senddata[0]=numVt;
   	      for (int i=0;i<numVt;++i)
	        senddata[i+1]=e->get(0,i)->getId();
              AP_send(senddata);
              sendcounts[pid]++;
            }
          }
	} // else (edge, face, region is on PB
      } //if (isOnPB)
    }
  }

  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts);
  int message=0;
  int count;
  mEntity* e;
  while(!AP_recv_count(&count)||message<count)
  {
    int from,tag,size,rc;
  // receive phase begins
    rc=AP_recv(MPI_ANY_SOURCE,554,AP_BLOCKING|AP_DROPOUT,
              (void**)&recvdata,&size,&from,&tag);
    if (rc)
    {
      message++;
      if (recvdata[0]==1) // vertex
      {
//        cout<<"("<<M_Pid()<<") receive ("<<recvdata[0]<<","
//	    <<recvdata[1]<<") from P"<<from<<endl;
	    
        mVertex* v = theMesh->getVertex(recvdata[1]);
	if (v)
	  markEntity((mEntity*)v, from);
      }
      else if (recvdata[0]==2)  //edge
      {

        mVertex* v1=theMesh->getVertex(recvdata[1]);
	mVertex* v2=theMesh->getVertex(recvdata[2]);
	if (v1&&v2)
	{ 
	  mEntity* e = (mEntity*)(theMesh->getEdge(v1,v2));
	  if (e) 
	    markEntity(e, from);
	}
      }
      else if (recvdata[0]==3)  //tri
      {
         mVertex* v1=theMesh->getVertex(recvdata[1]);
	mVertex* v2=theMesh->getVertex(recvdata[2]);
	mVertex* v3=theMesh->getVertex(recvdata[3]);
	if (v1&&v2&&v3)
	{
	  mEntity* e = (mEntity*)(theMesh->getTri(v1,v2,v3));
	  if (e) 
	    markEntity(e, from);
	}
      }
      AP_free(recvdata);
    }  // if(rc)
  } // while
  AP_check_sends(AP_WAITALL);
  delete [] sendcounts;
 }


//*************************************************************
void mMesh::bdryLinkSetupWithMeshMod(int minOnPB, int maxOnPB)
//*************************************************************
{      
  if (ParUtil::Instance()->size()==1)
    return; 
  int parts[1024];
// setup Dests and pClassify vertices
//cout<<"("<<M_Pid()<<") MeshMod::1\n";
  resetDests(this,minOnPB, maxOnPB); 
//cout<<"("<<M_Pid()<<") MeshMod::2\n";
  ParallelReclassifyMeshEntities(3);
//cout<<"("<<M_Pid()<<") MeshMod::4\n";
  bdryLinkSetup();
//cout<<"("<<M_Pid()<<") MeshMod::5\n";
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  unsigned int tagMark = AOMD_Util::Instance()->lookupMeshDataId("_dest");
  for(int i=0;i<4;i++)
    for(mMesh::iterall it = beginall(i) ; it!= endall(i) ; ++it)
      (*it)->deleteData(tagMark);
}

} // end of namespace

#endif
