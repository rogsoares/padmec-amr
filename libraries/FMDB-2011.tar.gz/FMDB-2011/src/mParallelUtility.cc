/******************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*********************************************************************************/

/*****************************************************************************
 *
 *  partition2/pmUtility.cc
 *  Created by Eunyoung Seol, on Mon Mar 04 2002, 10:26:37 EDT
 *
 *  File Content: definition of parallel modules in pmUtility.h *
 ****************************************************************************/

#include "mParallelUtility.h"
#include "ParUtil.h"
#include "AOMD_cint.h"
#include "mExchangeData.h"
#include "AOMD_Internals.h"
#include <stdio.h>
#include <iostream>
#include <assert.h>
#include <vector>
#include <list>
#include <algorithm>

using std::cout;
using std::endl;
using std::vector;
using std::pair;
using std::list;
using std::string;
using std::find;

namespace AOMD {

 
void unify(double *max, double *min)
{
#ifdef PARALLEL
  if (ParUtil::Instance()->size()==1)
    return;
  double* senddata;
  double* recvdata;
  // send phase begins
  int numPE = ParUtil::Instance()->size();
  int* sendcounts=new int[numPE];
  for (int i=0;i<numPE;++i) sendcounts[i]=0;
 
  for (int i=0; i<numPE;++i)
  {
    if (ParUtil::Instance()->rank() != i)
    {
      senddata = (double*)AP_alloc(i,955,sizeof(double)*2);
      senddata[0] = *max;
      senddata[1] = *min;
      AP_send(senddata);
      sendcounts[i]++;
    }
  }
  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts); 
  int message=0; 
  int count; 
  while(!AP_recv_count(&count)||message<count)
  { 
    int from,tag,size,rc; 
  // receive phase begins
    rc=AP_recv(MPI_ANY_SOURCE,955,AP_BLOCKING|AP_DROPOUT,(void**)&recvdata,&size,&from,&tag);
    if (rc) 
    {  
      message++; 
      if (*max < recvdata[0])
        *max = recvdata[0];
      if (*min > recvdata[1])
        *min = recvdata[1];
      AP_free(recvdata);
    }  // if(rc) 
  } 
  AP_check_sends(AP_WAITALL);
  delete [] sendcounts;
#else
  return;
#endif
} 


void unifyTaggedEdges(mMesh* theMesh, unsigned int attachTag,
     std::list<mEntity*> &LIST)
{

#ifdef PARALLEL
  AOMD_OwnerManager* o = theMesh->theOwnerManager;
  AOMD_OwnerManager::iter it, itend;

  // send phase begins
  int numPE = ParUtil::Instance()->size();
  int* sendcounts=new int[numPE];
  for (int i=0;i<numPE;++i) sendcounts[i]=0;

  list<mEntity*>::iterator lit=LIST.begin();
  for(; lit!=LIST.end();++lit)
  {
    mEntity* entity=*lit;
    if (!entity->getCommonBdry())
      continue;
    it = o->begin(entity);
    itend = o->end(entity);
    while(it!=itend) 
    {
      void* buf = AP_alloc((*it).second.pid(),9977,sizeof(rp_int));
      rp_int* castbuf = (rp_int *)buf;
      AOMD_SharedInfo si = (*it).second;
      castbuf->entity = si.getRemotePointer();
      AP_send(buf);
      sendcounts[(*it).second.pid()]++;
      ++it;
    } // while
  }  // for
  
  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts);
  int message=0;    
  int count;
  while(!AP_recv_count(&count)||message<count)
  {
    void* msg;
    int from,tag,size,rc;
  // receive phase begins
    rc=AP_recv(MPI_ANY_SOURCE,9977,AP_BLOCKING|AP_DROPOUT,(void**)&msg,&size,&from,&tag);
    if (rc)
    {
      message++;
      rp_int* castbuf = (rp_int*)msg;
      if( !castbuf->entity->getAttachedInt(attachTag))
      {
        castbuf->entity->attachInt(attachTag,1);
        LIST.push_back(castbuf->entity);
      }
      AP_free(msg);
    }  // if(rc)
  }
  AP_check_sends(AP_WAITALL);
  delete [] sendcounts;
#endif
}



// compute the total number of distinct mesh entities
// if we sum all mesh entities on all vectors VEC on all processors.
void computeUniqueID(std::vector<mEntity*> VEC, mMesh* theMesh, 
                       unsigned int aomdtag, int starting_id, int range_id[3])
{ 
#ifdef PARALLEL
  // count how many of mesh entities on VEC are owned by the actual processor
  AOMD_OwnerManager* o = theMesh->theOwnerManager;
  AOMD_OwnerManager::iter it, itend;
  bool am_I_the_owner;
    
  // we can iterate on all counterparts of all mesh entities
  int nbEnt = 0;

  for (unsigned int i=0; i<VEC.size(); ++i)
  {
    am_I_the_owner = true;
    // iterate over on AOMD_SharedInfo
    it = o->begin(VEC[i]);
    itend = o->end(VEC[i]);
	
    while(it != itend) {
    if (((*it).second.pid()) < ParUtil::Instance()->rank())
      am_I_the_owner = false;	 
      ++it;
    }
    // increase nbEnt if all pid in sharedInfo is bigger or equal to the current pe.
    if (am_I_the_owner) nbEnt++;
  }  //for
    
  // each s_vec_exact[i] contains the nb of distinct entities in processor i
  // one round of communication is needed to compute s_vec_exact
    
  P_SyncVector<int> s_vec_exact(nbEnt);
    
  int nbExact = 0;
  for (int i=0; i<ParUtil::Instance()->size(); ++i)
    nbExact += s_vec_exact[i];

  // put the total number in 3rd slot
  range_id[2] = nbExact;

  int nextID = starting_id;
  for (int i=0; i<ParUtil::Instance()->rank(); ++i)
    nextID += s_vec_exact[i];
    
  int* sendcounts = new int[ParUtil::Instance()->size()];
  for (int i=0; i<ParUtil::Instance()->size(); ++i) sendcounts[i]=0;

  range_id[0] = nextID;

  for (unsigned int i=0; i<VEC.size(); i++)
  {
    am_I_the_owner = true;
    it = o->begin(VEC[i]);
    itend = o->end(VEC[i]);
    while (it != itend)
    {
      if ((*it).second.pid() < ParUtil::Instance()->rank())
        am_I_the_owner = false;
	++it;
    }
    if (am_I_the_owner)
    { 
      VEC[i]->attachInt(aomdtag, nextID++);
      it = o->begin(VEC[i]);
      itend = o->end(VEC[i]);
      while (it != itend)
      {
        // send phase begins to find the entity in the counterpart
	// and assign the same id		
	void* buf = AP_alloc((*it).second.pid(), 445, sizeof(rp_int));
	rp_int* castbuf = (rp_int *)buf;
	AOMD_SharedInfo si = (*it).second;
	castbuf->entity = si.getRemotePointer();
	castbuf->i = nextID-1;
	AP_send(buf);
	sendcounts[(*it).second.pid()]++;
	++it;
      } // while
    } // if (am_I_the_owner)
  }  // for

  range_id[1] = nextID-1;
  //    for (int i=0; i<ParUtil::Instance()->size(); ++i) printf ("sendcounts[%d]  =%d\n",i,sendcounts[i]);

  // receive phase begins
  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts);
  int message=0;
  int count;
  while(!AP_recv_count(&count) || message<count)
  {
    void* msg;
    int from, tag, size, rc;
    rc = AP_recv(MPI_ANY_SOURCE, 445, AP_BLOCKING|AP_DROPOUT, &msg, &size, &from, &tag);
    if (rc)
    {
      message++;
      rp_int* castbuf = (rp_int*) msg;
      castbuf->entity->attachInt(aomdtag, castbuf->i);
      AP_free(msg);	
    }  // end of if (rc)
  }  // end of while(!AP...)
    
  AP_check_sends(AP_WAITALL);
  delete[] sendcounts; 

#else
  // do nothing
#endif

} // end of computeUniqueID(..)

/*  
  This function assign the range to each mesh entity.  
  IN: mMesh* theMesh              mesh handle
      vector<mEntity*> entities   contains mesh entities on each processor
      vector<int> numInt          contains entities[i]'s # of integers to assign 
      unsigned int tag            tag
      int starting_range	  starting integer of the range
  OUT:vector<pair<int,int>> range contains the range of entities[i]
                                  the first contains starting integer
                                  the second contains the # of intergers
  for example, assume starting_range is 1.
               if, in P1, entities=[v1,v2,v3], numInt=[1,2,4]
                   in P2, entities=[v4,v1,v3], numInt=[5,2,4]  
              then,in P1, range=[(1,2),(3,2),(5,4)]
                   in P2, range=[(9,5),(1,2),(5,4)]
*/


// this new one is consistent with poor ownership 

/* ALGORITH:
   
   1. unify numInt;
   2. if entity is only copy or CB&&owner
       counter++;
   3. counter=initialRangeValue;
      counter += counter of all less pid (ex) counter[2] = counter[0]+counter[1]+1
   4. for all only and CB&&owner
        attach counter, numInt
	if (CB && owner)
	{
	  send counter to counterpart
	}   
	counter++;
   5. when recv, set counter

*/

/* 
  TWO ASSUMPTION FOR THIS FUNCTION
   1. numInt is 1 for all entities
   2. If the mesh entity is on CB, all copies should be given to this function
 */
void assignUniqueRange(mMesh* theMesh,
                       vector<mEntity*> & entities,
                       vector<int>  & numInt,
                       unsigned int startRangeTag,
                       unsigned int endRangeTag,
                       int initialRangeValue)
{
#ifdef PARALLEL
  assert(entities.size()==numInt.size());

// intialize
  int numPE = ParUtil::Instance()->size();
  int myPE = ParUtil::Instance()->rank();
  
  int numOwnedEntities = 0;
  mEntity* ent;
  vector<mEntity*>::iterator entIter;

  int* sendcounts=new int[numPE];
  AOMD_OwnerManager* o = theMesh->theOwnerManager;
  AOMD_OwnerManager::iter it, itend;
  int message=0;
  int count;

// assert all remote copies of CB entity are given
/*  cout<<"* ("<<P_pid()<<") entities: ";
  for (entIter = entities.begin(); entIter!=entities.end();++entIter)
  {
    cout<<(*entIter)->getUid()<<", ";
  }
  cout<<endl;
*/  

// ******************************
// STEP 1: check CB entities 
// ******************************
  for (int i=0;i<numPE;++i) sendcounts[i]=0;
  for (entIter = entities.begin(); entIter!=entities.end();++entIter)
  {
    ent = (*entIter);
    if (!ent->getCommonBdry()) // non-CB entity
      continue;
    it = o->begin(ent);
    itend = o->end(ent);
    while (it != itend)
    {
      // send phase begins to find the entity in the counterpart
      // and assign the same id		
      void* buf = AP_alloc((*it).second.pid(), 4454, sizeof(rp_int));
      rp_int* castbuf = (rp_int*)buf;
      AOMD_SharedInfo si = (*it).second;
      castbuf->entity = si.getRemotePointer();
      AP_send(buf);
      sendcounts[(*it).second.pid()]++;
      ++it;
    } // while
  }  // for

  // receive phase begins
  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts);
  message=0;

  while(!AP_recv_count(&count) || message<count)
  {
    void* msg;
    int from, tag, size, rc;
    rc = AP_recv(MPI_ANY_SOURCE, 4454, AP_BLOCKING|AP_DROPOUT, &msg, &size, &from, &tag);
    if (rc)
    {
      message++;
      rp_int* castbuf = (rp_int*) msg;
      if (std::find(entities.begin(), entities.end(), castbuf->entity)==entities.end())
      {
        entities.push_back(castbuf->entity);
	cout<<"("<<P_pid()<<") AOMD WARNING: CB entity "
	    <<castbuf->entity->getUid()<<" is not given as input\n";  
      }
      AP_free(msg);	
    }  // end of if (rc)
  }  // end of while(!AP...)
    
  AP_check_sends(AP_WAITALL);

// ******************************
// STEP 2: count the owned entities
// ******************************
  
  for (entIter = entities.begin(); entIter!=entities.end();++entIter)
  {
    ent = (*entIter);
    if (!ent->getCommonBdry()) // non-CB entity
        numOwnedEntities++;
    else if (ent->getCommonBdry() && ent->getCommonBdry()->getOwner()==ParUtil::Instance()->rank())
      numOwnedEntities++;
  }


// ******************************
// STEP 3: compute initial_range value
// ******************************

  int* senddata;
  int* recvdata;

  // send phase begins

  for (int i=0;i<numPE;++i) sendcounts[i]=0;
 
  for (int pid=myPE+1; pid<numPE;++pid)
  {
    senddata = (int*)AP_alloc(pid,5559,sizeof(int));
    *senddata = numOwnedEntities;
    AP_send(senddata);
    sendcounts[pid]++;
  }

  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts);

  message=0;
  
  while(!AP_recv_count(&count)||message<count)
  {
    int from,tag,size,rc;
  // receive phase begins
    rc=AP_recv(MPI_ANY_SOURCE,5559,AP_BLOCKING|AP_DROPOUT,(void**)&recvdata,&size,&from,&tag);
    if (rc)
    {
      message++;
//      cout<<"("<<M_Pid()<<") recieve "<<(*recvdata)<<" from P"<<from<<endl;
      initialRangeValue+=(*recvdata);
      AP_free(recvdata);
    }  // if(rc)
  } // while
  AP_check_sends(AP_WAITALL);

//  cout<<"("<<P_pid()<<") numOwnedEntities="<<numOwnedEntities<<"\n";
//  cout<<"("<<P_pid()<<") initialRangeValue="<<initialRangeValue<<"\n";
  
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);

// ******************************
// STEP 4: attach range to the entities
// ******************************
// it requires one more communication to unify range for the CB entity

  // initialize sendcounts
  for (int i=0; i<numPE; ++i) sendcounts[i]=0;
  
  int counter=0;
  for (entIter = entities.begin(); entIter!=entities.end();++entIter)
  {
    ent = (*entIter);
    
    if (ent->getCommonBdry()->getOwner()!=ParUtil::Instance()->rank())
      continue;
      
    ent->attachInt(startRangeTag, initialRangeValue++);
    ent->attachInt(endRangeTag,numInt[counter]);
//    cout<<"("<<P_pid()<<") attach ("<<initialRangeValue-1<<","
//        <<numInt[counter]<<") to "<<ent->getUid()<<endl; 
    if (!ent->getCommonBdry())  // if non-CB entity
      continue;
    
    // iterate over on AOMD_SharedInfo
    it = o->begin(ent);
    itend = o->end(ent);
    while (it != itend)
    {
      // send phase begins to find the entity in the counterpart
      // and assign the same id		
      void* buf = AP_alloc((*it).second.pid(), 4453, sizeof(rp_int2));
      rp_int2* castbuf = (rp_int2 *)buf;
      AOMD_SharedInfo si = (*it).second;
      castbuf->entity = si.getRemotePointer();
      castbuf->i = initialRangeValue-1;
      castbuf->j = numInt[counter];
      AP_send(buf);
      sendcounts[(*it).second.pid()]++;
      ++it;
    } // while
  }  // for

  // receive phase begins
  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts);

  message=0;
  while(!AP_recv_count(&count) || message<count)
  {
    void* msg;
    int from, tag, size, rc;
    rc = AP_recv(MPI_ANY_SOURCE, 4453, AP_BLOCKING|AP_DROPOUT, &msg, &size, &from, &tag);
    if (rc)
    {
      message++;
      rp_int2* castbuf = (rp_int2*) msg;
      castbuf->entity->attachInt(startRangeTag,castbuf->i);
      castbuf->entity->attachInt(endRangeTag,castbuf->j);
//      cout<<"("<<P_pid()<<") attach ("<<castbuf->i<<","<<castbuf->j<<") to "
//          <<castbuf->entity->getUid()<<endl;
      AP_free(msg);	
    }  // end of if (rc)
  }  // end of while(!AP...)
    
  AP_check_sends(AP_WAITALL);
  delete[] sendcounts; 
#endif
}

} // end of namespace
