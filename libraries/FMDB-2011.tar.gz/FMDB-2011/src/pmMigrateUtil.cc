/**************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*****************************************************************************/

/*<i> ****************************************************************************
 *
 *  AOMD/pmodel/pmMigrateUtil.cc
 *  Created by Seegyoung Seol, on Mon Sep 30 2003, 10:26:37 EDT
 *
 *  File Content: function definition what are used for migration
 *
 *************************************************************************** </i>*/
 
#ifdef PARALLEL

#include <stdio.h>
#include <iostream>
#include <assert.h>
#include <list>
#include <set>
#include <map>
#include <vector>
#include "pmMigrateUtil.h"
#include "pmUtility.h"
#include "pmModel.h"
#include "mEntity.h"
#include "mAOMD.h"
#include "AOMD.h"
#include "ParUtil.h"
#include "autopack.h"
#include "AOMD_cint.h"

using std::cout;
using std::endl;
using std::list;
using std::pair;
using std::vector;
using std::map;
using std::set;

namespace AOMD {

void set_subtract(set<int> A, set<int> B, set<int>& C)
{
  set<int>::iterator aiter, biter;
  for (aiter=A.begin(); aiter!=A.end();++aiter)
  {
    biter = B.find(*aiter);
    if (biter==B.end()) C.insert(*aiter);
  }
} 

/*****************************************
 bounding partition id exchanger
*****************************************/
int bpsExchanger :: tag () const
{
  return 222;
}
void * bpsExchanger :: AP_alloc_and_fill_buffer 
         (mEntity *ent, int pid, mEntity* remoteEnt, int d_tag)
{
  int nbDests = ent->getNumBPs();
 
  char *buf= (char*) AP_alloc(pid, d_tag,
                        (sizeof(mEntity*) + (nbDests+1) * sizeof(int)) );
 
  memcpy(buf,&remoteEnt,sizeof(mEntity*));
  int *dests = (int*)malloc((nbDests+1)*sizeof(int));
  dests[0] = nbDests;
  int count=0;
  for (mEntity::BPIter bpIter=ent->bpBegin();bpIter!=ent->bpEnd();++bpIter)
    dests[++count]=*bpIter;
  memcpy(&buf[sizeof(mEntity*)],dests,(nbDests+1)*sizeof(int));
  free(dests);
  return buf;
}


void bpsExchanger::receiveData (int from, void *buf)
{
  char *mybuf = (char*) buf;
  mEntity *e;
  memcpy(&e,mybuf,sizeof(mEntity*));
  int nbDests;
  memcpy(&nbDests,&mybuf[sizeof(mEntity*)],sizeof(int));
  int *dests = (int*)malloc((nbDests+1)*sizeof(int));
  memcpy(dests,&mybuf[sizeof(mEntity*)],(nbDests+1)*sizeof(int));
  for(int i=1;i<=nbDests;i++)
    e->addBPs(dests[i]);
  free (dests);
}

/*****************************************
 bounding partition id reseter
*****************************************/
int bpsReseter::tag () const
{
  return 111;
}

void * bpsReseter:: AP_alloc_and_fill_buffer 
         (mEntity *ent, int pid, mEntity* remoteEnt, int d_tag)
{
  void* buf = AP_alloc(pid, d_tag, sizeof(mEnt_struct));
  mEnt_struct* castbuf = (mEnt_struct*)buf;
  castbuf->entity = remoteEnt;
  return buf;
}

void bpsReseter:: receiveData (int from, void *buf)
{
  mEnt_struct* castbuf = (mEnt_struct*)buf;
  castbuf->entity->clearBPs();
}

/*****************************************
 unused entity's remote copy remover
*****************************************/
int remoteCopyRemover::tag () const
{
  return 9995;
}

void * remoteCopyRemover:: AP_alloc_and_fill_buffer 
         (mEntity *ent, int pid, mEntity* remoteEnt, int d_tag)
{
  void* buf = AP_alloc(pid, d_tag, sizeof(mEnt_struct));
  mEnt_struct* castbuf = (mEnt_struct*)buf;
  castbuf->entity = remoteEnt;
  return buf;
}

void remoteCopyRemover:: receiveData (int from, void *buf)
{
  mEnt_struct* castbuf = (mEnt_struct*)buf;
  castbuf->entity->deleteRemoteCopy(from);
}

void printFamily(mEntity* ent)
{
  int mypid=ParUtil::Instance()->rank();
  set<mEntity*> family;
  set<mEntity*>::iterator it;
  getFamily(ent, family);
  cout<<"("<<mypid<<") family of "<<ent->getUid()<<": ";
  for (it=family.begin();it!=family.end();++it)
    cout<<(*it)->getUid()<<",";
  cout<<endl;
}  

// *****************************************
void getFamily(mEntity* ent,set<mEntity*>& family)
// *****************************************
{
  int n = ent->getLevel();
  // insert self
  family.insert(set<mEntity*>::value_type(ent));
  mEntity* fc;
  mEntity* eg;
  switch (n)
  {
    case 3:/* METHOD 1 */
#ifndef FLEXDB
           for (int i=0; i<ent->size(2);++i)
           { 
             fc = ent->get(2,i);
             family.insert(fc);
             for (int j=0; j<fc->size(1);++j)
             {
               eg = fc->get(1,j);
               family.insert(set<mEntity*>::value_type(eg));
               family.insert(set<mEntity*>::value_type(eg->get(0,0)));
               family.insert(set<mEntity*>::value_type(eg->get(0,1)));
             }  
           }
#else
           for (int i=0; i<ent->size(2);++i)
           { 
             fc = ent->get(2,i);
             family.insert(fc);
             if (fc->isAdjacencyCreated(2))
	       for (int j=0; j<fc->size(1);++j)
               {
                 eg = fc->get(1,j);
                 family.insert(set<mEntity*>::value_type(eg));
                 family.insert(set<mEntity*>::value_type(eg->get(0,0)));
                 family.insert(set<mEntity*>::value_type(eg->get(0,1)));
               }    
             else
  	       for (int j=0; j<ent->size(1);++j)
               {
                 eg = ent->get(1,j);
                 family.insert(set<mEntity*>::value_type(eg));
                 family.insert(set<mEntity*>::value_type(eg->get(0,0)));
                 family.insert(set<mEntity*>::value_type(eg->get(0,1)));
               }    
           }        
#endif
#ifdef DEBUG
         if (family.size()!=15)
         {
	   cout<<"\n("<<P_pid()<<") family of "<<ent->getUid()<<": "<<family.size()<<"\n";
           for (set<mEntity*>::iterator it=family.begin();it!=family.end();++it)
             (*it)->print();
         }
         assert (family.size()==15);
#endif
           break;
    case 2:// edges
          for (int j=0; j<ent->size(1);++j)
          {
            eg = ent->get(1,j);
            family.insert(set<mEntity*>::value_type(eg));
            family.insert(set<mEntity*>::value_type(eg->get(0,0)));
            family.insert(set<mEntity*>::value_type(eg->get(0,1)));
	  }  
#ifdef DEBUG
          if (family.size()!=7)
          {
	    cout<<"\n("<<P_pid()<<") family of "<<ent->getUid()<<": ";
            for (set<mEntity*>::iterator it=family.begin();it!=family.end();++it)
             (*it)->print();
          }
	  assert(family.size()==7);
#endif
	  break;
    case 1:  
           family.insert(set<mEntity*>::value_type(ent->get(0,0)));
           family.insert(set<mEntity*>::value_type(ent->get(0,1)));
#ifdef DEBUG
           if (family.size()!=3)
           {
	     cout<<"\n("<<P_pid()<<") family of "<<ent->getUid()<<": ";
             for (set<mEntity*>::iterator it=family.begin();it!=family.end();++it)
	       (*it)->print();
           }
           assert (family.size()==3);
#endif
           break;
    default: break;
  }
  return;
}

// *****************************************
void getEntitiesToHandle(map<mEntity*,int>& POToMove,
             set<mEntity*>* entitiesToHandle)
// *****************************************
{
  int mypid=ParUtil::Instance()->rank();
  int pid;
  int numPtn = ParUtil::Instance()->size();
  int* sendcounts=new int[numPtn];
  for (int i=0;i<numPtn;++i) sendcounts[i]=0; 
 
  entityPidMap::iterator mapit;
  mEntity* ent;
  for (mapit=POToMove.begin();mapit!=POToMove.end();++mapit)
  {
    if (mapit->second==mypid)
    {
      POToMove.erase(entityPidMap::key_type(mapit->first));
      continue;
    }
    set<mEntity*> family;
    set<mEntity*>::const_iterator lit;
    getFamily(mapit->first, family);
    for (lit=family.begin();lit!=family.end();++lit)
    {
      ent = *lit;
      ent->clearBPs();
      ent->setPClassification((pmEntity*)0);
      entitiesToHandle[ent->getLevel()].insert(set<mEntity*>::value_type(ent));
      if (ent->getNumRemoteCopies()==0)
        continue;
      for(mEntity::RCIter rciter=ent->rcBegin(); rciter!=ent->rcEnd();++rciter)
      {
          pid = rciter->first;
          void* buf = AP_alloc(pid, 4600, sizeof(mEnt_struct));
          mEnt_struct* castbuf = (mEnt_struct*)buf;
          castbuf->entity = rciter->second;
          AP_send(buf);
          sendcounts[pid]++;
      } // for rciter 
    } // for family
  } // for POtoMove

  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts);
  int message=0;
  int count;
 
  while(!AP_recv_count(&count) || message<count)
  {
    void* msg;
    int from, tag, size, rc;
    rc = AP_recv(MPI_ANY_SOURCE, 4600, AP_BLOCKING|AP_DROPOUT, &msg, &size, &from, &tag);
    if (rc)
    {
      message++;
      mEnt_struct* castbuf = (mEnt_struct*) msg;
      ent = castbuf->entity;
      ent->clearBPs();
      ent->setPClassification((pmEntity*)0);
      entitiesToHandle[ent->getLevel()].insert(set<mEntity*>::value_type(ent)); 
      AP_free(msg);
    }  // end of if (rc)
  }  // end of while(!AP...)
 
  AP_check_sends(AP_WAITALL);
  delete[] sendcounts;
}

// *****************************************
void setBPs(int meshDim, map<mEntity*,int>& POtoMove, 
           set<mEntity*>* entitiesToHandle)
// *****************************************
{
  entityPidMap::const_iterator mapit;
  mEntity* ent;
  int mypid=ParUtil::Instance()->rank();
 
//  for (mapit=POtoMove.begin();mapit!=POtoMove.end();++mapit)
//    printFamily(mapit->first);
  for (mapit=POtoMove.begin();mapit!=POtoMove.end();++mapit)
  {
     assert(mapit->second!=mypid);
     mapit->first->addBPs(mapit->second);
  }
    
  for (mapit=POtoMove.begin();mapit!=POtoMove.end();++mapit)
  {
    int pid = mapit->second;
    set<mEntity*> family;
    set<mEntity*>::const_iterator lit;
    getFamily(mapit->first, family);
 
    for (lit=family.begin();lit!=family.end();++lit)
    {
      if ((*lit)->getLevel()==meshDim) // exit if self
        continue;
 
      ent = *lit;
      ent->addBPs(pid);
  
      AOMD::mAdjacencyContainer upward;
      ent->getHigherOrderUpward(meshDim,upward);
      for (int i=0; i<upward.size();++i)
      {
        if (upward[i]->getNumBPs()==0)
        {
          ent->addBPs(mypid); //
          break;  // exit for loop
        }
      }
    }
  }
  
  for (int dim=0;dim<meshDim;++dim)
  {
    set<mEntity*>::iterator eit=entitiesToHandle[dim].begin();
    for (;eit!=entitiesToHandle[dim].end();++eit)
    {
      ent = *eit;
      AOMD::mAdjacencyContainer upward;
      ent->getHigherOrderUpward(meshDim,upward);
      for (int i=0; i<upward.size();++i)
      {
        if (upward[i]->getNumBPs()==0)
        {
          ent->addBPs(mypid); //
          break;  // exit for loop
        }
      } // upward
    } // for entitiesToHandle
  }  // for dim
}


// *****************************************
void exchangeBPs(set<mEntity*>* entitiesToHandle)
// *****************************************
{    
  set<mEntity*>::const_iterator eit;
  mEntity* ent;
    int numPtn = ParUtil::Instance()->size();
  int* sendcounts=new int[numPtn];
  for (int i=0;i<numPtn;++i) sendcounts[i]=0;
  int pid, buf_size,numBP;
  for (int dim=0; dim<=3;++dim)
  {
    for (eit=entitiesToHandle[dim].begin();eit!=entitiesToHandle[dim].end();++eit)
    {
      ent = *eit;
      numBP = ent->getNumBPs();
      if (ent->getNumRemoteCopies()==0)
        continue;
      for (mEntity::RCIter rciter=ent->rcBegin();rciter!=ent->rcEnd();++rciter)
      {
        pid = rciter->first;
        buf_size=sizeof(int_mEnt_struct) + numBP*sizeof(int);
        char* buf = (char*)AP_alloc(pid, 459, buf_size);
        int_mEnt_struct castbuf;  
        castbuf.i = numBP;
        castbuf.entity = rciter->second;
        memcpy(buf,&castbuf,sizeof(int_mEnt_struct));
        int* BPs = (int*)malloc(numBP*sizeof(int));
        int i=0;
        for (mEntity::BPIter bpiter=ent->bpBegin();bpiter!=ent->bpEnd();++bpiter)
          BPs[i++]=*bpiter;
        memcpy(&buf[sizeof(int_mEnt_struct)],BPs,numBP*sizeof(int));
        delete[] BPs;
        AP_send((void*)buf);
        sendcounts[pid]++;
      }  
    }
  }
    // recieve phase
  AP_check_sends(AP_NOFLAGS); 
  AP_reduce_nsends(sendcounts); 
  int message=0; 
  int count;
   
  while(!AP_recv_count(&count) || message<count)
  {
    void* msg;  
    
    int from, tag, size, rc; 
    rc = AP_recv(MPI_ANY_SOURCE, 459, AP_BLOCKING|AP_DROPOUT, &msg, &size, &from, &tag);
    if (rc) 
    {        
      message++;
      char* buf = (char*) msg;
      int_mEnt_struct castbuf;
      memcpy(&castbuf,buf,sizeof(int_mEnt_struct));
      ent = castbuf.entity;
      int* BPs = new int[castbuf.i];
      memcpy(BPs,&buf[sizeof(int_mEnt_struct)],sizeof(int)*castbuf.i);
      for (int i=0; i<castbuf.i;++i)
        ent->addBPs(BPs[i]);
      delete[] BPs;
      AP_free(msg);       
    }  // end of if (rc)
  }  // end of while(!AP...)
       
  AP_check_sends(AP_WAITALL);
  delete[] sendcounts;    
}

// ***********************************************************
void updatePC_and_collectEntitiesToRemove(
			set<mEntity*>* entitiesToHandle, 
			set<mEntity*>* entitiesToRemove)
// ***********************************************************
{
  mEntity* ent;
  set<mEntity*>::const_iterator eit;
  
  for (int dim=0; dim<=3; ++dim)
  {
    for (eit=entitiesToHandle[dim].begin();
      eit!=entitiesToHandle[dim].end();++eit)
    {
      ent = *eit;
      if (!ent->findPidInBPs(ParUtil::Instance()->rank()))
        entitiesToRemove[dim].insert(set<mEntity*>::value_type(ent));
      else if (!ent->getPClassification()) 
        ent->setPClassificationWithBPs();
    }    
  }
}

// ***********************************************************
void removeUnusedEntities(mMesh* mesh, int dim, 
			 set<mEntity*>* entitiesToRemove)
// ***********************************************************
{
  set<mEntity*>::iterator eiter;
  std::vector<mEntity*> entitiesOnCB;

  for (int i=dim;i>=0;--i)  // region to vertex
    for (eiter=entitiesToRemove[i].begin(); eiter!=entitiesToRemove[i].end();++eiter)
      if ((*eiter)->getNumRemoteCopies())
        entitiesOnCB.push_back(*eiter);
  
  remoteCopyRemover deCallback;
  genericDataExchanger(entitiesOnCB.begin(), entitiesOnCB.end(), deCallback);

  if (dim==3)
    for (eiter=entitiesToRemove[3].begin(); eiter!=entitiesToRemove[3].end();++eiter)
      M_removeRegion(mesh,*eiter);
      
  for (eiter=entitiesToRemove[2].begin(); eiter!=entitiesToRemove[2].end();++eiter)
    M_removeFace(mesh,*eiter);

  for (eiter=entitiesToRemove[1].begin(); eiter!=entitiesToRemove[1].end();++eiter)
    M_removeEdge(mesh,*eiter);
  
  for (eiter=entitiesToRemove[0].begin(); eiter!=entitiesToRemove[0].end();++eiter)
    M_removeVertex(mesh,*eiter);
  
}

} // end of namespace
#endif /* PARALLEL */
