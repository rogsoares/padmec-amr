/******************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*********************************************************************************/

#include <stdio.h>
#include <iostream>
#include <fstream>

#include "mAOMD.h"
#include "mMesh.h"
#include "mEdge.h"
#include "mEntity.h"
#include "AOMD_OwnerManager.h"
#include "AOMD_METIS_Partitioner.h"

#include "ParUtil.h"
#ifdef PARALLEL
#include "autopack.h"
#include "AOMD_ZoltanLoadBalancer.h"
#endif
#include "AOMD.h"
#include "AOMDInternals.h"
#include "AOMD_Internals.h"

using namespace std;

namespace AOMD {

  void AOMD_Util::partition_and_export   (const char *baseName, 
					  mMesh *theMesh,
					  AOMD_LoadBalancerCallbacks &lb)
  {
    int d = theMesh->getDim();
    theMesh->modifyState (d,d-1,1,0);
    theMesh->modifyState (d-1,d,1,0);
    if (d == 3)
      theMesh->modifyState (d,1,1,0);
    theMesh->loadBalance (lb,d,d-1);
    char name[256];
    for (int i=0;i<lb.nbProcs();i++)
      {
	sprintf(name,"%s-proc%d.msh",baseName,i);
	AOMD::AOMD_Util::Instance()->setCurrentProcessor(i);
	AOMD::AOMD_Util::Instance()->ex_port(name,theMesh,true);
      } 
    unsigned int tagMark = AOMD_Util::Instance()->lookupMeshDataId("_dest");
    {    for(int i=0;i<4;i++)
      for(mMesh::iterall it = theMesh->beginall(i) ; it!= theMesh->endall(i) ; ++it)
	(*it)->deleteData(tagMark); 
    }
    AOMD::AOMD_Util::Instance()->setCurrentProcessor(-1);
  }
#ifdef PARALLEL
  void AOMD_Util::import_and_loadbalance(const char *probName, 
					 mMesh *theMesh,
					 AOMD_LoadBalancerCallbacks &lb)
  {
    // only do that on the master processor
    int dim=0,maxdim;
    if(ParUtil::Instance()->master())
      {
	import (probName, theMesh);
	dim = (theMesh->size(3))?3:2;
	theMesh->modifyState(dim,dim-1,true);
	theMesh->modifyState(dim-1,dim,true);
	if (dim == 3)
	  theMesh->modifyState(dim,1,true);
      }
  
    ParUtil::Instance()->Barrier(__LINE__,__FILE__);  
    MPI_Allreduce(&dim,&maxdim,1,MPI_INT,MPI_MAX,
		  MPI_COMM_WORLD);
    dim = maxdim;
    theMesh->loadBalance_updateAdj(lb,dim,dim-1);
    theMesh->modifyState(dim,dim-1,false);
    theMesh->modifyState(dim-1,dim,false);
  }

  void AOMD_Util::import_and_loadbalance_oneLevel(const char *probName, 
					 mMesh *theMesh,
					 AOMD_LoadBalancerCallbacks &lb)
  {
    // only do that on the master processor
    int dim=0,maxdim;
    if(ParUtil::Instance()->master())
    {
	import_oneLevel(probName, theMesh);
	dim = (theMesh->size(3))?3:2;
     }
    if (ParUtil::Instance()->size()==1)
      return; 
    ParUtil::Instance()->Barrier(__LINE__,__FILE__);  
    MPI_Allreduce(&dim,&maxdim,1,MPI_INT,MPI_MAX,
		  MPI_COMM_WORLD);
    dim = maxdim;
    theMesh->loadBalance_oneLevel(lb,dim,dim-1);
    //M_checkOneLevelValidity(theMesh);
  }

#endif
} // end of namespace
