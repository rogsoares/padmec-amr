/**************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*****************************************************************************/

/*<i> ****************************************************************************
 *
 *  AOMD/pmodel/pmModel.cc
 *  Created by Seegyoung Seol, on Mon Dec 08 2003, 10:26:37 EDT
 *
 *  File Content: partition model class definition
 *
 *************************************************************************** </i>*/
#ifdef PARALLEL

#include "pmModel.h"
#include "ParUtil.h"
#include "pmModelUtil.h"
#include "pmEntity.h"

#include <assert.h>
#include <iostream>
#include <set>
#include <vector>
#include <algorithm>
#include <iterator>

using std::vector;
using std::set;
using std::cout;
using std::endl;

namespace AOMD {
  
pmModel* pmModel::instance = 0;

pmModel::pmModel() 
{
  isUptodate=false;
}
  
pmModel::~pmModel()
{ 
  PEIter peit=peBegin();
  for(; peit!=peEnd(); ++peit)
  {
    delete (*peit);
  }
  allPEntities.clear();
  for (int i=0; i<4;++i)
    allCBEntities[i].clear();
  delete mesh;
}
  
pmModel* pmModel::Instance()
{
  if(!instance)
    instance = new pmModel;
  return instance;
}

pmEntity* pmModel::getPartitionEntity(set<int>& bps)
{
  if (bps.size()<=1)
     return (pmEntity*)0;
     
  PEIter it=peBegin();
  for (; it!=peEnd(); ++it)
  {
    if ((*it)->isEqual(bps))
      return (*it);
  }
  pmEntity* newPE = new pmEntity(getNumPEs()+1, bps, 0);
  allPEntities.insert(newPE);
  return newPE;
}

pmEntity* pmModel::getPartitionEntity(int id)
{
  PEIter it=peBegin();
  for (; it!=peEnd(); ++it)
  {
    if ((*it)->getId()==id)
      return (*it);
  }
  return (pmEntity*)0;
}

// this function should be called whenever mesh partitioning changes
void pmModel::updateOwnership()
{
  vector<int> allSortedPids;
  vector<int>::iterator pidIter;
  getSortedPids_poor_to_rich(mesh,allSortedPids);
  
/*  if (ParUtil::Instance()->master())
  {  cout<<"\t* POOR TO RICH PIDS: ";
    for (pidIter=allSortedPids.begin(); pidIter!=allSortedPids.end();++pidIter)
       cout<<"P"<<*pidIter<<" -> ";
    cout<<"\n";
  }
*/

  PEIter peit=peBegin();
  for(; peit!=peEnd(); ++peit)
  {
    (*peit)->setOwner(allSortedPids);
  }

  isUptodate = false; 
}

void pmModel::update()
{
  if (isUptodate || ParUtil::Instance()->size()==1) return;

  ParUtil::Instance()->Msg(ParUtil::INFO,"\n***  update PARTITION MODEL ***\n");	  

// STEP 1: clear containers
  for (int d=0; d<4;++d)
    allCBEntities[d].clear();
  BPs.clear();

// STEP 2: update allCBEntities
  int numPtn = ParUtil::Instance()->size();
  bool* isBound = new bool[numPtn];
  for (int i=0; i<numPtn;++i) isBound[i]=false;
  mEntity* ent;
  
  mMesh::iterall it;
  for (int d = 0; d<mesh->getDim();++d)
  {
    for (it=mesh->beginall(d); it!=mesh->endall(d);++it)
    {
      ent = *it;
      if (ent->getPClassification())  // CB entity
      { 
        allCBEntities[d].push_back(*it);
        if (d==0) // mesh vertex
          for (mEntity::RCIter rciter=ent->rcBegin(); rciter!=ent->rcEnd();++rciter)
	    isBound[rciter->first]=true;
      }
    }
  }

// STEP 3: update BPs
  for (int i=0; i<numPtn;++i)
    if (isBound[i]) BPs.push_back(i);
    
  delete [] isBound;  

// STEP 4: set isUptodate true
  isUptodate=true;  
}

pmModel::BPIter pmModel::bpBegin()
{ 
//  if (!isUptodate)
//    update();
  assert(isUptodate);
  return BPs.begin(); 
}

pmModel::BPIter pmModel::bpEnd()
{ 
  assert(isUptodate);
//if (!isUptodate)
//    update();
  return BPs.end(); 
}

pmModel::CBIter pmModel::cbBegin(int dim)
{  
  assert(dim>=0 && dim<=mesh->getDim());
  assert(isUptodate);
  return allCBEntities[dim].begin();  
}

pmModel::CBIter pmModel::cbEnd(int dim)
{ 
  assert(dim>=0 && dim<=mesh->getDim());
  assert(isUptodate);
  return allCBEntities[dim].end();  
}

void pmModel::getCBEntities(int dim, vector<mEntity*>& cbEntities)
{
  if (ParUtil::Instance()->size()==1) return;
  assert(dim>=-1 && dim<=mesh->getDim());

  if (!isUptodate) 
  { 
    update();
  }
  if (dim==-1)
  {  
    for (int d=0; d<mesh->getDim();++d)
      std::copy(cbBegin(d), cbEnd(d), std::back_inserter(cbEntities));
  }
  else
    std::copy(cbBegin(dim), cbEnd(dim), std::back_inserter(cbEntities));
}

void pmModel::getRPClassification(pmEntity* pe, vector<mEntity*>& entities)
{ 
  if (!isUptodate)   
    update();
  ParUtil::Instance()->Msg(ParUtil::WARNING,"Reverse PClassification is not implemented yet\n");
}

void pmModel::print()
{
  PEIter it=peBegin();
  for (; it!=peEnd(); ++it)
    (*it)->print();
}

} // end of namespace

#endif /* PARALLEL */
