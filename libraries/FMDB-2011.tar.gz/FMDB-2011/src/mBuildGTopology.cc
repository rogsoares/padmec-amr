/**************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*****************************************************************************/
#include <iostream>
#include <stdio.h>
#include <fstream>
#include "mAOMD.h"
#include "mMesh.h"
#include "mEntity.h"
#include "mBuildAdj.h"

namespace AOMD {

  void buildForDimK ( mMesh *m, int k)
  {
    std::for_each(m->beginall(k),
		  m->endall(k),
		  createDownwardFunctor (k-1,0,m,false));
  }
  
  void AOMD_Util::BuildGTopology ( mMesh *m )
  {
    int dim = m->getDim();
    {for(int i=2;i<=dim;i++) buildForDimK (m,i);}
    {for(int i=0;i< dim;i++) m->modifyState(i,i+1,true);}
    //printf("AOMD_Util::BuildTopology Warning: no more model entity adjacency from AOMD\n");
    //    {for(int i=1;i<=dim;i++) connectForDimK (m,i);}
    {for(int i=0;i< dim;i++) m->modifyState(i,i+1,false);}
    {for(int i=2;i<=dim;i++) m->modifyState(i,i-1,false);}
    m->reduceToMinumumRepresentation();
      
  }

}  // end of namespace

