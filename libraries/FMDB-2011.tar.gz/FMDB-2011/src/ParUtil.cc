/******************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*********************************************************************************/
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
//#ifdef SUN4
//#include <sys/varargs.h>
//#else
#include <stdarg.h>
//#endif
#include "ParUtil.h"
#ifdef PARALLEL
#include "autopack.h"
#else
#ifndef MSC
#include <sys/time.h>
#endif
#endif

namespace AOMD {

ParUtil* ParUtil::Instance()
{
  if(!instance)
    {
      instance = new ParUtil;
    }
  return instance;
}

ParUtil::~ParUtil() 
{
  Msg(INFO,"Finalizing...\n");
  Finalize();
}

ParUtil::ParUtil() 
{
}

void ParUtil::init(int &argc, char **&argv) {

#ifdef PARALLEL
  int namelen;
  char name[1024];
  MPI_Init(&argc, &argv);

  MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
  MPI_Comm_size(MPI_COMM_WORLD, &mysize);
  
  MPI_Comm_dup(MPI_COMM_WORLD, &seq_local_comm);
  MPI_Errhandler_set(MPI_COMM_WORLD,MPI_ERRORS_RETURN);
  AP_init(&argc, &argv);
  AP_setparam(100000, 1, 10, 100);
  //  MPI_Get_processor_name(name,&namelen);
  //  procName = name;
  vl = 1;
  resetBarrierSensor();
#endif
}

double ParUtil::wTime() const
{

#ifdef PARALLEL
  return MPI_Wtime(); 
#else
#ifndef MSC
  struct timeval tp;
  struct timezone tzp;
  double timeval;
  
  gettimeofday(&tp,&tzp);
  
  timeval = (double) tp.tv_sec;
  timeval = timeval + (double) ((double) .000001 * (double) tp.tv_usec);
  
  return(timeval);
#else
  return 0;
#endif
#endif
}

std::string ParUtil::processorName() const
{
#ifdef PARALLEL
  return procName;
#else
  return std::string("localhost");
#endif
}

void ParUtil:: Msg(ParUtil::MessageLevel level, char *fmt, ...)
{ 
  char buff[1024];
  va_list  args;
  va_start (args, fmt);
  vsprintf(buff, fmt, args);
  va_end (args);

  switch(level)
    {
    case DEBUG1:
      if(vl > 1)
	{
	  /* char logname[256];
	  sprintf(logname,"log-proc%d-%s.dat",myrank,procName);
	  log = fopen (logname,"a");	  
	  fprintf(log,"%s",buff);
	  fclose(log);*/
	}
      break;
    case DEBUG2:
      if(vl > 2)
	{
	  /*	  char logname[256];
	  sprintf(logname,"log-proc%d-%s.dat",myrank,procName);
	  log = fopen (logname,"a");	  
	  fprintf(log,"%s",buff);
	  fclose(log);*/
	}
      break;
    case INFO:
      if(vl >= 0 && master())
	{
	  //	  fprintf(log,"%s",buff);
	  fprintf(stdout,"%s",buff);
	  //	  fflush(log);
	}
      if(vl > 2)
	{
	  //	  fprintf(log,"%s",buff);
	  //	  fflush(log);
	}
      break;
    case WARNING:
      fprintf(stdout,"Processor %d AOMD WARNING : %s",rank(),buff);
      fflush(stdout);
      break;
    case ERROR:
      fprintf(stdout,"AOMD FATAL ERROR : %s",buff);
      fflush(stdout);
      Abort();
      break;
    }
}

void ParUtil::Abort()
{
#ifdef PARALLEL
  MPI_Abort(MPI_COMM_WORLD, 1);
#else
  abort();
#endif
}

void ParUtil::Barrier(int line, const char *fn)
{
#ifdef PARALLEL
    double t1 = wTime();
  //  Msg(DEBUG2,"BARRIER : Line %d in %s\n",line,fn);
    MPI_Barrier(MPI_COMM_WORLD);
  //  Msg(DEBUG2,"BARRIER PASSED : Line %d in %s\n",line,fn);
    timeSpentOnBarriers += (wTime()-t1);
#endif
}

void ParUtil::Finalize()
{
#ifdef PARALLEL
  MPI_Finalize();
#endif
}

ParUtil* ParUtil::instance = 0;
int ParUtil:: buffer_size = 1024;

} // end of namespace
