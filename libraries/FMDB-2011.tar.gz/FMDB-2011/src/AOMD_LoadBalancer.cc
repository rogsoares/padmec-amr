/******************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*********************************************************************************/
#include <stdio.h>
#include <iostream>
#include <assert.h>
#include "AOMD_LoadBalancer.h"
#include "mMigrateUtil.h"
#include "mMesh.h"
#include "mEntity.h"
#include "mVertex.h"
#include "mEdge.h"
#include "mRegion.h"
#include "ParUtil.h"
#include "pmGraphs.h"
#include "mAOMD.h"
#include "AOMD_OwnerManager.h"
#include "AOMD_Internals.h"
#ifdef PARALLEL
#include "autopack.h"
#include "mExchangeData.h"
#endif

using std::vector;
using std::set;
using std::cout;
using std::pair;
using std::endl;
using std::list;
	       
namespace AOMD {

const int VERTEX_TRACK_ID = 6469;

int mMesh::loadBalance (AOMD_LoadBalancerCallbacks &cb, int from, int to)
{
  int totalMoved = 0;
  ParUtil::Instance()->Barrier(__LINE__,__FILE__); 
  int n = from;
  AOMD_distributed_graph g(this,from,to,&cb);
  int *partitionVector = new int[g.theGraph->nn];
  cb.partition(g,partitionVector);

  int initial_id = g.vtxdist[ParUtil::Instance()->rank()];
  list<mEntity *> toDelete;
  CreateMigrationVectors (this,partitionVector,initial_id,from,0,toDelete,cb.nbProcs());
  ParallelReclassifyMeshEntities(n);  
#ifdef PARALLEL /// migration phase uniquely in parallel
  int *sendcounts = new int[ParUtil::Instance()->size()];

  for(int dim = 0; dim <= n; dim++)
  {
    ParUtil::Instance()->Barrier(__LINE__,__FILE__);
    for(int i=0;i<ParUtil::Instance()->size();i++)
      sendcounts[i]=0;
    for(mMesh::iter it = begin(dim) ; it!= end(dim) ; ++it)
    {
      mEntity *e = *it;
	  	  
      for(int dest=0;dest<getNbDests(e);dest++)
      {	      
        int part = getDest(e,dest);
	      
	if(part != ParUtil::Instance()->rank())
	{
          void *buf = packMeshEntity(e,part,cb);
	  AP_send(buf);
	  sendcounts[part] ++;
        }
      }
    }
    
    AP_check_sends(AP_NOFLAGS);
    AP_reduce_nsends(sendcounts);
    int message=0;
    int count;

    while (!AP_recv_count(&count) || message<count) 
    {  
      void *msg;
      int from, tag, size, rc;
      rc=AP_recv(MPI_ANY_SOURCE, MPI_ANY_TAG, AP_BLOCKING|AP_DROPOUT,
  	         &msg, &size, &from, &tag);
      if (rc && (tag == TAGVERTEX || tag == TAGNONVERTEX)) 
      {
        message++;
        unpackMeshEntity(msg,from,tag,cb);
        AP_free(msg);
      }
    }
    AP_check_sends(AP_WAITALL); 
    ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  }

  int localMoved = toDelete.size();
  MPI_Allreduce(&localMoved,&totalMoved,1,MPI_INT,MPI_SUM,
		MPI_COMM_WORLD);
  
  for(list<mEntity *>::const_iterator it = toDelete.begin();
      it != toDelete.end();++it)
  {
    DEL(*it);
  }
  
  modifyState(from,to,true);

  if(from == 3)
  {
    modifyState(2,1,true);
    modifyState(3,1,true);
  }

  cleanup(from);

  modifyState(to,from,false);
  modifyState(to,from,true);

  bdryLinkSetup();
 
  delete [] sendcounts;
  delete [] partitionVector;

  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  unsigned int tagMark = AOMD_Util::Instance()->lookupMeshDataId("_dest");
  for(int i=0;i<4;i++)
    for(mMesh::iterall it = beginall(i) ; it!= endall(i) ; ++it)
      (*it)->deleteData(tagMark); 
#endif
  return totalMoved;
}

} // end of namespace

