/**************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*****************************************************************************/

/*<i> ****************************************************************************
 *
 *  AOMD/pmodel/pmZoltanCallbacks.cc
 *  Created by Seegyoung Seol, on Thur Dec 09 2003, 10:26:37 EDT
 *
 *  File Content: Zoltan callback class definition
 *
 *************************************************************************** </i>*/
 
#ifdef PARALLEL
#include <iostream>
#include <stdio.h>
#include <vector>
#include <algorithm>
#include "pmZoltanCallbacks.h"
#include "mEntity.h"

using std::vector;
using std::find;

namespace AOMD {

pmZoltanCallbacks::pmZoltanCallbacks(Algorithm algo)
  : theAlgorithm(algo)
{
}

void pmZoltanCallbacks::setAlgorithm(const Algorithm &algo)
{
  theAlgorithm = algo;
}

} // end of namespace

#ifdef _HAVE_PARMETIS_
#include "ParUtil.h"
#include "pmGraphs.h"
extern "C"
{
#include "parmetis.h"
void METIS_PartGraphRecursive(int *, idxtype *, idxtype *, idxtype *, idxtype *, int *, int *, int *, int *, int *, idxtype *); 
}


namespace AOMD {

// return TRUE if the attached user data to entity should be removed 
// on this processor after migration, otherwise, return FALSE
bool deleteUserData(mEntity* ent,int pid)
{
//  if (!ent->findPidInBPs(ParUtil::Instance()->rank()))
//    return true;

  mEntity::BPIter bpiter=ent->bpBegin();
  bool startFlag=false;
  for (;bpiter!=ent->bpEnd();++bpiter)
  {
    if (*bpiter==pid)
    {
      startFlag=true;
      continue;
    }
    if (startFlag)
    {
      vector<int> pidsExist;
      ent->getPidsExist(pidsExist);
      if (find(pidsExist.begin(), pidsExist.end(), *bpiter)==pidsExist.end()) // find another pid to send this entity
        return false;
    }
  }
  if (!ent->findPidInBPs(ParUtil::Instance()->rank()))
    return true;
  return false;
}

void pmZoltanCallbacks::partition(AOMD_distributed_graph2 &dg,
				       int *partitionVector)
{
  int edgecut,options[4];
  /* --- call ParMetis partioning routine ---*/
  int wgtflag;
  if(dg.theGraph->vwgt && dg.theGraph->adjwgt)wgtflag = 3;
  else if (dg.theGraph->vwgt)wgtflag = 2;
  else if (dg.theGraph->adjwgt)wgtflag = 1;
  else wgtflag = 0;

  int numflag    = 1;            /*-> FORTRAN style numbering */
  options[0] = 0;                /*-> default algorithm options */

//  if(ParUtil::Instance()->master())
//    dg.theGraph->print(std::cout);

  MPI_Comm comm = MPI_COMM_WORLD;

//  printf("parmetis partitioning on P%d...\n",ParUtil::Instance()->rank());

  switch (theAlgorithm)
    {
    case Random:
      {
	for(int i=0;i<dg.theGraph->nn;i++)
	  partitionVector[i] = rand() % ParUtil::Instance()->size() + 1;
      }
      break;
    case Remap:
  //    if (ParUtil::Instance()->master())
//        printf("(%d) call ParMETIS_RepartRemap\n",ParUtil::Instance()->rank());
      ParMETIS_RepartRemap(dg.vtxdist,
			   dg.theGraph->xadj,
			   dg.theGraph->adjncy,
			   dg.theGraph->vwgt,
			   dg.theGraph->adjwgt,
			   &wgtflag,
			   &numflag,
			   options,
			   &edgecut,
			   partitionVector,
			   &comm
			   );
      break;
    case MLRemap:
//      if (ParUtil::Instance()->master()) 
//        printf("(%d) call ParMETIS_RepartMLRemap\n",ParUtil::Instance()->rank());
      ParMETIS_RepartMLRemap(dg.vtxdist,
			     dg.theGraph->xadj,
			     dg.theGraph->adjncy,
			     dg.theGraph->vwgt,
			     dg.theGraph->adjwgt,
			     &wgtflag,
			     &numflag,
			     options,
			     &edgecut,
			     partitionVector,
			     &comm
			     );
      break;
    case LDiffusion:
    //  if (ParUtil::Instance()->master()) 
//        printf("(%d) call ParMETIS_RepartLDiffusion\n",ParUtil::Instance()->rank());
      ParMETIS_RepartLDiffusion(dg.vtxdist,
				dg.theGraph->xadj,
				dg.theGraph->adjncy,
				dg.theGraph->vwgt,
				dg.theGraph->adjwgt,
				&wgtflag,
				&numflag,
				options,
				&edgecut,
				partitionVector,
				&comm
				);
      break;
    case GDiffusion:
    //  if (ParUtil::Instance()->master()) 
//        printf("(%d) call ParMETIS_RepartGDiffusion\n",ParUtil::Instance()->rank());
      ParMETIS_RepartGDiffusion(dg.vtxdist,
				dg.theGraph->xadj,
				dg.theGraph->adjncy,
				dg.theGraph->vwgt,
				dg.theGraph->adjwgt,
				&wgtflag,
				&numflag,
				options,
				&edgecut,
				partitionVector,
				&comm
				);
      break;
    case Serial:
      {
//	if (ParUtil::Instance()->master()) 
//          printf("(%d) call METIS_PartGraphRecursive\n",ParUtil::Instance()->rank());
	AOMD_graph &g = *(dg.theGraph);
	int nbParts = ParUtil::Instance()->size();
	METIS_PartGraphRecursive(&g.nn,g.xadj,g.adjncy,g.vwgt,g.adjwgt,&wgtflag,
				 &numflag,&nbParts,options,&edgecut,
				 partitionVector); 
      }
      break;
    }
//  if (ParUtil::Instance()->master())
//    printf("(%d) back from parmetis to c++\n", ParUtil::Instance()->rank());
  // back to C++
  for(int i=0;i<dg.theGraph->nn;i++)
    {
      partitionVector[i]--;
    }
}

} // end of namespace

#else
#include "mException.h"

namespace AOMD {

void pmZoltanCallbacks::partition(AOMD_distributed_graph2 &theGraph, int *partitionVector)
{
  throw new mException(__LINE__,__FILE__,"AOMD must be linked with ParMETIS for using ParMETIS Load Balancing");
}

} // end of namespace
#endif
#endif

