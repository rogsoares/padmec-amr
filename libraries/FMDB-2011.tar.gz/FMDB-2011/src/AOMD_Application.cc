/**************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*****************************************************************************/

/*<i> ****************************************************************************
 *
 *  AOMD/cint/PM_adapt.cc
 *  Created by Seegyoung Seol, on Thur Dec 04 2003, 10:26:37 EDT
 *
 *  File Content: meshAdapt-specific C interface definition
 *
 *************************************************************************** </i>*/
 
#ifndef SIM
#ifdef PARALLEL
#include "AOMD_cint.h"
#include "pmMeshAdapt.h"
#include "pmTrellis.h"

#include <iostream>
#include <list>
#include <vector>

using namespace AOMD;
using std::cout;
using std::endl;
using std::vector;


void M_unifyTaggedEntities(pMeshDataId tag, std::list<pEntity>& edges)
{
  if (P_size()==1) return;
    
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
#ifdef DEBUG
//  ParUtil::Instance()->Msg(ParUtil::INFO,"*** M_unifyTaggedEntities\n");
#endif
  unifyTaggedEntities(tag,edges);
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
}


void M_attachUniqueId(pMesh mesh, pMeshDataId tag)
{
  if (P_size()==1) return;
    
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
#ifdef DEBUG
//  ParUtil::Instance()->Msg(ParUtil::INFO,"*** M_attachUniqueId\n");
#endif
  attachUniqueId(mesh,tag);
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
}

void M_assignUniqueRange (pMesh pm, 
	  		       pMeshDataId tag1,
			       pMeshDataId tag2, 
			       std::vector<pEntity> &l1,
			       std::vector<int> &l2, 
			       int initialId)
{
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
#ifdef DEBUG
//  ParUtil::Instance()->Msg(ParUtil::INFO,"*** M_assignUniqueRange\n");
#endif
  // declared in include/pmTrellis.h
  assignUniqueRange(pm,tag1,tag2,initialId, l1,l2);
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  return;
}

int M_deleteDimReduction(pMesh pm,std::vector<mEntity*>* rmE)
{
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
#ifdef DEBUG
//  ParUtil::Instance()->Msg(ParUtil::INFO,"*** M_deleteDimReduction\n");
#endif
  // declared in include/pmMeshAdapt.h
  int ret=deleteDimReduction(pm,rmE);  
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  return ret;
}

#endif  /* PARALLEL */
#endif   /* ifndef SIM */
