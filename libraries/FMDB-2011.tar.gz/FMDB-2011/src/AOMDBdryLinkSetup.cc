/******************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*********************************************************************************/
#include <fstream>
#include <iostream>
#include <stdio.h>
#include "mMesh.h"
#include "mEdge.h"
#include "mVertex.h"
#include "mFace.h"
#include "mEntity.h"
#include "AOMD_OwnerManager.h"
#include "ParUtil.h"

#ifdef PARALLEL
#include "autopack.h"
#endif

namespace AOMD {

#ifdef PARALLEL

  using namespace std;
  struct mentity_intrep
  {
    /// the mesh entity address on THIS side
    mEntity* ent;
    /// processor id on THIS side
    int pbid;
    /// vertices id's
    int vert[4];    
  };

  /*
    I should review this part because of
    this reclassification stuff that should
    not be called. The idea would be to 
    take all entities equally classified ,
    take their sub-entities and send the whole
    to the remote processes.
  */

  void mMesh::bdryLinkSetup()
  {
    theOwnerManager->clearRemoteCopies();
    
    int *sendcounts = new int[ParUtil::Instance()->size()];
    for(int i=0;i<ParUtil::Instance()->size();i++)sendcounts[i]=0;
    int n = size(2)?2:1;
    
    // Michel D. bug (8/8/2002)
    for (int l=1;l<=n;l++)
      updateCommonBdryEntities(l);
    
    /// changed 1 -> 0 in this loop
    for(int dim=0;dim<=n;dim++)
      {
	int i=0;
	for(iter it = begin(dim); it != end(dim);++it)
	  {
	    mEntity *e = *it;
	    /// we ensures that the entity is classified on
	    /// a parallel boundary.
	    mCommonBdry* g = e->getCommonBdry();
	    if(g)
	      {
		for(AOMD_OwnerManager::iter_top it_t = 
		      theOwnerManager->begin_top(g->getId());
		    it_t !=theOwnerManager->end_top(g->getId()); 
		    ++ it_t)
		  {
		    int sharedPID = (*it_t).second;
		    if (ParUtil::Instance()->rank() != sharedPID) 
		      {
			void *buf=AP_alloc(sharedPID, 444,
					   sizeof(mentity_intrep));	  
			mentity_intrep *castbuf= (mentity_intrep *)buf;
			if(dim==0 && e->getType() == mEntity::VERTEX)
			  {
			    castbuf->vert[0] = e->getId();
			    castbuf->vert[1] = -1;
			    castbuf->vert[2] = e->getId();
			  }
			else if(dim==0 && e->getType() == mEntity::MIRROR)
			  {
			    throw 1;
			  }
			else
			  {
			    for(int j=0;j<e->size(0);j++)
			      castbuf->vert[j] = e->get(0,j)->getId();
			    if(e->size(0)<4)castbuf->vert[e->size(0)] = -1;
			  }
			castbuf->pbid=ParUtil::Instance()->rank();
			castbuf->ent=e;
			AP_send(buf);
			sendcounts[sharedPID] ++;
		      } 
		  }
	      }
	  }
      }
    // receive phase begins
    
    AP_check_sends(AP_NOFLAGS);
    AP_reduce_nsends(sendcounts);
    
    int message=0;
    int count;
    while (!AP_recv_count(&count) || message<count) 
      {
	void *msg;
	int from;
	int tag;
	int size;
	int rc;
	rc=AP_recv(MPI_ANY_SOURCE, 444, AP_BLOCKING|AP_DROPOUT,
		   &msg, &size, &from, &tag);
	if (rc) 
	  {
	    message++;	  
	    mentity_intrep *castbuf=(mentity_intrep *)msg;
	    mEntity *recieved (0);
	    if(castbuf->vert[1] == -1)
	      {
		mVertex *localVertex = getVertex(castbuf->vert[0]);	      
		if(!localVertex)
		  ParUtil::Instance()->Msg(ParUtil::WARNING,
					   "[1] unknown vertex %d on proc %d\n",castbuf->vert[0],
					   ParUtil::Instance()->rank());
		//;
		else
		  theOwnerManager->addRemoteCopy((mEntity*)localVertex,
						 from,castbuf->ent,false);	  
		recieved = localVertex;
	      }
	    else if(castbuf->vert[2] == -1) /// It's an edge (alleluya)
	      {
		mVertex *v1 = getVertex(castbuf->vert[0]);
		mVertex *v2 = getVertex(castbuf->vert[1]);
		if(!v1)
		  //;
		  ParUtil::Instance()->Msg(ParUtil::WARNING,
					   "[2] unknown vertex %d on proc %d\n",
					   castbuf->vert[0],ParUtil::Instance()->rank());
		if(!v2)
		  //;
		  ParUtil::Instance()->Msg(ParUtil::WARNING,
					   "[3] unknown vertex %d on proc %d\n",
					   castbuf->vert[1],ParUtil::Instance()->rank());
		mEdge *localEdge = 0;
		if(v1 && v2)
		  localEdge = getEdge(v1,v2);
		if(!localEdge)
		  //;
		  ParUtil::Instance()->Msg(ParUtil::WARNING,
					   "[4] no remote copy for edge %d %d sent from proc %d \n",
					   castbuf->vert[0],castbuf->vert[1],from);
		else 
		  {
		    theOwnerManager->addRemoteCopy((mEntity*)localEdge,
						   from,castbuf->ent,false);	  
		    // this edge should at least knows having a remote copy on processor 'from'
		    bool found = false;
		    for(AOMD_OwnerManager::iter ito = theOwnerManager->begin(localEdge);
			ito != theOwnerManager->end(localEdge);++ito)
		      if((*ito).second.pid() == from)found = true;
		    if(!found)
		      ParUtil::Instance()->Msg(ParUtil::WARNING,
					       "[5] An edge %d %d have a mismatch classification %d (no remote copy on proc %d)\n",
					       castbuf->vert[0],castbuf->vert[1],
					       localEdge->getCommonBdry()->getId(),from);		  
		  }	
		recieved = localEdge;
	      }
	    else if(castbuf->vert[3] == -1)
	      {
		mVertex *v1 = getVertex(castbuf->vert[0]);
		mVertex *v2 = getVertex(castbuf->vert[1]);
		mVertex *v3 = getVertex(castbuf->vert[2]);
		if(!v1)
		  ParUtil::Instance()->Msg(ParUtil::WARNING,
					   "[6] unknown vertex %d on proc %d\n",
					   castbuf->vert[0],ParUtil::Instance()->rank());
		if(!v2)
		  ParUtil::Instance()->Msg(ParUtil::WARNING,
					   "[7] unknown vertex %d on proc %d\n",
					   castbuf->vert[1],ParUtil::Instance()->rank());
		if(!v3)
		  ParUtil::Instance()->Msg(ParUtil::WARNING,
					   "[8] unknown vertex %d on proc %d\n",
					   castbuf->vert[2],ParUtil::Instance()->rank());
		mFace *localFace;
		if(v1 && v2 && v3)
		  {
		    localFace = getTri(getVertex(castbuf->vert[0]),
				       getVertex(castbuf->vert[1]),
				       getVertex(castbuf->vert[2]));	      
		    if(!localFace)
		      ParUtil::Instance()->Msg(ParUtil::WARNING,
					       "[9] no remote copy for face %d %d %d sent from proc %d\n",
					       castbuf->vert[0],castbuf->vert[1],
					       castbuf->vert[2],from);
		    else
		      {
			/// on THIS side, face is localFace
			/// on processor from, face adress is castbuf->ent
			/// false is for not periodic
			theOwnerManager->addRemoteCopy((mEntity*)localFace,
						       from,castbuf->ent,false);	  
		      }
		  }
		recieved = localFace;
	      }
	    else
	      {
		mVertex *v1 = getVertex(castbuf->vert[0]);
		mVertex *v2 = getVertex(castbuf->vert[1]);
		mVertex *v3 = getVertex(castbuf->vert[2]);
		mVertex *v4 = getVertex(castbuf->vert[3]);
		if(!v1)
		  printf("[10] unknown vertex %d on proc %d\n",
			 castbuf->vert[0],ParUtil::Instance()->rank());
		if(!v2)
		  printf("[11] unknown vertex %d on proc %d\n",
			 castbuf->vert[1],ParUtil::Instance()->rank());
		if(!v3)
		  printf("[12] unknown vertex %d on proc %d\n",
			 castbuf->vert[2],ParUtil::Instance()->rank());
		if(!v4)
		  printf("[13] unknown vertex %d on proc %d\n",
			 castbuf->vert[3],ParUtil::Instance()->rank());
		mFace *localFace;
		if(v1 && v2 && v3 && v4)
		  {
		    localFace = getQuad(getVertex(castbuf->vert[0]),
					getVertex(castbuf->vert[1]),
					getVertex(castbuf->vert[2]),
					getVertex(castbuf->vert[3]));	      
		    theOwnerManager->addRemoteCopy((mEntity*)localFace,
						   from,castbuf->ent,false);	  
		  }
		else
		  {
		    ParUtil::Instance()->Msg(ParUtil::WARNING,
					     "[14] no remote copy for quad sent from proc %d \n",
					     from);
		  }
		recieved = localFace;
	      }	  
	    AP_free(msg);

	    if (recieved)
	      {
		int classif = recieved->getCommonBdry() -> getId();
		bool ok = false;
		for ( AOMD_OwnerManager::iter_top it = theOwnerManager->begin_top(classif) ; 
		      it != theOwnerManager->end_top(classif) ; 
		      ++it)
		  {
		    int otherMesh = (*it).second;
		    if (otherMesh == from) ok = 1;
		  }
		if (!ok)
		  {
		    ParUtil::Instance()->Msg(ParUtil::WARNING,
					     "[15] a mesh entity was send form processor %d ", 
					     from);
		    recieved->print();
		    ParUtil::Instance()->Msg(ParUtil::WARNING,
					     "[16] it has a counterpart here but no message was sent there\n", 
					     from);
		  }

		if (recieved -> isAdjacencyCreated ( recieved -> getLevel() ) )
		  {
		    ParUtil::Instance()->Msg(ParUtil::WARNING,
					     "[16] a mesh entity was send form processor %d ", 
					     from);
		    recieved->print();
		    ParUtil::Instance()->Msg(ParUtil::WARNING,
					     "[17] it has childeren so that it is useless to send the info, something is wrong\n");
		  }

	      }
	  }
      }  
    AP_check_sends(AP_WAITALL);
    ParUtil::Instance()->Barrier(__LINE__,__FILE__);
    delete [] sendcounts;
    
// compute owner of common bdry - added 10/14/03 Eunyoung Seol
    theOwnerManager->setPoorPid_asOwner(this);

  }
#else

  void mMesh::bdryLinkSetup()
  {
    theOwnerManager->clearRemoteCopies();
    int n = size(2)?2:1;
    updateCommonBdryEntities(n);

    for(int dim=0;dim<=n;dim++)
      {
	for(iter it = begin(dim); it != end(dim);++it)
	  {
	    mEntity *e = *it;
	    std::list<mEntity*> mirrors;
	    if(lookupForMirrorEntities (e,mirrors))
	      {
		for( std::list<mEntity*>::const_iterator it2 = mirrors.begin() ;
		     it2 != mirrors.end(); ++it2)
		  {
		    theOwnerManager->addRemoteCopy(e,ParUtil::Instance()->rank(),*it2,true);	  	      
		  }
	      }
	  }
      }  
  }
#endif

} // end of namespace
