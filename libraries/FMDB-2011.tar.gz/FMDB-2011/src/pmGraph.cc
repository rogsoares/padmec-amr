/**************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*****************************************************************************/

/*<i> ****************************************************************************
 *
 *  AOMD/pmodel/pmGraphs.cc
 *  Created by Seegyoung Seol, on Mon Dec 08 2003, 10:26:37 EDT
 *
 *  File Content: mesh entity exchange functions
 *
 *************************************************************************** </i>*/
 
#ifdef PARALLEL

#include <iostream>
#include "pmGraphs.h"
#include "pmUtility.h"
#include "pmMigrateUtil.h"
#include "mMesh.h"
#include "mEntity.h"
#include "pmMigrationCallbacks.h"
#include "ParUtil.h"
#include "mAOMD.h"

#include "autopack.h"
#include "pmDataExchanger.h"
#include "AOMD_OwnerManager.h"


#include <stdio.h>
#include <algorithm>
#include <map>

using namespace std;

namespace AOMD {

  class idExchanger : public pmDataExchanger
  {
    int from,to;
    unsigned int tagId;
    unsigned int tagDn;
  public :
    idExchanger(int f, int t):from(f),to(t), 
                             tagId(AOMD_Util::Instance()->getId()),
			     tagDn(AOMD_Util::Instance()->getDn())      
    {}
    virtual int tag() const;
    virtual void * AP_alloc_and_fill_buffer (mEntity *e, int, mEntity*, int);
    virtual void receiveData (int pid, void *buf);   
  };

  int idExchanger :: tag () const
  {
    return 111;
  }

  void* idExchanger:: AP_alloc_and_fill_buffer (mEntity *e, int pid, 
  			mEntity* remoteEnt , int d_tag)
  {
    if(!e->isAdjacencyCreated(from))
      {
	ParUtil::Instance()->Msg(ParUtil::WARNING,"   KATASTROFF \n");
	if (e->size(to)) ParUtil::Instance()->Msg(ParUtil::WARNING," size(to) = %d\n",e->size(to));
	e->print();
	//return 0;
	throw;
      }
  
    void *buf=AP_alloc(pid, d_tag, sizeof(int_mEnt_struct));
    int_mEnt_struct* rp = (int_mEnt_struct*)buf;
  
    rp->i = (*e->begin(from))->getAttachedInt(tagId);
    rp->entity = remoteEnt;
    //    printf("attaching data %d %d ",rp->i,tagDn);e->print();

    return buf;  
  }

  void idExchanger::receiveData (int from, void *buf)
  {
    int_mEnt_struct* castbuf=(int_mEnt_struct*)buf;
    castbuf->entity->attachInt(tagDn,castbuf->i);
    if(castbuf->entity->getAttachedInt(tagDn) != castbuf->i)throw;
    //    printf("recieving data %d %d ",castbuf->i,tagDn);castbuf->entity->print();
  }

  AOMD_distributed_graph2::AOMD_distributed_graph2(mMesh *m, int from, int to,
						   pmMigrationCallbacks *dm,
						   int level)  
  {
    /** Hypothesis is that nodes of the graph are mesh
	entities of dimension from and edges are of dimension
	to */
    int n = from;
    vtxdist = new int [ParUtil::Instance()->size()+1];
    int *nbNodesPerProc = new int [ParUtil::Instance()->size()];

    unsigned int tagId = AOMD_Util::Instance()->getId();
    unsigned int tagDn = AOMD_Util::Instance()->getDn();

    //printf("computing distributed graph (p%d)\n",ParUtil::Instance()->rank());

    /// We compute how many nodes of the graph per processor
    ParUtil::Instance()->Barrier(__LINE__,__FILE__);
    computeNbNodesPerProc(m,nbNodesPerProc,from,level);

    /// We then compute a vector that tells the range
    /// of nodes on processor i : 
    /// range of proc i is [vtxdist[i] ... vtxdist[i+1]]
    int init = 1;
    vtxdist[0] = 1;
    int total = 1;
    for (int i=0;i<ParUtil::Instance()->size();i++)
      {
	total += nbNodesPerProc[i];
	vtxdist[i+1] = total;      
      }
    
    delete [] nbNodesPerProc;
  

    /// Print vtxdist on the stdout
    /*if(ParUtil::Instance()->master())
      {
	ParUtil::Instance()->Msg(ParUtil::WARNING,"vtxdist(%d) = (",ParUtil::Instance()->rank());
	for (int i=0;i<=ParUtil::Instance()->size();i++)
	  {
	    if(i)
	     ParUtil::Instance()->Msg(ParUtil::WARNING,",%d",vtxdist[i]);
	    else
	      ParUtil::Instance()->Msg(ParUtil::WARNING,"%d",vtxdist[i]);
	  }
	ParUtil::Instance()->Msg(ParUtil::WARNING,")\n");	   
      }
    */
    /// We will tag all nodes with id's in this range
    init =vtxdist[ParUtil::Instance()->rank()];  
    /**
       if level < 0 then the graph is composed of all leaves
       of the mesh.

       else the graph is composed of elements of refinement
       level level. level=0 means all roots !!
    */

    if(level < 0)
      {
	for(mMesh::iter it = m->begin(n) ; it!=m->end(n) ; ++it)
	  {	  
	    (*it)->attachInt(tagId,init++);
	    if ((*it)->getAttachedInt(tagId) != init-1)throw;
	  }
      }
    else
      {
	for(mMesh::iterall it = m->beginall(n) ; it!=m->endall(n) ; ++it)
	  {
	    mEntity *e = *it;
	    // we only take this level	  
	    if(m->getRefinementLevel(e) == level)
	      {	    
		int id = init++;
		e->attachInt(tagId,id);
		list<mEntity*> leaves;
		e->getLeaves(leaves);		
		for(list<mEntity*>::const_iterator itl = leaves.begin();itl != leaves.end();++itl)
		  {
		    mEntity *leaf = *itl;
		    leaf->attachInt(tagId,id);
		  }
	      }
	  }
      }

    vector<mEntity*> entOnCB;
    for (mMesh::iterall it=m->beginall(to); it!=m->endall(to);++it)
      if ((*it)->getPClassification())
        entOnCB.push_back(*it);

    /// add neighbors through inter processor boundaries  
    idExchanger myCallback(from,to);
    //ParUtil::Instance()->Msg(ParUtil::INFO,"\n *initialize Graph_DataExchanger...");
    //cout<<"\t("<<ParUtil::Instance()->rank()<<") initialize Graph_DataExchanger...\n";
    genericDataExchanger(entOnCB.begin(), entOnCB.end(),myCallback);
    //ParUtil::Instance()->Msg(ParUtil::INFO," * exchanging data on commonBdry done...\n");
    //printf("\t(%d) exchanging data on commonBdry done...\n",ParUtil::Instance()->rank());
    
    // create the serial graph with inter processor links !!!
    if(level < 0)
      theGraph = new AOMD_graph (m,from,to,false);    
    else
      theGraph = new AOMD_graph (m,from,to,false,level);    

    /// add vertex weights to the graph
    {
      int initial_id = vtxdist[ParUtil::Instance()->rank()];
      if(theGraph->vwgt)delete [] theGraph->vwgt; 
      theGraph->vwgt = new int [theGraph->nn];
      for(int i=0;i<theGraph->nn;i++)theGraph->vwgt[i] = 1;
      for(mMesh::iter it = m->begin(n) ; it!=m->end(n) ; ++it)
	{
	  int id = (*it)->getAttachedInt(tagId) - initial_id;	
	  if(dm->useWeights())
	    theGraph->vwgt[id] *= (int) (dm->getWeight((*it)));
	}
      int sumw = 0;
      {      for(int i=0;i<theGraph->nn;i++)sumw += theGraph->vwgt[i];}
      //      ParUtil::Instance()->Msg(ParUtil::WARNING,"prw = %d\n",sumw);
    }
    


    //printf(" (%d) mGraph done...\n",ParUtil::Instance()->rank());
    for(mMesh::iter it = m->begin(n-1) ; it!=m->end(n-1) ; ++it)
      (*it)->deleteData(tagDn);
  }


  void AOMD_distributed_graph2 :: print(ostream &o)
  {
    printf("on processor %d :\n",ParUtil::Instance()->rank());
    theGraph->print(o);
    o << "vtxdist : ";
    for(int i=0;i<=ParUtil::Instance()->size();i++)o << vtxdist[i] << " ";
    o << "\n";
  }



  AOMD_distributed_graph2 :: ~AOMD_distributed_graph2()
  {
    delete theGraph;
    delete [] vtxdist;
  }

} // end of namespace

#endif
