/* 
   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of Trellis written and maintained by the 
   Scientific Computation Research Center (SCOREC) at Rensselaer Polytechnic
   Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA
*/
#include <iostream>
#include <algorithm>
#include "LagrangeMapping.h"
#ifndef SIM
#include "AOMD_Internals.h"
#endif
#include "mPoint.h"

#include <math.h>
#include <stdio.h>
#include <assert.h>

using std::cout;
using std::vector;

namespace Trellis_Util {

  LagrangeMapping::LagrangeMapping (pEntity e)
    :Mapping(e)
  {
    std::vector<pVertex> verts;
    M_GetVertices (ent,verts);
    for(int i=0;i<verts.size();i++)
      {
	pPoint p =  V_point(verts[i]); 
	knots.push_back(mPoint(P_x(p),P_y(p),P_z(p)));
      }    
    elementType = M_GetElementType(ent);
  }
  
  /*
  LagrangeMapping::LagrangeMapping (pEntity e, LevelSetFunction _levelSetFunc, 
						       int condition = 1)
    :Mapping(e)
  {
    std::vector<pVertex> verts;
    M_GetVertices (ent, verts);
    double *tmp = new double[verts.size()];
    std::vector<AOMD::mPoint> pts(verts.size());
    int count = 0;	// The number of count denote the ElementType	
    //    int num_pos = 0;
    //    int num_neg = 0;

    double product = 1;
    for(int i = 0; i<verts.size(); i++)
      {
	pPoint p = V_point(verts[i]);
	pts[i] = AOMD::mPoint(P_x(p), P_y(p), P_z(p));
	tmp[i] = _levelSetFunc(pts[i]);
	product *=tmp[i];
      }

    switch(M_GetElementType(ent)) 
      {
      case TRI: 
	{
	  if(condition > 0) 
	    {
	std::cout << " condition > 0" << std::endl;	
	      if(tmp[0] >= 0 && tmp[1] >= 0 && tmp[2] >= 0)
		{
		  std::cout << " All Positive" << std::endl;
		  for(int i = 0 ; i< verts.size(); i++)
		      knots.push_back(pts[i]);
		  count = 3;
		  //		  elementType = TRI;
		}
	      else if(tmp[0] <= 0 && tmp[1] <= 0 && tmp[2] <= 0)
		{
		  std::cout << " All Negative" << std::endl;
		  count = 0;
		}
	      else
		{
		  std::cout << " Positive & Negative" << std::endl;
		  for(int i =0 ; i<verts.size(); i++)
		    {
		      int x = (i+1)%verts.size();	
		      if(tmp[i] >= 0)
			{
			  knots.push_back(pts[i]);
			  count++;
			  if(tmp[i] > 0 && tmp[x] < 0)
			    {
			      double lamda = fabs(tmp[i]/tmp[x]);	
			      AOMD::mPoint p1( (pts[i](0) + lamda*pts[x](0))/(1+lamda),  
					       (pts[i](1) + lamda *pts[x](1))/(1+lamda), 0);
			      knots.push_back(p1);
			      count++;		
			    }  			  
			} // end of tmp[i]>=0
		      else 
			{
			  if(tmp[x] > 0)
			    {
			      double lamda = fabs(tmp[i]/tmp[x]);
                              AOMD::mPoint p1( (pts[i](0) + lamda*pts[x](0))/(1+lamda),
                                               (pts[i](1) + lamda *pts[x](1))/(1+lamda), 0);
                              knots.push_back(p1);
                              count++;	
			    }				  
			}	
		    } // // end of loop for
		}  // // end of cases with positive and negative value
	    }//end of condition > 0

          else if (condition < 0)
            {
              if(tmp[0] <= 0 && tmp[1] <= 0 && tmp[2] <= 0)
                {
		  for(int i = 0; i< verts.size(); i++)
		    knots.push_back(pts[i]);
		  count = 3;
		  //                  elementType = TRI;
                }
              else if(tmp[0] >= 0 && tmp[1] >= 0 && tmp[2] >= 0)
                {
		  count = 0;         
                }
              else
                {
                  for(int i =0 ; i<verts.size(); i++)
                    {
                      int x = (i+1)%verts.size();
                      if(tmp[i] <= 0)
                        {
                          knots.push_back(pts[i]);
                          count++; 
                          if(tmp[i] < 0 && tmp[x] > 0)
                            {
                              double lamda = fabs(tmp[i]/tmp[x]);
                              AOMD::mPoint p1( (pts[i](0) + lamda*pts[x](0))/(1+lamda),
                                               (pts[i](1) + lamda *pts[x](1))/(1+lamda), 0);
                              knots.push_back(p1);
                              count++;
                            }
                        } // end of tmp[i]<=0
                      else
                        {
                          if(tmp[x] < 0)
                            {
                              double lamda = fabs(tmp[i]/tmp[x]);
                              AOMD::mPoint p1( (pts[i](0) + lamda*pts[x](0))/(1+lamda),
                                               (pts[i](1) + lamda *pts[x](1))/(1+lamda), 0);
                              knots.push_back(p1);
                              count++;
                            }
                        }
                    } // end of loop for
                }  // end of cases with positive and negative value
            }//end of condition < 0

	  else
	    {
	      if(tmp[0] > 0 && tmp[1] > 0 && tmp[2] > 0)
		{
		  count = 0;
		}
	      else if(tmp[0] < 0 && tmp[1] < 0 && tmp[2] < 0)
		{
		  count = 0;
		}
	      else
		{
                  for(int i =0 ; i<verts.size(); i++)
                    {
                      int x = (i+1)%verts.size();
                      if(tmp[i] == 0)
                        {
                          knots.push_back(pts[i]);
                          count++; 
                        } // end of tmp[i]==0
                      else if( tmp[i]*tmp[x] < 0)
                        {
                              double lamda = fabs(tmp[i]/tmp[x]);
                              AOMD::mPoint p1( (pts[i](0) + lamda*pts[x](0))/(1+lamda),
                                               (pts[i](1) + lamda *pts[x](1))/(1+lamda), 0);
                              knots.push_back(p1);
                              count++;
                        }
		      else;	
		    } //end of loop for
		} // end of situation not all values > 0 or all values < 0			
	    }	// end of condition = 0

	}// end of case TRI
	break;


      case QUAD:
	{
	{
	  if(condition > 0) 
	    {
	std::cout << " condition > 0" << std::endl;	
	      if(tmp[0] >= 0 && tmp[1] >= 0 && tmp[2] >= 0 && tmp[3] >=0)
		{
		  std::cout << " All Positive" << std::endl;
		  for(int i = 0 ; i< verts.size(); i++)
		      knots.push_back(pts[i]);
		  count = 4;
		  //		  elementType = QUAD;
		}
	      else if(tmp[0] <= 0 && tmp[1] <= 0 && tmp[2] <= 0 && tmp[3] <= 0)
		{
		  std::cout << " All Negative" << std::endl;
		  count = 0;
		}
	      else
		{
		  std::cout << " Positive & Negative" << std::endl;
		  for(int i =0 ; i<verts.size(); i++)
		    {
		      int x = (i+1)%verts.size();	
		      if(tmp[i] >= 0)
			{
			  knots.push_back(pts[i]);
			  count++;
			  if(tmp[i] > 0 && tmp[x] < 0)
			    {
			      double lamda = fabs(tmp[i]/tmp[x]);	
			      AOMD::mPoint p1( (pts[i](0) + lamda*pts[x](0))/(1+lamda),  
					       (pts[i](1) + lamda *pts[x](1))/(1+lamda), 0);
			      knots.push_back(p1);
			      count++;		
			    }  			  
			} // end of tmp[i]>=0
		      else 
			{
			  if(tmp[x] > 0)
			    {
			      double lamda = fabs(tmp[i]/tmp[x]);
                              AOMD::mPoint p1( (pts[i](0) + lamda*pts[x](0))/(1+lamda),
                                               (pts[i](1) + lamda *pts[x](1))/(1+lamda), 0);
                              knots.push_back(p1);
                              count++;	
			    }				  
			}	
		    } // // end of loop for
		}  // // end of cases with positive and negative value
	    }//end of condition > 0

          else if (condition < 0)
            {
              if(tmp[0] <= 0 && tmp[1] <= 0 && tmp[2] <= 0 && tmp[3] <= 0)
                {
		  for(int i = 0; i< verts.size(); i++)
		    knots.push_back(pts[i]);
		  count = 4;
		  //                  elementType = QUAD;
                }
              else if(tmp[0] >= 0 && tmp[1] >= 0 && tmp[2] >= 0 && tmp[3] >= 0)
                {
		  count = 0;         
                }
              else
                {
                  for(int i =0 ; i<verts.size(); i++)
                    {
                      int x = (i+1)%verts.size();
                      if(tmp[i] <= 0)
                        {
                          knots.push_back(pts[i]);
                          count++; 
                          if(tmp[i] < 0 && tmp[x] > 0)
                            {
                              double lamda = fabs(tmp[i]/tmp[x]);
                              AOMD::mPoint p1( (pts[i](0) + lamda*pts[x](0))/(1+lamda),
                                               (pts[i](1) + lamda *pts[x](1))/(1+lamda), 0);
                              knots.push_back(p1);
                              count++;
                            }
                        } // end of tmp[i]<=0
                      else
                        {
                          if(tmp[x] < 0)
                            {
                              double lamda = fabs(tmp[i]/tmp[x]);
                              AOMD::mPoint p1( (pts[i](0) + lamda*pts[x](0))/(1+lamda),
                                               (pts[i](1) + lamda *pts[x](1))/(1+lamda), 0);
                              knots.push_back(p1);
                              count++;
                            }
                        }
                    } // end of loop for
                }  // end of cases with positive and negative value
            }//end of condition < 0

	  else
	    {
	      if(tmp[0] > 0 && tmp[1] > 0 && tmp[2] > 0 && tmp[3] > 0)
		{
		  count = 0;
		}
	      else if(tmp[0] < 0 && tmp[1] < 0 && tmp[2] < 0 && tmp[3] < 0)
		{
		  count = 0;
		}
	      else
		{
                  for(int i =0 ; i<verts.size(); i++)
                    {
                      int x = (i+1)%verts.size();
                      if(tmp[i] == 0)
                        {
                          knots.push_back(pts[i]);
                          count++; 
                        } // end of tmp[i]==0
                      else if( tmp[i]*tmp[x] < 0)
                        {
                              double lamda = fabs(tmp[i]/tmp[x]);
                              AOMD::mPoint p1( (pts[i](0) + lamda*pts[x](0))/(1+lamda),
                                               (pts[i](1) + lamda *pts[x](1))/(1+lamda), 0);
                              knots.push_back(p1);
                              count++;
                        }
		      else;	
		    } //end of loop for
		} // end of situation not all values > 0 or all values < 0			
	    }	// end of condition = 0

	}// end of case QUAD	  
	}
	break;
      default: 
	cout << "GeomshapeFunction: Entity type not supported\n"; 
      }
    
    cout << "Elementtype    " << count << std::endl; 
    switch(count)
      {
      case 1: 
	{
	  elementType = VERTEX;  
	  int k = 0;
	  ent->setElementDim(k);
	}
	break;	
      case 2: 
	{
	elementType = EDGE;
	int k = 1;
	ent->setElementDim(k);
	}
	break;
      case 3: 
	{
	elementType = TRI;     
	int k = 2;
	  ent->setElementDim(k);  
	}
	break;
      case 4: 
	{
	elementType = QUAD;    
	int k = 2;
	ent->setElementDim(k);
	}
	break;
      case 5: 
	{
	elementType = (TRELLIS_MTYPE)5;     
	int k = 2;
	ent->setElementDim(k);
	}
	break;

      default:
	{
	cout << " Wrong Entity type \n";
	elementType  = VERTEX;
	int k = -1;
	ent->setElementDim(k);
	}
      }

    delete []tmp;
  }
  */

  LagrangeMapping::LagrangeMapping(pEntity me, std::vector<mPoint> *input_knots):Mapping(me)
  {
    int i = 0;
    while ( i < input_knots->size())
      {
	knots.push_back((*input_knots)[i]);
	i++;
      }
    elementType = ((TRELLIS_MTYPE)(input_knots->size()-1));
    
  }

  
  int LagrangeMapping::order() const
  { 
    return 1; 
  }

  int LagrangeMapping::geomOrder() const
  { 
    return 1; 
  }


  void GeomShapeFunctionQuad (double u, double v, double dum, double *x)
  {
    x[0] =  0.25 * (1.-u) * (1.-v);
    x[1] =  0.25 * (1.+u) * (1.-v);
    x[2] =  0.25 * (1.+u) * (1.+v);
    x[3] =  0.25 * (1.-u) * (1.+v);
  } 

  void GeomShapeFunctionTet (double u, double v, double w, double *x)
  {
    x[0] =  1.-u-v-w;
    x[1] =  u;
    x[2] =  v;
    x[3] =  w;
  } 
  
  void GeomShapeFunctionHex (double u, double v, double w, double *x)
  {
    x[0] = 0.125 * (1.-u) * (1.-v) * (1.-w);
    x[1] = 0.125 * (1.+u) * (1.-v) * (1.-w);
    x[2] = 0.125 * (1.+u) * (1.+v) * (1.-w);
    x[3] = 0.125 * (1.-u) * (1.+v) * (1.-w);
    x[4] = 0.125 * (1.-u) * (1.-v) * (1.+w);
    x[5] = 0.125 * (1.+u) * (1.-v) * (1.+w);
    x[6] = 0.125 * (1.+u) * (1.+v) * (1.+w);
    x[7] = 0.125 * (1.-u) * (1.+v) * (1.+w);
  } 


  void GeomShapeFunctionTri ( double u, double v, double dum, double *result)
  {
    double w = 1.-u-v;
    result[0] = w;
    result[1] = u;
    result[2] = v;
  }

  void GradGeomShapeFunctionTri (double u, double v, double dum , mVector *result)
  {
    result[0] (0)  = -1.0;
    result[1] (0)  = 1.0;
    result[2] (0)  = 0.0;
    result[0] (1)  = -1.0;
    result[1] (1)  = 0.0;
    result[2] (1)  = 1.0;    
    result[0] (2) = 0.0; 
    result[1] (2) = 0.0; 
    result[2] (2) = 0.0; 
  }

  void GradGeomShapeFunctionQuad (double u, double v, double dum , mVector *result)
  {
    double t1 = v-1.0;
    double t2 = v+1.0;
    double t3 = u-1.0;
    double t4 = -u-1.0;
    result[0] (0)  = t1/4.0;
    result[1] (0)  = -t1/4.0;
    result[2] (0)  = t2/4.0;
    result[3] (0)  = -t2/4.0;
    result[0] (1)  = t3/4.0;
    result[1] (1)  = t4/4.0;
    result[2] (1)  = -t4/4.0;
    result[3] (1)  = -t3/4.0;    
    result[0] (2) = 0.0; 
    result[1] (2) = 0.0; 
    result[2] (2) = 0.0; 
    result[3] (2) = 0.0; 
  } 
  
  void GradGeomShapeFunctionTet (double u, double v, double dum , mVector *result)
  {
    result[0] (0)  = -1.0;
    result[1] (0)  = 1.0;
    result[2] (0)  = 0.0;
    result[3] (0)  = 0.0;
    result[0] (1)  = -1.0;
    result[1] (1)  = 0.0;
    result[2] (1)  = 1.0;
    result[3] (1)  = 0.0;
    result[0] (2)  = -1.0;
    result[1] (2)  = 0.0;
    result[2] (2)  = 0.0;
    result[3] (2)  = 1.0;
  } 
  
  void GradGeomShapeFunctionHex (double u, double v, double w , mVector *grad)
  {
    grad[0][0] = -0.125*(1.-v)*(1.-w) ; grad[0][1]= -0.125*(1.-u)*(1.-w); grad[0][2] = -0.125*(1.-u)*(1.-v);
    grad[1][0] =  0.125*(1.-v)*(1.-w) ; grad[1][1]= -0.125*(1.+u)*(1.-w); grad[1][2] = -0.125*(1.+u)*(1.-v);
    grad[2][0] =  0.125*(1.+v)*(1.-w) ; grad[2][1]=  0.125*(1.+u)*(1.-w); grad[2][2] = -0.125*(1.+u)*(1.+v);
    grad[3][0] = -0.125*(1.+v)*(1.-w) ; grad[3][1]=  0.125*(1.-u)*(1.-w); grad[3][2] = -0.125*(1.-u)*(1.+v);
    grad[4][0] = -0.125*(1.-v)*(1.+w) ; grad[4][1]= -0.125*(1.-u)*(1.+w); grad[4][2] =  0.125*(1.-u)*(1.-v);
    grad[5][0] =  0.125*(1.-v)*(1.+w) ; grad[5][1]= -0.125*(1.+u)*(1.+w); grad[5][2] =  0.125*(1.+u)*(1.-v);
    grad[6][0] =  0.125*(1.+v)*(1.+w) ; grad[6][1]=  0.125*(1.+u)*(1.+w); grad[6][2] =  0.125*(1.+u)*(1.+v);
    grad[7][0] = -0.125*(1.+v)*(1.+w) ; grad[7][1]=  0.125*(1.-u)*(1.+w); grad[7][2] =  0.125*(1.-u)*(1.+v);
  } 

  void GeomShapeFunctionLine (double u, double v, double w, double *result)
  {
    result[0] = -u*.5+.5;
    result[1] = u*.5+.5;
  }

  void GradGeomShapeFunctionLine (double u, double v, double w, mVector *grad)
  {
    grad[0](1) = grad[0](2) = 0.0;
    grad[1](1) = grad[1](2) = 0.0;
    grad[0](0) = (-0.5);
    grad[1](0) = (+0.5);
  }
  
  void GeomShapeFunctionPrism (double u, double v, double w, double *x)
  {
    double k = 1.-u-v;
    x[0] =  (k) * (0.5*(1.+w));
    x[1] =  (u) * (0.5*(1.+w));
    x[2] =  (v) * (0.5*(1.+w));
    x[3] =  (k) * (0.5*(1.-w));
    x[4] =  (u) * (0.5*(1.-w));
    x[5] =  (v) * (0.5*(1.-w));
  } 

  void GradGeomShapeFunctionPrism (double u, double v, double w , mVector *grad)
  {
    grad[0][0] = -0.5*(1.+w) ; grad[0][1]= -0.5*(1.+w); grad[0][2] = 0.5*(1.-u-v);
    grad[1][0] =  0.5*(1.+w) ; grad[1][1]= 0.0        ; grad[1][2] = 0.5*(u);
    grad[2][0] =  0.0        ; grad[2][1]= -0.5*(1.+w); grad[2][2] = 0.5*(v);
    grad[3][0] = -0.5*(1.-w) ; grad[3][1]= -0.5*(1.-w); grad[3][2] = -0.5*(1.-u-v);
    grad[4][0] =  0.5*(1.-w) ; grad[4][1]= 0.0        ; grad[4][2] = -0.5*(u);
    grad[5][0] =  0.0        ; grad[5][1]= -0.5*(1.-w); grad[5][2] = -0.5*(v);
  } 


  void LagrangeMapping::eval(double u, double v, double w, 
			     double &x, double &y, double &z) const
  {

    x = 0.0, y = 0.0, z = 0.0;
    double f[256];
    GeomShapeFunction (u,v,w,f);
    for(int i=0;i<knots.size();i++)
      {
	mPoint p =  knots[i];
	double fct = f[i];
	x += p(0) * fct;
	y += p(1) * fct;
	z += p(2) * fct;
      }
  }

  void LagrangeMapping::deval(double u, double v, double w, 
			      double &dxdu, double &dydu, double &dzdu,
			      double &dxdv, double &dydv, double &dzdv,
			      double &dxdw, double &dydw, double &dzdw) const
  {
    dxdu = 0.0, dydu = 0.0, dzdu = 0.0;
    dxdv = 0.0, dydv = 0.0, dzdv = 0.0;
    dxdw = 0.0, dydw = 0.0, dzdw = 0.0;
    mVector dus[256];
    GradGeomShapeFunction  (u ,  v ,  w, dus);
    for(int i=0;i<knots.size();i++)
      {
	mVector du(dus[i]);
	mPoint p =  knots[i];

	const double xx = p(0);
	const double yy = p(1);
	const double zz = p(2);

	dxdu += xx * du(0);
	dydu += yy * du(0);
	dzdu += zz * du(0);

	dxdv += xx * du(1);
	dydv += yy * du(1);
	dzdv += zz * du(1);

	dxdw += xx * du(2);
	dydw += yy * du(2);
	dzdw += zz * du(2);
      }
  }

  void LagrangeMapping::normalVector (pEntity border , double u, double v, double w, mVector &n) const
  {

    // In case of a mesh mapping, the normal to an entity which is on
    // a border = sum of grad geom shape functions which node are not
    // on the border entity

    n[0] = n[1] = n[2] = 0.0;
  
    mTensor2 jInv;
    double detJac = jacInverse(u,v,w,jInv);

    std::vector<pVertex> verts;
    M_GetVertices (ent,verts);
    std::vector<pVertex> vb;
    M_GetVertices (border,vb);

    mVector dus[256];
    GradGeomShapeFunction  (u ,  v ,  w, dus);

    for(int i=0;i<verts.size();i++)
      {
	std::vector<pVertex>::iterator it = std::find (vb.begin(),vb.end(),verts[i]);
	if(it == vb.end())
	  {
	    mVector gr(dus[i]);
	    gr *= jInv;
	    n-= gr;
	  }
      }
    n.norm();
  }

  ConstantLagrangeMapping::ConstantLagrangeMapping(pEntity m)
    : LagrangeMapping(m)
  {
    det = LagrangeMapping::jacInverse(0,0,0,jac);
    if(det < 0)det = -det;
  }

  CylindricalCoordinatesLagrangeMapping::CylindricalCoordinatesLagrangeMapping(pEntity m)
    : LagrangeMapping(m)
  {  
  }

  double ConstantLagrangeMapping::detJac(double,double,double) const
  {
    return det;
  }

  double ConstantLagrangeMapping::jacInverse(double,double,double,mTensor2 &j) const
  {
    j = jac;
    return det;
  }

  double CylindricalCoordinatesLagrangeMapping::detJac(double u,double v,double w) const
  {
    mTensor2 j;
    double r,z,teta;
    eval(u,v,w,r,z,teta);
    //  printf("r = %12.5E det = %12.5E\n",r,LagrangeMapping::jacInverse(u,v,w,j) );
    return (r * LagrangeMapping::jacInverse(u,v,w,j));
  }

  double CylindricalCoordinatesLagrangeMapping::jacInverse(double u,double v,double w,mTensor2 &j) const
  {
    double r,z,teta;
    eval(u,v,w,r,z,teta);
    double det = LagrangeMapping::jacInverse (u,v,w,j);
    return (r * det);
  }

  int CylindricalCoordinatesLagrangeMapping::order() const
  { 
    return 2; 
  }


  RegularCubeLagrangeMapping::RegularCubeLagrangeMapping(pEntity e)
    : LagrangeMapping(e)
  {
    std::vector<pVertex> v;
    M_GetVertices (e,v);

    double x1,y1,z1;
    for(int i=0;i<v.size();i++)
      {
	pPoint pt = V_point(v[i]); 
	mPoint p = mPoint(P_x(pt),P_y(pt),P_z(pt)); 
	if(!i)
	  {
	    x0 = x1 = p(0);
	    y0 = y1 = p(1);
	    z0 = z1 = p(2);
	  }
	else
	  {
	    if(x0 > p(0))x0 = p(0);
	    if(y0 > p(1))y0 = p(1);
	    if(z0 > p(2))z0 = p(2);
	    if(x1 < p(0))x1 = p(0);
	    if(y1 < p(1))y1 = p(1);
	    if(z1 < p(2))z1 = p(2);
	  }
      }
    dx = x1-x0;
    dy = y1-y0;

    //  printf("%f %f %f %f\n",x0,y0,dx,dy);

    if(elementType == QUAD)
      dz = 1.0;
    else
      dz = z1-z0;
  }

  void RegularCubeLagrangeMapping::eval(double u, double v, double w,
					double &x, double &y, double &z) const
  {
    x = x0 + .5 * (1.+u) * dx;
    y = y0 + .5 * (1.+v) * dy;
    if(elementType == QUAD)
      z = 0.0;
    else
      z = z0 + .5 * (1.+w) * dz;
  }

  void RegularCubeLagrangeMapping::deval(double u, double v, double w,
					 double &dxdu, double &dydu, double &dzdu,
					 double &dxdv, double &dydv, double &dzdv,
					 double &dxdw, double &dydw, double &dzdw) const
  {
    dxdu = 0.5 * dx;
    dydv = 0.5 * dy;
    if(elementType == QUAD)
      dzdw = 0.0;
    else
      dzdw = .5 * dz;
    dxdv=dxdw=dydu=dydw=dzdu=dzdv = 0.0;

  }

  bool RegularCubeLagrangeMapping::invert(double x, double y, double z,
					  double &u, double &v, double &w) const
  {
    u = 2.* (x-x0)/dx -1.0;
    v = 2.* (y-y0)/dy -1.0;
    if(elementType == QUAD)
      w = 0.0;
    else
      w = 2.* (z-z0)/dz -1.0;

    //  printf("%f %f -> %f %f\n",x,y,u,v);

    return true;
  }

  double RegularCubeLagrangeMapping::detJac(double u, double v, double w) const
  {
    if(elementType == QUAD)
      return 0.25*(dx*dy);
    else
      return 0.125*(dx*dy*dz);
  }

  double RegularCubeLagrangeMapping::jacInverse(double u, double v, double w, 
						mTensor2& jInv) const
  {    
    jInv(0,0) = 2./dx;
    jInv(1,1) = 2./dy;
    if(elementType == QUAD)
      jInv(2,2) = 1.0;
    else
      jInv(2,2) = 2./dz;

    jInv(1,2) = jInv(2,1) 
      = jInv(2,0) = jInv(0,2) 
      = jInv(0,1) = jInv(1,0) = 0.0;
    return detJac(0,0,0);
  }

  void RegularCubeLagrangeMapping::normalVector (pEntity border , double u, double v, double w, mVector &n) const
  {
    double u1,v1,w1;
    mPoint p1;
    LagrangeMapping lm(border);
    lm.COG(u1,v1,w1);
    lm.eval(u1,v1,w1,p1(0),p1(1),p1(2));

    if( fabs(p1(0) - x0) < 1.e-6 * dx ) n = mVector(-1,0,0);
    else if( fabs(p1(0) - x0 - dx) < 1.e-6 * dx ) n = mVector(1,0,0);
    else if( fabs(p1(1) - y0) < 1.e-6 * dy ) n = mVector(0,-1,0);
    else if( fabs(p1(1) - y0 - dy) < 1.e-6 * dy ) n = mVector(0,1,0);
    else if( fabs(p1(2) - z0) < 1.e-6 * dz ) n = mVector(0,0,-1);
    else if( fabs(p1(2) - z0 - dz) < 1.e-6 * dz ) n = mVector(0,0,1);
    else assert (1==0);
  }

  double RegularCubeLagrangeMapping::PushBack (double u, double v, double w, int vsize, vector<mVector> &gr) const
  {
    double detJ = detJac(u,v,w);
  
    double xx = 2./dx;
    double yy = 2./dy;
    double zz = 2./dz;

    for(int i=0;i<vsize;i++)
      {
	gr[i](0) *= (xx);
	gr[i](1) *= (yy);
	if(elementType == HEX)
	  gr[i](2) *= (zz);	
      }
    return detJ;
  }

  void LagrangeMapping::boundingBox (  mPoint &pMin, mPoint &pMax ) const
  {
    std::vector<pVertex> v;
    M_GetVertices (ent,v);
    pPoint pt = V_point(v[0]); 
    pMin = pMax = mPoint(P_x(pt),P_y(pt),P_z(pt));    
    int size = v.size();;
    for(int i=1;i<size;i++)
      { 
	pt = V_point(v[i]); 
	mPoint p1 = mPoint(P_x(pt),P_y(pt),P_z(pt)); 
	if (p1(0) < pMin(0)) pMin(0) = p1(0);
	if (p1(1) < pMin(1)) pMin(1) = p1(1);
	if (p1(2) < pMin(2)) pMin(2) = p1(2);
	if (p1(0) > pMax(0)) pMax(0) = p1(0);
	if (p1(1) > pMax(1)) pMax(1) = p1(1);
	if (p1(2) > pMax(2)) pMax(2) = p1(2);
      }
  }
  
  void LagrangeMapping::GeomShapeFunction (double u, double v, double w, double *x) const
  {
    switch(elementType)
      {
      case VERTEX : x[0] = 1.0;break;
      case EDGE   : GeomShapeFunctionLine(u,v,w,x);break;
      case TRI    : GeomShapeFunctionTri(u,v,w,x);break;
      case QUAD   : GeomShapeFunctionQuad(u,v,w,x);break;
      case TET    : GeomShapeFunctionTet(u,v,w,x);break;
      case HEX    : GeomShapeFunctionHex(u,v,w,x);break;
      case PRISM  : GeomShapeFunctionPrism(u,v,w,x);break;
      default: 
	cout << "GeomshapeFunction: Entity type not supported\n"; 
      }
  }
  void LagrangeMapping::GradGeomShapeFunction (double u, double v, double w,mVector *grad) const
  {
    switch(elementType)
      {
      case VERTEX : grad[0][0] = grad[0][1] = grad[0][2] = 0.0;break;
      case EDGE   : GradGeomShapeFunctionLine (u,v,w,grad);break;
      case TRI    : GradGeomShapeFunctionTri  (u,v,w,grad);break;
      case QUAD   : GradGeomShapeFunctionQuad (u,v,w,grad);break;
      case TET    : GradGeomShapeFunctionTet (u,v,w,grad);break;
      case HEX    : GradGeomShapeFunctionHex (u,v,w,grad);break;
      case PRISM  : GradGeomShapeFunctionPrism (u,v,w,grad);break;
      default: break; // need to throw an exception here
      }
  }

} // end of namespace
