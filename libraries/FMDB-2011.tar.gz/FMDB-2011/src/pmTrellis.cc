/**************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*****************************************************************************/

/*<i> ****************************************************************************
 *
 *  AOMD/pmodel/pmTrellis.cc
 *  Created by Seegyoung Seol, on Tue Dec 23 2003, 10:26:37 EDT
 *
 *  File Content: parallel Trellis suppoting functions
 *
 *************************************************************************** </i>*/

#ifdef PARALLEL

#include <stdio.h>
#include <iostream>
#include <assert.h>
#include <vector>
#include <list>

#include "pmTrellis.h"
#include "pmUtility.h"
#include "pmMeshAdapt.h"
#include "ParUtil.h"
#include "autopack.h"
#include "AOMD_cint.h"

using std::vector;
using std::list;
using std::cout;
using std::endl;

namespace AOMD {


/*  
  This function assign the range to each mesh entity.  
  IN: mMesh* theMesh              mesh handle
      vector<mEntity*> entities   contains mesh entities on each processor
      vector<int> numInt          contains entities[i]'s # of integers to assign 
      unsigned int tag            tag
      int starting_range	  starting integer of the range
  OUT:vector<pair<int,int>> range contains the range of entities[i]
                                  the first contains starting integer
                                  the second contains the # of intergers
  for example, assume starting_range is 1.
               if, in P1, entities=[v1,v2,v3], numInt=[1,2,4]
                   in P2, entities=[v4,v1,v3], numInt=[5,2,4]  
              then,in P1, range=[(1,2),(3,2),(5,4)]
                   in P2, range=[(9,5),(1,2),(5,4)]
*/


// this new one is consistent with poor ownership 

/* ALGORITH:
   
   1. unify numInt;
   2. if entity is only copy or CB&&owner
       counter++;
   3. counter=initialRangeValue;
      counter += counter of all less pid (ex) counter[2] = counter[0]+counter[1]+1
   4. for all only and CB&&owner
        attach counter, numInt
	if (CB && owner)
	{
	  send counter to counterpart
	}   
	counter++;
   5. when recv, set counter

*/

/* 
  TWO ASSUMPTION FOR THIS FUNCTION
   1. numInt is 1 for all entities
   2. If the mesh entity is on CB, all copies should be given to this function
 */

void assignUniqueRange(mMesh* theMesh, unsigned int startRangeTag,
                      unsigned int endRangeTag, int initialRangeValue,
                      std::vector<mEntity*> & entities, std::vector<int> & numInt)
{

  assert(entities.size()==numInt.size());

// intialize
  int numPtn = ParUtil::Instance()->size();
  int mypid = ParUtil::Instance()->rank();
  
  int numOwnedEntities = 0;
  mEntity* ent;
  vector<mEntity*>::iterator entIter;

  int* sendcounts=new int[numPtn];
  int message=0;
  int count;

// assert all remote copies of CB entity are given
/*  cout<<"* ("<<P_pid()<<") entities: ";
  for (entIter = entities.begin(); entIter!=entities.end();++entIter)
  {
    cout<<(*entIter)->getUid()<<", ";
  }
  cout<<endl;
*/  

// ******************************
// STEP 1: check CB entities 
// ******************************
  for (int i=0;i<numPtn;++i) sendcounts[i]=0;
  for (entIter = entities.begin(); entIter!=entities.end();++entIter)
  {
    ent = (*entIter);
    if (!ent->getPClassification()) // non-CB entity
      continue;
    for (mEntity::RCIter rciter=ent->rcBegin(); rciter!=ent->rcEnd();++rciter)
    {
      // send phase begins to find the entity in the counterpart
      // and assign the same id		
      void* buf = AP_alloc(rciter->first, 4454, sizeof(mEnt_struct));
      mEnt_struct* castbuf = (mEnt_struct*)buf;
      castbuf->entity = rciter->second;
      AP_send(buf);
      sendcounts[rciter->first]++;
    } // for
  }  // for

  // receive phase begins
  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts);
  message=0;

  while(!AP_recv_count(&count) || message<count)
  {
    void* msg;
    int from, tag, size, rc;
    rc = AP_recv(MPI_ANY_SOURCE, 4454, AP_BLOCKING|AP_DROPOUT, &msg, &size, &from, &tag);
    if (rc)
    {
      message++;
      mEnt_struct* castbuf = (mEnt_struct*) msg;
      if (std::find(entities.begin(), entities.end(), castbuf->entity)==entities.end())
      {
        entities.push_back(castbuf->entity);
	cout<<"\t("<<P_pid()<<") AOMD WARNING: CB entity "
	    <<castbuf->entity->getUid()<<" is not given as input\n";  
      }
      AP_free(msg);	
    }  // end of if (rc)
  }  // end of while(!AP...)
    
  AP_check_sends(AP_WAITALL);

// ******************************
// STEP 2: count the owned entities
// ******************************
  
  for (entIter = entities.begin(); entIter!=entities.end();++entIter)
  {
    ent = (*entIter);
    if (!ent->getPClassification()) // non-CB entity
        numOwnedEntities++;
    else
    {
      if (ent->getOwner()==ParUtil::Instance()->rank())
        numOwnedEntities++;
    }   
  }


// ******************************
// STEP 3: compute initial_range value
// ******************************

  int* senddata;
  int* recvdata;

  // send phase begins

  for (int i=0;i<numPtn;++i) sendcounts[i]=0;
 
  for (int pid=mypid+1; pid<numPtn;++pid)
  {
    senddata = (int*)AP_alloc(pid,5559,sizeof(int));
    *senddata = numOwnedEntities;
    AP_send(senddata);
    sendcounts[pid]++;
  }

  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts);

  message=0;
  
  while(!AP_recv_count(&count)||message<count)
  {
    int from,tag,size,rc;
  // receive phase begins
    rc=AP_recv(MPI_ANY_SOURCE,5559,AP_BLOCKING|AP_DROPOUT,(void**)&recvdata,&size,&from,&tag);
    if (rc)
    {
      message++;
//      cout<<"("<<M_Pid()<<") recieve "<<(*recvdata)<<" from P"<<from<<endl;
      initialRangeValue+=(*recvdata);
      AP_free(recvdata);
    }  // if(rc)
  } // while
  AP_check_sends(AP_WAITALL);

//  cout<<"("<<mypid<<") numOwnedEntities="<<numOwnedEntities<<"\n";
//  cout<<"("<<mypid<<") initialRangeValue="<<initialRangeValue<<"\n";
  
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);

// ******************************
// STEP 4: attach range to the entities
// ******************************
// it requires one more communication to unify range for the CB entity

  // initialize sendcounts
  for (int i=0; i<numPtn; ++i) sendcounts[i]=0;
  
  int counter=0;
  for (entIter = entities.begin(); entIter!=entities.end();++entIter)
  {
    ent = (*entIter);
    
    if (ent->getOwner()!=mypid)
      continue;
      
    ent->attachInt(startRangeTag, initialRangeValue++);
    ent->attachInt(endRangeTag,numInt[counter]);
//    cout<<"("<<mypid<<") attach ("<<initialRangeValue-1<<","
//        <<numInt[counter]<<") to "<<ent->getUid()<<endl; 
    if (!ent->getPClassification())  // if non-CB entity
      continue;
    
    // iterate over on AOMD_SharedInfo
    for (mEntity::RCIter rciter=ent->rcBegin();rciter!=ent->rcEnd();++rciter)
    {
      // send phase begins to find the entity in the counterpart
      // and assign the same id		
      void* buf = AP_alloc(rciter->first, 4453, sizeof(int2_mEnt_struct));
      int2_mEnt_struct* castbuf = (int2_mEnt_struct*)buf;
      castbuf->entity = rciter->second;
      castbuf->i = initialRangeValue-1;
      castbuf->j = numInt[counter];
      AP_send(buf);
      sendcounts[rciter->first]++;
    } // for RC
  }  // for entities

  // receive phase begins
  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts);

  message=0;
  while(!AP_recv_count(&count) || message<count)
  {
    void* msg;
    int from, tag, size, rc;
    rc = AP_recv(MPI_ANY_SOURCE, 4453, AP_BLOCKING|AP_DROPOUT, &msg, &size, &from, &tag);
    if (rc)
    {
      message++;
      int2_mEnt_struct* castbuf = (int2_mEnt_struct*) msg;
      castbuf->entity->attachInt(startRangeTag,castbuf->i);
      castbuf->entity->attachInt(endRangeTag,castbuf->j);
//      cout<<"("<<mypid<<") attach ("<<castbuf->i<<","<<castbuf->j<<") to "
//          <<castbuf->entity->getUid()<<endl;
      AP_free(msg);	
    }  // end of if (rc)
  }  // end of while(!AP...)
    
  AP_check_sends(AP_WAITALL);
  delete[] sendcounts; 
}


} // end of namespace
#endif
