/**************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*****************************************************************************/

/*<i> ****************************************************************************
 *
 *  AOMD/pmodel/pmMeshMigration.cc
 *  Created by Seegyoung Seol, on Thur Dec 04 2003, 10:26:37 EDT
 *
 *  File Content: main mesh migration functions 
 *
 *************************************************************************** </i>*/
 
#ifdef PARALLEL

#include <stdio.h>
#include <iostream>
#include <assert.h>
#include <vector>
#include <set>
#include <list>
#include <map>
#include <iterator>

#include "pmModel.h"
#include "pmMigrateUtil.h"
#include "pmModelUtil.h"
#include "pmMigrationCallbacks.h"
#include "mMesh.h"
#include "mEntity.h"
#include "mVertex.h"
#include "mEdge.h"
#include "mRegion.h"
#include "ParUtil.h"
#include "pmGraphs.h"
#include "mAOMD.h"
#include "autopack.h"
#include "AOMD_cint.h"

using std::vector;
using std::set;
using std::cout;
using std::pair;
using std::list;
using std::endl;
using std::map;
	       
namespace AOMD {

void  printPOtoMove(map<mEntity*, int>& POtoMove)
{
  map<mEntity*, int>::const_iterator mapit;
  int mypid=ParUtil::Instance()->rank();
  for (mapit=POtoMove.begin(); mapit!=POtoMove.end();++mapit)
    cout<<"("<<mypid<<") move "<<mapit->first->getUid()<<" to P"<<mapit->second<<endl;
}

// *****************************************
void pmLoadBalance(mMesh* mesh, pmMigrationCallbacks &cb)
// *****************************************
{
  if (ParUtil::Instance()->size()==1)  return;
  if (M_globalMinDim(mesh)==0)
    ParUtil::Instance()->Msg(ParUtil::INFO,"\n*** LOAD BALANCING MAY NOT WORK DUE TO EMPTY MESH ***\n\n");     
  int from = M_globalMaxDim(mesh);
  int to = from-1;
#ifdef _DEBUG
  double t1, t2;

// STEP 1: build a graph for parmetis
  t1=ParUtil::Instance()->wTime();
#endif
  AOMD_distributed_graph2 g(mesh,from,to,&cb,0);
#ifdef _DEBUG
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) build a graph\n",t2-t1);
  
// STEP 2: get partitioning info from parmetis
  t1=ParUtil::Instance()->wTime();
#endif
  int *partitionVector = new int[g.theGraph->nn];
  cb.partition(g,partitionVector);
#ifdef _DEBUG
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) get partition vector\n",t2-t1);
#endif  
// STEP 3: get partition objects to move
  int initial_id = g.vtxdist[ParUtil::Instance()->rank()];
  map<mEntity*,int> POtoMove;
#ifdef _DEBUG
  t1=ParUtil::Instance()->wTime();
#endif
  getPOsToMoveFromPartitionVector(mesh, from,partitionVector,initial_id, POtoMove); 
#ifdef _DEBUG
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) get entities to move from partition vector\n",t2-t1);
#endif
// STEP 4: migrate entities
  migrateMeshEntities(mesh, POtoMove, cb);
  
// update maximumValue of mIdGenerator
  int localMaxId =mesh->getIdGenerator().getMaxValue();
//  cout<<"("<<P_pid()<<") max vid before update="<<localMaxId<<endl;

  int globalMaxId = localMaxId;
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  MPI_Allreduce(&localMaxId,&globalMaxId,1,MPI_INT,MPI_MAX,MPI_COMM_WORLD);
  mesh->pmSetNewVertexId(globalMaxId-P_size()+P_pid()+1);
//  cout<<"("<<P_pid()<<") max vid after update="
//      <<mesh->getIdGenerator().getMaxValue()<<endl;
// update id generator
}

// *****************************************
int pmMerge(mMesh* mesh, pmMigrationCallbacks &cb)
// *****************************************
{
  if (ParUtil::Instance()->size()==1)  return 0;

  int mDim = M_globalMaxDim(mesh);
#ifdef _DEBUG
  double t1, t2;
#endif  
// STEP 1: get partition objects to move
  map<mEntity*,int> POtoMove;
#ifdef _DEBUG
  t1=ParUtil::Instance()->wTime();
#endif

// determine the processor to merge
  int numPE = ParUtil::Instance()->size();
  int myPid = ParUtil::Instance()->rank();
  int* numR = new int[numPE];
  
  int* senddata;
  int* recvdata;

  // send phase begins
  int* sendcounts=new int[numPE];
  for (int i=0;i<numPE;++i) sendcounts[i]=0;
 
  for (int pid=0; pid<numPE;++pid)
  {
    if (pid==P_pid()) continue;
    senddata = (int*)AP_alloc(pid,5590,sizeof(int)*1);
    senddata[0]=mesh->size(mDim);
    AP_send(senddata);
    sendcounts[pid]++;      
  }
  
  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts);

  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  int message=0;
  int count;
  while(!AP_recv_count(&count)||message<count)
  {
    int from,tag,size,rc;
  // receive phase begins
    rc=AP_recv(MPI_ANY_SOURCE,5590,AP_BLOCKING|AP_DROPOUT,
               (void**)&recvdata,&size,&from,&tag);
    if (rc)
    {
      message++;
      numR[from] = recvdata[0];
      AP_free(recvdata);
    }  // if(rc)
  } // while
  AP_check_sends(AP_WAITALL);
  delete [] sendcounts;
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  numR[myPid] = mesh->size(mDim);
  int pidToMerge = myPid;
  int numRMax = mesh->size(mDim);
  
  for (int k=0; k<numPE; ++k)
    if (numR[k] > numRMax)
    {
      numRMax = numR[k];
      pidToMerge = k;
    }
    
  delete [] numR;

  pidToMerge = P_getMinInt(pidToMerge);
  ParUtil::Instance()->Msg(ParUtil::INFO,"\tPID TO MERGE = %d\n",pidToMerge);

  if (ParUtil::Instance()->rank() != pidToMerge)
    for (mMesh::iterall it=mesh->beginall(mDim); it!=mesh->endall(mDim); ++it)
    {
  // move all entities to a master processor
      POtoMove.insert(entityPidMap::value_type(*it,pidToMerge)); 
    }

#ifdef _DEBUG  
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) get entities to move\n",t2-t1);
#endif
// STEP 2: migrate entities
  migrateMeshEntities(mesh, POtoMove, cb);
  return pidToMerge; 
}

// *****************************************
int pmMeshMigration(mMesh* mesh,
                    int dimToMove,list<mEntity*>& entities,
                    pmMigrationCallbacks &cb,
                    std::vector<mEntity*>* rmE,
                    std::vector<mEntity*>* newE)
// *****************************************
{
  if (ParUtil::Instance()->size()==1)  return 0;

// STEP 1: unify origin entities to move
  unifyEntitiesToMove(mesh, entities);

// STEP 2: get partition objects to move
  map<mEntity*,int> POtoMove;
  getPOsToMove(mesh, entities, dimToMove, POtoMove); 

// STEP 3: migrate entities
  return migrateMeshEntities(mesh, POtoMove, cb, rmE, newE);
}

int pmMeshMigration(mMesh* mesh, pmMigrationCallbacks &cb,
 		    std::list<mEntity*>& vtsOnCB, 
		    std::list<std::pair<mEntity*,mEntity*> > &vtfcPairs,
                    std::vector<mEntity*>* rmE,
                    std::vector<mEntity*>* newE)
{
  if (ParUtil::Instance()->size()==1)  return 0;

// STEP 1: unify CB vertices to move
  unifyEntitiesToMove(mesh, vtsOnCB);

// STEP 2: get partition objects to move
  map<mEntity*,int> POtoMove;
// old method written by Li
//  getEntitiesToMove(mesh,vtsOnCB, vtfcPairs, POtoMove); 

// new method written by Seol
// this much improve mesh quality and doesn't cause crash
  getPOsToMoveForSnap(mesh,vtsOnCB, vtfcPairs, POtoMove); 

// STEP 3: migrate entities
  return migrateMeshEntities(mesh, POtoMove, cb, rmE, newE); 
}

// it is called by LB and doesn't need any returned mesh entities to be created
// and removed
// *****************************************
int migrateMeshEntities(mMesh* mesh, 
                        map<mEntity*,int>& POtoMove,
		        pmMigrationCallbacks& cb)
// *****************************************			
{
  vector<mEntity*> rmE[4];
  vector<mEntity*> newE[4];
  
  return migrateMeshEntities(mesh, POtoMove,cb,rmE,newE);
}

// *****************************************
int migrateMeshEntities(mMesh*mesh, 
                        map<mEntity*,int>& POtoMove,
		        pmMigrationCallbacks& cb,
                        std::vector<mEntity*>* rmE,
                        std::vector<mEntity*>* newE)
// *****************************************			
{
  int localMove=POtoMove.size();
  int totalMove;
  MPI_Allreduce(&localMove,&totalMove,1,MPI_INT,MPI_SUM,MPI_COMM_WORLD);
  if (totalMove==0)
  {
#ifdef _DEBUG
    ParUtil::Instance()->Msg(ParUtil::INFO,"\n* NO entity migration needed\n");
#endif
    return 0;
  }
      
  int dim = M_globalMaxDim(mesh);
  int mypid = ParUtil::Instance()->rank();
#ifdef _DEBUG
  double t1, t2;
#endif
  set<mEntity*> entitiesToRemove[4];
  set<mEntity*> entitiesToHandle[4];
  set<mEntity*> entitiesOnCB;

// ********************************************
// STEP 1: reset BPs 
// ********************************************    
  // unify entitiesToHandle and clear their BPs and PCs
#ifdef _DEBUG
  t1 = ParUtil::Instance()->wTime();
#endif
#ifdef DEBUG  
  double ts = ParUtil::Instance()->wTime();
#endif
  getEntitiesToHandle(POtoMove, entitiesToHandle);
#ifdef _DEBUG
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) reset bounding partition ids \n",t2-t1);

// ********************************************
// STEP 2: set BPs 
// ********************************************    
  t1 = ParUtil::Instance()->wTime();
#endif
  setBPs(dim, POtoMove, entitiesToHandle);
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  exchangeBPs(entitiesToHandle);
#ifdef _DEBUG
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) set bounding partition ids \n",t2-t1);

// ********************************************
// STEP 3: update PClassification and collect entities to remove
// ********************************************    
  t1 = ParUtil::Instance()->wTime();
#endif
  updatePC_and_collectEntitiesToRemove(entitiesToHandle, entitiesToRemove);
#ifdef _DEBUG
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) update PClassification\n",t2-t1);

// ********************************************
// STEP 4: Migrate entities
// ******************************************** 
  t1 = ParUtil::Instance()->wTime();
#endif
  for (int i=0; i<=dim;++i)
    exchangeEntities(mesh, dim, cb, i, entitiesToHandle[i], newE);
#ifdef _DEBUG
  t2 = ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) exchange entities\n",t2-t1);
  
// ********************************************
// STEP 5: collect entities removed to return
// ******************************************** 
  t1 = ParUtil::Instance()->wTime();
#endif
  for (int i=0; i<=dim;++i)
    std::copy(entitiesToRemove[i].begin(), entitiesToRemove[i].end(),
              std::back_inserter(rmE[i]));
#ifdef _DEBUG
  t2 = ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) gather removed entities to return to the user\n", t2-t1);

// ********************************************
// STEP 4: delete unused entities
// ******************************************** 
  t1 = ParUtil::Instance()->wTime();
#endif
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  removeUnusedEntities(mesh, dim, entitiesToRemove);
#ifdef _DEBUG
  t2 = ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) remove unused entities\n",t2-t1);
  
// ********************************************
// STEP 5: update partition model in terms of ownership
// ******************************************** 
  t1 = ParUtil::Instance()->wTime();
#endif
  pmModel::Instance()->updateOwnership();
#ifdef _DEBUG
  t2 = ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) update partition model\n",t2-t1);
#endif
#ifdef DEBUG  
  if (mypid==0)
    cout<<"      # Moved = " <<totalMove<<" (t = "<<ParUtil::Instance()->wTime()-ts<<" sec)\n";
#endif
  return 1;
}
				    
} // end of namespace

#endif
