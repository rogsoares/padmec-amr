/* 
   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of Trellis written and maintained by the 
   Scientific Computation Research Center (SCOREC) at Rensselaer Polytechnic
   Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA
*/
// mVector.cpp: implementation of the mVector class.
//
//////////////////////////////////////////////////////////////////////
#include "mVector.h"
#include "mTensor2.h"
#include "mPoint.h"

#include <math.h>

namespace Trellis_Util {

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

        mVector& mVector::operator *= ( const mTensor2 &other )
        {
        //      RIGHT multiply of a matrix to a vector: mTensor2 * mVector
                mVector m(*this);
                pos[0] = pos[1] = pos[2] = 0.0;
                for(int i=0;i<3;i++) {
                        for(int j=0;j<3;j++) {
                                pos[i] += other(i,j) * m.pos[j];
                        }
                }
                return *this;
        }

        mVector mVector::operator * ( const mTensor2& M ) const
        {
        //      added by T. Bui 2/03
        //      LEFT multiply of a vector to a matrix: mVector * mTensor2
                return !M * (*this);
        }

} // end of namespace
