/**************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*****************************************************************************/

/*<i> ****************************************************************************
 *
 *  AOMD/pmodel/pmExchangeMEntities.cc
 *  Created by Seegyoung Seol, on Thur Dec 04 2003, 10:26:37 EDT
 *
 *  File Content: mesh entity exchange functions
 *
 *************************************************************************** </i>*/
#ifdef PARALLEL

#include <stdio.h>
#include <iostream>
#include <assert.h>

#include "pmMigrateUtil.h"
#include "pmUtility.h"
#include "pmModel.h"
#include "mAOMD.h"
#include "mMesh.h"
#include "mEntity.h"
#include "mException.h"
#include "mVertex.h"
#include "ParUtil.h"
#include "autopack.h"
#include "AOMDInternals.h"
#include "pmMigrationCallbacks.h"

#ifndef SIM
#include "modeler.h"
#else
#include "SimModel.h"
#endif

#include <list>
#include <vector>
#include <set>

using std::list;
using std::vector;
using std::set;
using std::cout;
using std::endl;

namespace AOMD {

// **********************************************
//    forward function declaration
// **********************************************
void exchangeEntitiesToBroadcast(vector<rc_struct_2>&);

void* packMEntity(mEntity*, int, pmMigrationCallbacks &cb);
void* packMNonVertex(mEntity*, int, pmMigrationCallbacks &cb);

void unpackMEntity(mMesh*, int, void *vbuf, int iproc, int itag,
                  pmMigrationCallbacks &cb,
                  std::vector<mEntity*>* newE,
		  vector<rc_struct_2>& entitiesToBounce);
		  		       
// **********************************************
void exchangeEntities(mMesh* mesh, int meshDim, 
                     pmMigrationCallbacks &cb,
		     int entDim, set<mEntity*>& entitiesToSend, 
		     vector<mEntity*>* newE)		     
// **********************************************
{
  mEntity* ent;
  set<int>::iterator piter;
  int pid;
  int mypid=ParUtil::Instance()->rank();
  
  set<mEntity*>::const_iterator eit;
  
    int *sendcounts = new int[ParUtil::Instance()->size()];
    for(int i=0;i<ParUtil::Instance()->size();i++) sendcounts[i]=0;

   ParUtil::Instance()->Barrier(__LINE__,__FILE__);

    for(eit=entitiesToSend.begin(); eit!=entitiesToSend.end();++eit)
    {
  
      ent = *eit;
      // decide processor to send
      if (mypid!=ent->getMinPidExist())
        continue;
      set<int> temp, RCs;
      ent->getPidsExist(RCs);
      set_subtract(ent->tempBPs,RCs,temp);	  
      for (piter=temp.begin(); piter!=temp.end();++piter)
      {	      
        pid = *piter;
        void *buf = packMEntity(ent,pid,cb);
        AP_send(buf);
        sendcounts[pid] ++;
      }
    }

    AP_check_sends(AP_NOFLAGS);
    AP_reduce_nsends(sendcounts);
    int message=0;
    int count;
    vector<rc_struct_2> entitiesToBounce;
    while (!AP_recv_count(&count) || message<count) 
    {  
      void *msg;
      int from, tag, size, rc;
      rc=AP_recv(MPI_ANY_SOURCE, MPI_ANY_TAG, AP_BLOCKING|AP_DROPOUT,
               &msg, &size, &from, &tag);
      if (rc && (tag == TAGVERTEX || tag == TAGNONVERTEX)) 
      {
        message++;
        unpackMEntity(mesh,meshDim,msg,from,tag,cb,newE,entitiesToBounce);
        AP_free(msg);
      }
    }
    AP_check_sends(AP_WAITALL); 
    delete[] sendcounts;   
   ParUtil::Instance()->Barrier(__LINE__,__FILE__);
    if (meshDim > entDim)
      exchangeEntitiesToBounce(entitiesToBounce);
}

// **********************************************
void exchangeEntitiesToBounce(vector<rc_struct_2>& entitiesToBounce)
// **********************************************
{
//  int mypid=ParUtil::Instance()->rank();
  int numPtn = ParUtil::Instance()->size();
  int* sendcounts=new int[numPtn];
  for (int i=0;i<numPtn;++i) sendcounts[i]=0;
  
  vector<rc_struct_2>::const_iterator rcvIter;
  for (rcvIter=entitiesToBounce.begin(); rcvIter!=entitiesToBounce.end();++rcvIter)
  {
    void* buf = AP_alloc((*rcvIter).pid, 4459, sizeof(mEnt2_struct));
    mEnt2_struct* castbuf = (mEnt2_struct*)buf;
    castbuf->ent1 = (*rcvIter).ent1;  // entity on this processor
    castbuf->ent2 = (*rcvIter).ent2;  // entity on remote processor
    AP_send(buf);
    sendcounts[(*rcvIter).pid]++;
  }

  // recieve phase
  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts);
  int message=0;
  int count;
  vector<rc_struct_2> entitiesToBroadcast;
  while(!AP_recv_count(&count) || message<count)
  {
    void* msg;
    int from, tag, size, rc;
    rc = AP_recv(MPI_ANY_SOURCE, 4459, AP_BLOCKING|AP_DROPOUT, &msg, &size, &from, &tag);
    if (rc)
    {
      message++;
      mEnt2_struct* castbuf = (mEnt2_struct*) msg;
      castbuf->ent2->addRemoteCopy(from, castbuf->ent1);
      
      entitiesToBroadcast.push_back(rc_struct_2(castbuf->ent2,from, castbuf->ent1));
   
      AP_free(msg);	
    }  // end of if (rc)
  }  // end of while(!AP...)
    
  AP_check_sends(AP_WAITALL);
  delete[] sendcounts;   

  exchangeEntitiesToBroadcast(entitiesToBroadcast);
}

// **********************************************
void exchangeEntitiesToBroadcast(vector<rc_struct_2>& entitiesToBroadcast)
// **********************************************
{
  mEntity* ent;
  int pid;
  
  int numPtn = ParUtil::Instance()->size();
  int* sendcounts=new int[numPtn];
  for (int i=0;i<numPtn;++i) sendcounts[i]=0;
  
  vector<rc_struct_2>::const_iterator rcvIter;
  for (rcvIter=entitiesToBroadcast.begin(); rcvIter!=entitiesToBroadcast.end();++rcvIter)
  {
    ent = (*rcvIter).ent1;
    for (mEntity::RCIter rciter=ent->rcBegin();rciter!=ent->rcEnd();++rciter)
    {
      pid = (*rciter).first;
      if (pid==(*rcvIter).pid)
        continue;
      void* buf = AP_alloc(pid, 4460, sizeof(int_mEnt2_struct));
      int_mEnt2_struct* castbuf = (int_mEnt2_struct*)buf;
      castbuf->ent1 = (*rciter).second;
      castbuf->i=(*rcvIter).pid;
      castbuf->ent2 = (*rcvIter).ent2;
      AP_send(buf);
      sendcounts[pid]++;
    }
  }

  // recieve phase
  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts);
  int message=0;
  int count;

  while(!AP_recv_count(&count) || message<count)
  {
    void* msg;
    int from, tag, size, rc;
    rc = AP_recv(MPI_ANY_SOURCE, 4460, AP_BLOCKING|AP_DROPOUT, &msg, &size, &from, &tag);
    if (rc)
    {
      message++;
      int_mEnt2_struct* castbuf = (int_mEnt2_struct*) msg;
      castbuf->ent1->addRemoteCopy(castbuf->i, castbuf->ent2);
      AP_free(msg);	
    }  // end of if (rc)
  }  // end of while(!AP...)
    
  AP_check_sends(AP_WAITALL);
  delete[] sendcounts;   
}

// **********************************************
void * packMEntity(mEntity *ent, int pid, 
		  pmMigrationCallbacks &cb)
// **********************************************
{
  if (ent->getLevel()==0)
    return packMVertex(ent, pid, cb);
  else
    return packMNonVertex(ent, pid, cb);
}
    
// **********************************************
void* packMVertex(mEntity *ent, int pid, pmMigrationCallbacks &cb)
// **********************************************
{    
  char *buf;
  char *buf_user;
  int user_size;
  int entity_size;

  /* User may have some data to send to the other process 
     These data are of size user_size */
  buf_user = (char*)cb.getUserData(ent,pid,user_size);
  if(!buf_user)user_size = 0;

  int numBP = ent->getNumBPs();
  if (numBP<2) numBP=0;
  
  int numRC = ent->getNumRemoteCopies();
  
  int numParam=0;
  if (ent->getData(AOMD_Util::Instance()->getParametric()))
  {
    int gType = GEN_type(ent->getClassification());
    if (gType==1) // vertex classified on model edge
      numParam=1;
    else if (gType==2) // vertex classified on model face
      numParam=2;
  }
  
  entity_size = sizeof(packedVertex) + numRC*sizeof(rc_struct_1)
                + numBP*sizeof(int) + numParam*sizeof(double);

  buf=(char*)AP_alloc(pid, TAGVERTEX, entity_size + user_size);
      
// fixed length data
  packedVertex castbuf; 
  castbuf.sender = ent;
  castbuf.iD = ent->getId();
  castbuf.gTag = GEN_tag(ent->getClassification());
  castbuf.gType = GEN_type(ent->getClassification());
  Trellis_Util::mPoint p(((mVertex*)ent)->point());
  for(int i=0;i<3;i++) castbuf.coord[i] = p(i);
  castbuf.numRC = numRC;
  castbuf.numBP = numBP;
  castbuf.numParam = numParam;
  memcpy(buf,&castbuf,sizeof(packedVertex)); 

  // variable length data - RC and BP
  int i=0;
  if (numRC>0)
  {
    int_mEnt_struct* RCs = (int_mEnt_struct*)malloc(numRC*sizeof(int_mEnt_struct));
    for (mEntity::RCIter rciter=ent->rcBegin();rciter!=ent->rcEnd();++rciter)
    {
      RCs[i].i=rciter->first;
      RCs[i].entity=rciter->second;
      i++;
    }
    memcpy(&buf[sizeof(packedVertex)],RCs,numRC*sizeof(int_mEnt_struct));
    free (RCs);
  }

  if (numBP>1)
  {
    int* BPs = (int*)malloc(numBP*sizeof(int));
    i=0;
    for (mEntity::BPIter bpiter=ent->bpBegin();bpiter!=ent->bpEnd();++bpiter)
      BPs[i++]=*bpiter;
    
    memcpy(&buf[sizeof(packedVertex)+numRC*sizeof(rc_struct_1)],BPs,numBP*sizeof(int));
    free (BPs);
  }
 
  if (numParam>0)
  {
    double* Params = (double*)malloc(numParam*sizeof(double));
    Trellis_Util::mVector vec = ent->getAttachedVector(AOMD_Util::Instance()->getParametric());
    for (int k=0; k<numParam;++k) Params[k] = vec(k);
    memcpy(&buf[sizeof(packedVertex)+numRC*sizeof(rc_struct_1)+numBP*sizeof(int)],
           Params,numParam*sizeof(double));
    free (Params);
  }
  
  if(user_size)
  {
    memcpy (&buf[entity_size],buf_user,user_size);
    cb.deleteUserData(buf_user);
  }
  
  return buf;
  
}

// **********************************************
void * packMNonVertex(mEntity *ent, int pid, 
		  pmMigrationCallbacks &cb)
// **********************************************
{    
// int mypid=ParUtil::Instance()->rank();
  char *buf;
  char *buf_user;
  int user_size;
  int entity_size;

  /* User may have some data to send to the other process 
     These data are of size user_size */
  buf_user = (char*)cb.getUserData(ent, pid,user_size);
  if(!buf_user)user_size = 0;

  int numBP = ent->getNumBPs();
  if (numBP<2) numBP=0;
  int numRC = ent->getNumRemoteCopies();
  int entDim = ent->getLevel();
  int numDE=0;
  switch(entDim)
  {
    case 1: numDE=2; break;
    case 2: numDE=3; break;
    case 3: numDE=4; break;
    default: break;
  }
  entity_size = sizeof(packedNonVertex) + numDE*sizeof(mEntity*) 
                + numRC*sizeof(rc_struct_1) + numBP*sizeof(int);
 
  int tmp=0;
  
  buf=(char*)AP_alloc(pid, TAGNONVERTEX, entity_size + user_size);
 
  // fixed length data
  packedNonVertex castbuf;
  castbuf.sender = ent;
  castbuf.type = ent->getType();
  castbuf.gTag = GEN_tag(ent->getClassification());
  castbuf.gType = GEN_type(ent->getClassification());
  castbuf.numRC = numRC;
  castbuf.numBP = numBP;
  memcpy(buf,&castbuf,sizeof(packedNonVertex));
  tmp += sizeof(packedNonVertex);
  
  mEnt_struct* DEs = (mEnt_struct*) malloc(numDE*sizeof(mEnt_struct));
  for (int i=0; i<numDE;++i)
     DEs[i].entity = ent->get(0,i)->getRemoteCopy(pid);
  memcpy(&buf[tmp],DEs,numDE*sizeof(mEnt_struct));
  free(DEs);
  tmp += numDE*sizeof(mEnt_struct);
  
  // variable length data - RC and BP
  int i=0;
  if (numRC>0)
  {
    int_mEnt_struct* RCs = (int_mEnt_struct*)malloc(numRC*sizeof(int_mEnt_struct));
    for (mEntity::RCIter rciter=ent->rcBegin();rciter!=ent->rcEnd();++rciter)
    {  
      RCs[i].i=rciter->first;
      RCs[i].entity=rciter->second; 
      i++;
    }
    memcpy(&buf[tmp],RCs,numRC*sizeof(int_mEnt_struct));
    free (RCs);
    tmp += numRC*sizeof(int_mEnt_struct);
  }
  
  if (numBP>1)
  {
    int* BPs = (int*)malloc(numBP*sizeof(int));
    i=0;
    for (mEntity::BPIter bpiter=ent->bpBegin();bpiter!=ent->bpEnd();++bpiter)
    {
      BPs[i++]=*bpiter;
    }
    memcpy(&buf[tmp],BPs,numBP*sizeof(int));
    free (BPs);
  }

  if(user_size)
    {
      memcpy (&buf[entity_size],buf_user,user_size);
      cb.deleteUserData(buf_user);
    }
  
  return buf;
  
}

// **********************************************
void unpackMEntity(mMesh* mesh, int meshDim, void *vbuf, int pid, int itag,
                  pmMigrationCallbacks &cb,
 		  std::vector<mEntity*>* newE,
		   vector<rc_struct_2>& entitiesToBounce)
// **********************************************
{
  char *buf = (char*)vbuf;
  int entity_size;
  int mypid=ParUtil::Instance()->rank();
  
  mEntity *ent;
 
  if(itag == TAGVERTEX)
  {
    packedVertex castbuf;
    memcpy(&castbuf,buf,sizeof(packedVertex));

// STEP 1: create entity

    ent = mesh->createVertex_noUpdateId(castbuf.iD,castbuf.coord[0],castbuf.coord[1],castbuf.coord[2],
                                  mesh->getGEntity(castbuf.gTag,castbuf.gType));
#if defined(DMUM) || defined(FLEXDB)
      if (ent->g_mesh == 0) ent->g_mesh = mesh;
#endif
      newE[0].push_back(ent);
    
// STEP 2: add sender to remote copy
    ent->addRemoteCopy(pid, castbuf.sender);

// STEP 3: copy Remote Copies of sender 
    if (castbuf.numRC>0)
    {  
      int_mEnt_struct* RCs = new int_mEnt_struct[castbuf.numRC];
      memcpy(RCs,&buf[sizeof(packedVertex)],sizeof(int_mEnt_struct)*castbuf.numRC);
      for (int i=0; i<castbuf.numRC;++i)
      {
        ent->addRemoteCopy(RCs[i].i, RCs[i].entity);
      }
      free(RCs); 
    }
// STEP 4: copy bounding partition iDs and set PClassification
    if (castbuf.numBP>1)
    {    
      int* BPs = new int[castbuf.numBP];
      memcpy(BPs,&buf[sizeof(packedVertex)+sizeof(rc_struct_1)*castbuf.numRC],sizeof(int)*castbuf.numBP);
      
      set<int> BPset;
      for (int i=0; i<castbuf.numBP;++i)
        BPset.insert(BPs[i]);
      pmEntity* pe = pmModel::Instance()->getPartitionEntity(BPset);
      ent->setPClassification(pe);
      free(BPs);
    }
    
    if (castbuf.numParam>0)
    {    
      double* Params = new double[castbuf.numParam];
      memcpy(Params,
             &buf[sizeof(packedVertex)+sizeof(rc_struct_1)*castbuf.numRC+castbuf.numBP*sizeof(int)],
	     sizeof(double)*castbuf.numParam);
      if (castbuf.numParam==1)
        ent->attachVector (AOMD_Util::Instance()->getParametric(),Trellis_Util::mVector(Params[0],0,0));     
      else // if (castbuf.numParam==2)
        ent->attachVector (AOMD_Util::Instance()->getParametric(),Trellis_Util::mVector(Params[0],Params[1],0));     
      free(Params);
    }
    
// store entity to bounce
    
    entitiesToBounce.push_back(rc_struct_2(ent,pid,castbuf.sender)); 
  
    entity_size = sizeof(packedVertex)+castbuf.numRC*sizeof(rc_struct_1)
                  +castbuf.numBP*sizeof(int)+castbuf.numParam*sizeof(double);
  }
  else if(itag == TAGNONVERTEX)
  {
    entity_size=sizeof(packedNonVertex);
    packedNonVertex castbuf;
    memcpy(&castbuf,buf,sizeof(packedNonVertex));
    pGEntity g = mesh->getGEntity(castbuf.gTag,castbuf.gType);

// STEP 1: create an entity
    int numDE;
    switch (castbuf.type)
    {
      case mEntity::EDGE: 
      {
        numDE=2;
	mEnt_struct* DEs = new mEnt_struct[numDE]; 
        memcpy(DEs,&buf[sizeof(packedNonVertex)],sizeof(mEnt_struct)*numDE);
	mVertex *v1 = (mVertex*)DEs[0].entity;
	mVertex *v2 = (mVertex*)DEs[1].entity;
	ent = M_createE(mesh, v1, v2, g); 
        newE[1].push_back(ent);
        delete[] DEs;
      } break;

      case mEntity::TRI: 
      {
        numDE=3;
	mEnt_struct* DEs = new mEnt_struct[3]; 
        memcpy(DEs,&buf[sizeof(packedNonVertex)],sizeof(mEnt_struct)*3);
        mVertex* v1 = (mVertex*)DEs[0].entity;
        mVertex* v2 = (mVertex*)DEs[1].entity;
        mVertex* v3 = (mVertex*)DEs[2].entity;

        mEntity* edges[3];
        edges[0]=(mEntity*)E_exist(v1,v2);
        edges[1]=(mEntity*)E_exist(v2,v3);
        edges[2]=(mEntity*)E_exist(v1,v3);
        ent = M_createF(mesh, 3, edges, 0, g);
        newE[2].push_back(ent);

        delete[] DEs;
      } break;

      case mEntity::TET: 
      {
        numDE=4;
	mEnt_struct* DEs = new mEnt_struct[numDE]; 
        memcpy(DEs,&buf[sizeof(packedNonVertex)],sizeof(mEnt_struct)*numDE);
        mVertex* v1 = (mVertex*)DEs[0].entity;
        mVertex* v2 = (mVertex*)DEs[1].entity;
        mVertex* v3 = (mVertex*)DEs[2].entity; 
        mVertex* v4 = (mVertex*)DEs[3].entity;
	mEntity* faces[4];
        faces[0]=(mEntity*)F_exist(0,(mEntity*)v1,(mEntity*)v2,(mEntity*)v3,(mEntity*)0);
        faces[1]=(mEntity*)F_exist(0,(mEntity*)v1,(mEntity*)v2,(mEntity*)v4,(mEntity*)0);
        faces[2]=(mEntity*)F_exist(0,(mEntity*)v2,(mEntity*)v3,(mEntity*)v4,(mEntity*)0);
        faces[3]=(mEntity*)F_exist(0,(mEntity*)v1,(mEntity*)v3,(mEntity*)v4,(mEntity*)0);
        ent=(mEntity*)M_createR(mesh, 4, faces, 0, g);

        newE[3].push_back(ent);
        delete[] DEs;
      } break;
      
      default :
        throw new mException(__LINE__,__FILE__,
                             "unpacking not done for this type of mesh entity");
    }
    entity_size+=sizeof(mEnt_struct)*numDE;

// STEP 2: add sender to remote copy
    if (meshDim>ent->getLevel()) 
      ent->addRemoteCopy(pid, castbuf.sender);

// STEP 3: copy Remote Copies
    if (castbuf.numRC>0)
    {  
      int_mEnt_struct* RCs = new int_mEnt_struct[castbuf.numRC];
      memcpy(RCs,&buf[entity_size],sizeof(int_mEnt_struct)*castbuf.numRC);
      for (int i=0; i<castbuf.numRC;++i)
      {
        ent->addRemoteCopy(RCs[i].i, RCs[i].entity);
      }
      entity_size+= sizeof(int_mEnt_struct)*castbuf.numRC;
      free(RCs);
    }
    
// STEP 4: copy bounding partition iDs and set PClassification
    if (castbuf.numBP>1)
    {
    // copy bounding partition iDs and set PClassification
      int* BPs = new int[castbuf.numBP];
      memcpy(BPs,&buf[entity_size],sizeof(int)*castbuf.numBP);
      
      set<int> BPset;
      for (int i=0; i<castbuf.numBP;++i)
      {
        BPset.insert(BPs[i]);
      }
      pmEntity* pe = pmModel::Instance()->getPartitionEntity(BPset);
      ent->setPClassification(pe);
      entity_size += sizeof(int)*castbuf.numBP;
      free(BPs);
    }

// STEP 5: store entity to bounce
    if (ent->getLevel()<meshDim)
      entitiesToBounce.push_back(rc_struct_2(ent,pid,castbuf.sender));
  }

// STEP 6: process user attached data
  cb.recieveUserData(ent,pid,itag,&buf[entity_size]);
  // now that entities are created, we can send user data
}

}  // end of AOMD

#endif /* PARALLEL */
