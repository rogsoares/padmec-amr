/**************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*****************************************************************************/

/*<i> ****************************************************************************
 *
 *  AOMD/pmodel/pmModelUtil.cc
 *  Created by Seegyoung Seol, on Mon Dec 08 2003, 10:26:37 EDT
 *
 *  File Content: partition model utility functions
 *
 *************************************************************************** </i>*/

#ifdef PARALLEL

#include <stdio.h>
#include <iostream>
#include <assert.h>
#include <string>

#include "pmModel.h"
#include "pmModelUtil.h"
#include "pmMigrateUtil.h"
#include "AOMD_cint.h"
#include "AOMD_OwnerManager.h"
#include "pmUtility.h"
#include "ParUtil.h"
#include "autopack.h"

using std::list;
using std::pair;
using std::vector;
using std::cout;
using std::string;
using std::endl;

namespace AOMD {

// ***********************************************************
void getSortedPids_poor_to_rich(mMesh* mesh,vector<int>& poor_to_rich_pids)
// ***********************************************************
{
  int dim=M_globalMaxDim(mesh);
  int numPE = ParUtil::Instance()->size();
  // one round communication to get #regions for all processors
  int* sendcounts = new int[ParUtil::Instance()->size()];
  vector<pair<int,int> > numRg_pid;
  vector<pair<int,int> >::iterator vecIt;
  int* senddata;
  int* recvdata;
  
  for (int i=0; i<numPE; ++i) sendcounts[i]=0;

  for (int p=0; p<numPE;++p)
  {
    if (p==ParUtil::Instance()->rank())
      numRg_pid.push_back(pair<int,int>(mesh->size(dim), ParUtil::Instance()->rank()));
    else 
    {  
      senddata = (int*)AP_alloc(p, 99, sizeof(int));
      *senddata = mesh->size(dim);
      AP_send(senddata);
      sendcounts[p]++;
     }
  }
  // receive phase begins
  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts);
  int message=0;
  int count;

  while(!AP_recv_count(&count) || message<count)
  {
    int from, tag, size, rc;
    rc=AP_recv(MPI_ANY_SOURCE,99,AP_BLOCKING|AP_DROPOUT,(void**)&recvdata,&size,&from,&tag);
    if (rc)
    {
      message++;
      numRg_pid.push_back(pair<int,int> (*recvdata,from));
//      cout<<"("<<M_Pid()<<") recieved "<<*recvdata<<" from P"<<from<<endl;
      AP_free(recvdata);
    }  // if(rc)
  }  // end of while(!AP...)
  
  //  cout<<"("<<ParUtil::Instance()->rank()<<") entities.size()="<<entities.size()<<endl; 
  AP_check_sends(AP_WAITALL);
  delete[] sendcounts;

  std::sort(numRg_pid.begin(), numRg_pid.end());
  
  for (vecIt=numRg_pid.begin();vecIt!=numRg_pid.end();++vecIt)
  {
    poor_to_rich_pids.push_back((*vecIt).second);
  }
}

// it compares two patition ids based on the mesh size and returns 
//   1 if A > B
//   0 if A = B
//  -1 if A < B
int comparePid(mMesh* mesh, int A, int B)
{
  vector<int> sortedPids;
  getSortedPids_poor_to_rich(mesh,sortedPids);
  int indexA=0, indexB=0;
  
  for (int i=0; i<sortedPids.size();++i)
  {
    if (sortedPids[i]==A) indexA=i;
    if (sortedPids[i]==B) indexB=i;
  }
  if (indexA>indexB) return 1;
  else if (indexA==indexB) return 0;
  else return -1;
}

/*
void transformOwnerManagerToPModel(mMesh* mesh)
{
  
  mMesh::cbiter cbIter= mesh->cbbegin();
  //mMesh::cbiter cbIterend = mesh->cbend();
  mCommonBdry* cb;
  int cbId, owner; 
  
  AOMD_OwnerManager* o= mesh->theOwnerManager;
//  o->print();
  // trasform topology to mCommonBdry
  for (; cbIter!=mesh->cbend(); ++cbIter)
  {
    cb = *cbIter;
    cbId = cb->getId();
  
    AOMD_OwnerManager::iter_top topo = o->begin_top(cbId);
    for (; topo!=o->end_top(cbId); ++topo)
    {
      cb->addBPs((*topo).second);
    }
    cb->print();
  }
  // transform allSharedInfos to remoteCopy
  mEntity* ent;
  AOMD_SharedInfo si;
  int pid;
  AOMD_OwnerManager::iter it=o->begin();
  for (; it!o->end();++it)
  {
    ent = (*it).first;
    ent->addRemoteCopy((*it).second.pid(), (*it).second.getRemotePointer());
  }
}
*/
} // end of namespace
#endif
