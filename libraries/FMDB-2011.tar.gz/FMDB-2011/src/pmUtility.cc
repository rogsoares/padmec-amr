/**************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*****************************************************************************/

/*<i> ****************************************************************************
 *
 *  AOMD/pmodel/pmUtility.cc
 *  Created by Seegyoung Seol, on Mon Dec 08 2003, 10:26:37 EDT
 *
 *  File Content: partition model utility functions
 *
 *************************************************************************** </i>*/

#ifdef PARALLEL

#include <stdio.h>
#include <iostream>
#include <assert.h>
#include <vector>

#include "pmUtility.h"
#include "ParUtil.h"
#include "autopack.h"

using std::vector;

namespace AOMD {

//it merges array
//(Ex)    P0 [1,2,3] , P1 [2,4,5]
//    ==>  P0 [1,2,3,4,5] , P1 [2,4,5,1,3]
void mergeArray(std::vector<int>& vec)
{
  if (ParUtil::Instance()->size()==1)
    return;

  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  int* senddata;
  int* recvdata;

  // send phase begins
  int numPE = ParUtil::Instance()->size();
  int* sendcounts=new int[numPE];
  for (int i=0;i<numPE;++i) sendcounts[i]=0;

  for (unsigned int i=0;i<vec.size();++i)
  {
    int dataToSend=vec[i];
    for (int pid=0; pid<numPE;++pid)
    {
      if (ParUtil::Instance()->rank() != pid)
      {
        senddata = (int*)AP_alloc(pid,555,sizeof(int));
        *senddata = dataToSend;
        AP_send(senddata);
        sendcounts[pid]++;
      }
    }
  }
  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts);

  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  int message=0;
  int count;
  while(!AP_recv_count(&count)||message<count)
  {
    int from,tag,size,rc;
  // receive phase begins
    rc=AP_recv(MPI_ANY_SOURCE,555,AP_BLOCKING|AP_DROPOUT,(void**)&recvdata,&size,&from,&tag);
    if (rc)
    {
      message++;
      if(std::find(vec.begin(),vec.end(),*recvdata)==vec.end())
         vec.push_back(*recvdata);
      AP_free(recvdata);
    }  // if(rc)
  } // while
  AP_check_sends(AP_WAITALL);
  delete [] sendcounts;
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
}

} // end of namespace
#endif
