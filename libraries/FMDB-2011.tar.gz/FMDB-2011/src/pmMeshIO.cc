/**************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*****************************************************************************/

/*<i> ****************************************************************************
 *
 *  AOMD/pmodel/pmMeshIO.cc
 *  Created by Seegyoung Seol, on Mon Dec 08 2003, 10:26:37 EDT
 *
 *  File Content: parallel mesh IO functions
 *
 *************************************************************************** </i>*/
#ifdef PARALLEL

#include <iostream>
#include <fstream>
#include <stdio.h>
#include <map>
#include <algorithm>
#include <assert.h>
#include <vector>
#include <set>

#include "AOMD.h"
#include "AOMDInternals.h"
#include "mAOMD.h"
#include "mMesh.h"
#include "mEntity.h"
#include "mVertex.h"
#include "pmEntity.h"
#include "pmModel.h"
#include "pmUtility.h"
#include "mException.h"
#include "ParUtil.h"
#include "pmMigrationCallbacks.h"
#include "pmMigrateUtil.h"
#include "modeler.h"
#include "AOMD_cint.h"
using std::copy;
using std::map;
using std::cout;
using std::endl;
using std::vector;
using std::set;

namespace AOMD {

//********************************************************
void AOMD_Util::load_and_partition(const char *filename, mMesh *mesh,
				    pmMigrationCallbacks &lb)
//********************************************************				    
{
  import_oneLevel(filename, mesh);
  if (ParUtil::Instance()->size()==1) return; 
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);  
  pmLoadBalance(mesh,lb);
}

//********************************************************
void AOMD_Util::loadPartitionedMesh(mMesh* mesh, const char* fName)
//********************************************************
{
  char line[256];
  int i;
  int NbRegions=0,NbFaces,NbEdges,NbVertices,NbPoints;
  int GEntityType,GEntityId,EntityNbConnections;
  int Dummy;
  int VertexId1,VertexId2;
  int Edge1,Edge2,Edge3,Edge4;
  int Face1, Face2, Face3, Face4;
  int nbPts,NbEdgesOnFace,NbFacesOnRegion;
  double x,y,z;
  double u,v;
  int patch;
  int pclassid, ucbid;
  pmEntity* pe;
  mEntity* ent;

  char inmesh[256]; 
  char without_extension[256];
  int mypid=ParUtil::Instance()->rank();
     
  snprintf(without_extension,strlen(fName)-3,"%s",fName);
  sprintf(inmesh,"%s%d.sms",without_extension,mypid); 

  FILE *in = fopen (inmesh,"r");
  if(!in)
  {
    cout<<"AOMD WARNING: unable to open file \""<<inmesh<<"\"\n";
    return;
  }
    

// *********************************
// STEP 1: setup format
// *********************************
  fscanf(in,"%s %d",line,&Dummy);
  assert(Dummy==3);
  typedef GEntity* (*entityBy_FP)(SGModel*,int,int);
  entityBy_FP fp = GM_entityByID;
  mesh->setGEntity_FP(GM_entityByTag);

// *********************************
// STEP 2: check number of partitions
// *********************************
  int pid, total, numPEs, totalCBEntities;
  fscanf(in,"%d %d %d %d",&total, &pid, &numPEs, &totalCBEntities);
  assert(total<=ParUtil::Instance()->size());

// *********************************
// STEP 3: setup partition model
// *********************************
  int peid, pedim, peowner, penumBPs;
  pmModel* pmodel=pmModel::Instance();
  for (int i=0; i<numPEs;++i)
  {
    fscanf(in,"%d %d %d %d",&peid, &pedim, &peowner, &penumBPs);
    set<int> bps;
    int bp;
    for (int j=0; j<penumBPs;++j)
    {  
      fscanf(in,"%d",&bp);
      bps.insert(bp);
    }
    pmEntity* newPE = new pmEntity(peid, bps, pedim);
    pmodel->addPEntity(newPE);
    newPE->setOwner(peowner);
  }

// *********************************
// STEP 4: setup CB entity container
// *********************************
  vector<mEntity*> CBEntities;
  CBEntities.resize(totalCBEntities);  
  
  fscanf(in,"%d %d %d %d %d",&NbRegions,&NbFaces,&NbEdges,
                               &NbVertices,&NbPoints);

//  cout<<"("<<mypid<<") reading "<<NbVertices<<" vt, "
//      <<NbEdges<<" eg, "<<NbFaces<<" fc, "<<NbRegions<<" rg\n";

// *********************************
// STEP 5: read vertices
// *********************************

  std::vector<mVertex*> vertices;
  mVertex* vv;        
  int vid;
  for(i=0;i<NbVertices;i++)
  {
    fscanf(in,"%d",&vid);       
    fscanf(in,"%d",&GEntityId);       
    if (GEntityId)
    {
      fscanf(in,"%d %d %lf %lf %lf",&GEntityType,&EntityNbConnections,
	                                  &x,&y,&z); 
      vv = mesh->createVertex(vid,x,y,z,
	                 mesh->getGEntity(GEntityId-1,GEntityType,fp)); 
      vertices.push_back(vv);
	    
      switch(GEntityType)
      {
        case 0:
            break;
        case 1:
            fscanf(in,"%le",&u);
            vv->attachVector(getParametric(),Trellis_Util::mVector (u,0,0) );
            break;
  	case 2:
	    fscanf(in,"%le %le %d",&u,&v,&patch);		
	    vv->attachVector(getParametric(),Trellis_Util::mVector (u,v,patch) );
   	    break;
	case 3:
	    break;
 	default :
  	    if (!in)
	      throw new mException (__LINE__,__FILE__,"unknown tag in sms loadSmsFile");	      
      }
      fscanf(in,"%d %d", &pclassid, &ucbid);
      if (pclassid!=-1)
      {
        pe = pmodel->getPartitionEntity(pclassid);
//	assert(pe!=0);
	vv->setPClassification(pe);
	CBEntities[ucbid]=(mEntity*)vv;

      }
    }
  } // end of reading vertices
  
 
// *********************************
// STEP 6: read edges
// *********************************
  std::vector<mEntity*> edges;
  mVertex* v1;
  mVertex* v2;
  mEntity* e;
    
  for(i=0;i<NbEdges;i++)
  {
    fscanf(in,"%d",&GEntityId);
    if (GEntityId)
    {
      fscanf(in,"%d %d %d %d %d",&GEntityType, &VertexId1,&VertexId2,
	           &EntityNbConnections,&nbPts); 
      v1 = vertices[VertexId1-1];
      v2 = vertices[VertexId2-1];
      e = M_createE(mesh, v1, v2, mesh->getGEntity(GEntityId-1,GEntityType,fp));
      edges.push_back(e);
	    
      for(int j=0;j<nbPts;j++)
      {
        switch(GEntityType)
        {
   	  case 0: break;
          case 1: fscanf(in,"%le",&u);
		 break;
	  case 2: fscanf(in,"%le %le %d",&u,&v,&patch);
		 break;
 	  case 3: break;
          default : throw new mException (__LINE__,__FILE__,
					  "unknown tag in sms loadSmsFile");	      
        }
      }
      fscanf(in,"%d %d", &pclassid, &ucbid);
      if (pclassid!=-1)
      {
        pe = pmodel->getPartitionEntity(pclassid);
	assert(pe!=0);
	e->setPClassification(pe);
	CBEntities[ucbid]=e;
      }

    }
  }  // end of reading edges

// *********************************
// STEP 7: read faces
// *********************************

  std::vector<mEntity*> faces;
  mEntity* f;
  mEntity* eg[3];
  
  for(i=0;i<NbFaces;i++)
  {
    fscanf(in,"%d",&GEntityId);
    if(GEntityId)
    {
      fscanf(in,"%d %d",&GEntityType, &NbEdgesOnFace);

      if (NbEdgesOnFace != 3)
        throw new mException (__LINE__,__FILE__,
			      "wrong number of edges on a face in loadSmsFile");
      fscanf(in,"%d %d %d %d",&Edge1,&Edge2,&Edge3,&nbPts);
 
      eg[0]=edges[abs(Edge1)-1];
      eg[1]=edges[abs(Edge2)-1];
      eg[2]=edges[abs(Edge3)-1];

      f = M_createF(mesh, 3, eg, 0, mesh->getGEntity(GEntityId-1,GEntityType,fp));
      faces.push_back(f);

      for(int j=0;j<nbPts;j++)
      {
	switch(GEntityType)
	{
	  case 0: break;
	  case 1: fscanf(in,"%le",&u);
		 break;
	  case 2: fscanf(in,"%le %le %d",&u,&v,&patch);
		 break;
	  case 3: break;
	  default: throw new mException (__LINE__,__FILE__,
					  "unknown tag in sms loadSmsFile");	      
	}
      }
      fscanf(in,"%d %d", &pclassid, &ucbid);
      if (pclassid!=-1)
      {
        pe = pmodel->getPartitionEntity(pclassid);
	assert(pe!=0);
	f->setPClassification(pe);
	CBEntities[ucbid]=f;
      }
    }
  } // end of reading faces

// *********************************
// STEP 8: read regions
// *********************************

  mEntity* fc[4];
  for(i=0;i<NbRegions;i++)
  {
    fscanf(in,"%d",&GEntityId);
    if(GEntityId)
    {
      fscanf(in,"%d",&NbFacesOnRegion);
      if(NbFacesOnRegion > 4)
      {
	throw new mException (__LINE__,__FILE__,
	      		"wrong number of edges on a face in loadSmsFile");				       
      }
      //    if(NbFacesOnRegion == 4)
      {
	fscanf(in,"%d %d %d %d %d",&Face1,&Face2,&Face3,&Face4,&Dummy);
	fc[0]=faces[abs(Face1)-1];
	fc[1]=faces[abs(Face2)-1];
	fc[2]=faces[abs(Face3)-1];
	fc[3]=faces[abs(Face4)-1];
                
        M_createR(mesh,4,fc,0,mesh->getGEntity(GEntityId-1,3,fp));
	
      }	    
    }
  } // end of reading regions
  
  fclose (in);
  
// *********************************
// STEP 9: setup common boundary
// *********************************
  int numPtn = ParUtil::Instance()->size();
  int* sendcounts=new int[numPtn];
  for (int i=0;i<numPtn;++i) sendcounts[i]=0;
  
  for (int idx=0; idx<(int)CBEntities.size(); ++idx)
  {
    ent=CBEntities[idx];
    if (!ent) continue;
    pe = ent->getPClassification();
    for (pmEntity::BPIter bpiter=pe->bpBegin(); bpiter!=pe->bpEnd();++bpiter)
    {
      if (*bpiter==mypid) continue;
      void* buf = AP_alloc(*bpiter, 4000, sizeof(int_mEnt_struct));
      int_mEnt_struct* castbuf = (int_mEnt_struct*)buf;
      castbuf->i=idx;
      castbuf->entity = ent;
      AP_send(buf);
      sendcounts[*bpiter]++;      
    }     
  }
    // recieve phase
  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts);
  int message=0;
  int count;

  while(!AP_recv_count(&count) || message<count)
  {
    void* msg;
    int from, tag, size, rc;
    rc = AP_recv(MPI_ANY_SOURCE, 4000, AP_BLOCKING|AP_DROPOUT, &msg, &size, &from, &tag);
    if (rc)
    {
      message++;
      int_mEnt_struct* castbuf = (int_mEnt_struct*) msg;
      CBEntities[castbuf->i]->addRemoteCopy(from, castbuf->entity);
      AP_free(msg);	
    }  // end of if (rc)
  }  // end of while(!AP...)
    
  AP_check_sends(AP_WAITALL);
  delete[] sendcounts;   

// *********************************
// STEP 10: update maximumValue of mIdGenerator
// *********************************
  int localMaxId =mesh->getIdGenerator().getMaxValue();
  int globalMaxId = localMaxId;
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  MPI_Allreduce(&localMaxId,&globalMaxId,1,MPI_INT,MPI_MAX,MPI_COMM_WORLD);
  mesh->pmSetNewVertexId(globalMaxId-numPtn+mypid+1);
}

class ucbidExchanger:public pmDataExchanger
{
public :
  virtual int tag() const;
  virtual void * AP_alloc_and_fill_buffer (mEntity *e, int pid, mEntity* rc, int);
  virtual void receiveData (int pid, void *buf);
};

int ucbidExchanger::tag () const
{
  return 3010;
}

void * ucbidExchanger:: AP_alloc_and_fill_buffer 
         (mEntity *ent, int pid, mEntity* remoteEnt, int d_tag)
{
  void* buf = AP_alloc(pid, d_tag, sizeof(int_mEnt_struct));
  int_mEnt_struct* castbuf = (int_mEnt_struct*)buf;
  castbuf->entity = remoteEnt;
  castbuf->i = ent->getAttachedInt(MD_lookupMeshDataId("uidOnCB"));
  return buf;
}

void ucbidExchanger:: receiveData (int from, void *buf)
{
  int_mEnt_struct* castbuf = (int_mEnt_struct*)buf;
  castbuf->entity->attachInt(MD_lookupMeshDataId("uidOnCB"), castbuf->i);
}


// this function assumes one-level representation
//********************************************************
void AOMD_Util::writePartitionedMesh(mMesh* mesh, const char* fName)
//********************************************************
{
  char outmesh[256];
  char without_extension[256];
  int mypid=ParUtil::Instance()->rank();
  
  snprintf(without_extension,strlen(fName)-3,"%s",fName);
  sprintf(outmesh,"%s%d.sms",without_extension,mypid);
    
  std::ofstream ofs(outmesh);

  unsigned int tagId= MD_lookupMeshDataId("uidOnCB");
  
  int numCBEntOwned=0; //any region is not on CB
  
  mMesh::iterall it;
  mEntity* ent;

// STEP 1: Count # cb entities owned by the processor 
//         and compute initialId to start

  vector<mEntity*> entOnCB;
  for (int dim=0; dim<mesh->getDim();++dim)
  {
    for (it=mesh->beginall(dim);it!=mesh->endall(dim);++it)
    {
      ent = *it;
      if (ent->getPClassification() && ent->getOwner()==mypid)
      {
        entOnCB.push_back(ent);
	numCBEntOwned++;
      }
    }
  }
    
  int totalCBEnt = P_getSumInt(numCBEntOwned);
  vector<int> output;
  P_getGlobal(numCBEntOwned, output);
  int initialId = 0;
  for (int i=0; i<mypid;++i)
    initialId+=output[i];
  
// STEP 2: attach uid to all CB entities

  for (vector<mEntity*>::iterator vit=entOnCB.begin();vit!=entOnCB.end();++vit)
  {
    (*vit)->attachInt(tagId,initialId);
    initialId++;
  }
  
  ucbidExchanger deCallback;
  genericDataExchanger(entOnCB.begin(), entOnCB.end(), deCallback);

// STEP 3: write header - 3 means partitioned mesh
  ofs<<"sms 3\n";  // partitioned mesh format 

// STEP 4: write partition model info    
  ofs<<ParUtil::Instance()->size()<<" "<<mypid<<" "
     <<pmModel::Instance()->getNumPEs()<<" "<<totalCBEnt<<endl;
  pmModel::PEIter peiter=pmModel::Instance()->peBegin();
  pmEntity* pe;
  for(;peiter!=pmModel::Instance()->peEnd();++peiter)
  {
    pe=(*peiter);
    ofs<<pe->getId()<<" "<<pe->getLevel()<<" "<<pe->getOwner()<<" "
       <<pe->getNumBPs()<<" ";
    for (pmEntity::BPIter bpiter=pe->bpBegin();bpiter!=pe->bpEnd();++bpiter)
      ofs<<*bpiter<<" ";
    ofs<<endl;
  }

  std::map<int,int> numberid;	
  EIter eIter;
  FIter fIter;
  VIter vIter;
  RIter rIter;
  double loc[3];
  pVertex vertex;
  pRegion region;
  pEdge edge;
  pFace face;

  int gtype;
  int gid;
  pGEntity gEntity;

  int NbRegions, NbFaces, NbEdges, NbVertices,NbPoints;
  NbRegions=mesh->size(3);
  NbFaces=mesh->size(2);
  NbEdges=mesh->size(1);
  NbVertices=mesh->size(0);
  NbPoints=NbVertices;

  ofs<< NbRegions << " " << NbFaces << " "<< NbEdges <<" " <<NbVertices << " " << NbPoints <<endl;

// STEP 5: write mesh vertices

  if (NbVertices>0)
  {
    vIter = M_vertexIter(mesh);
    int i=1;
	    
    while((vertex=VIter_next(vIter)))
    {  
      numberid.insert(std::make_pair(EN_id(vertex),i++));
      V_coord(vertex,loc);
      gtype=GEN_type(vertex->getClassification());
      gid = GEN_id(vertex->getClassification());  
      // write coordinates and gclassification
      ofs << vertex->getId()<<" "
          << gid+1 << " " << gtype << " "
	  << V_numEdges(vertex) << endl << loc[0] << " " << loc[1] 
	  << " " << loc[2]<<" "; 
      // write parametric
      if (vertex->getData(AOMD_Util::Instance()->getParametric()))
      {
        Trellis_Util::mVector vec = vertex->getAttachedVector(getParametric());
        switch (gtype)
        {
          case 1 :  // model edge
	  {  ofs << vec(0); break; }
          case 2 : // model face
	  {  ofs << vec(0)<<" "<<vec(1)<<" 0"; break;  }
	  default: break;
	}
      }
      else
      {
        switch (gtype)
        {
          case 1 :  // model edge
	  {  ofs <<"0"; break; }
          case 2 : // model face
	  {  ofs <<"0 0 0"; break;  }
	  default: break;
	}
      }
      ofs << endl;
      // write pclassification
      if (vertex->getPClassification())
        ofs<<vertex->getPClassification()->getId()<<" "
	  <<vertex->getAttachedInt(MD_lookupMeshDataId("uidOnCB"))<<endl;
      else
        ofs<<"-1 -1"<<endl;
    } // while vertex
    VIter_delete(vIter);
  }  // end of vertex

// STEP 6: write mesh edges

  if (NbEdges>0)
  {	
    eIter = M_edgeIter(mesh);
    int i=1;
    while((edge = EIter_next(eIter)))
    {
      gtype=GEN_type(edge->getClassification());
      gid = GEN_id(edge->getClassification());  
      ofs << gid+1 << " " << gtype << " " ;
      EN_setID(edge,i++);
      for (int j=0; j<2 ;j++)
      {
	vertex = E_vertex(edge,j);
	int ID=EN_id(vertex);
	std::map<int,int>::const_iterator p=numberid.find(ID);
	ofs << (*p).second << " ";
      } 		
      ofs << E_numFaces(edge) << " " << "0"<<endl; 

      if (edge->getPClassification())
        ofs<<edge->getPClassification()->getId()<<" "
	   <<edge->getAttachedInt(MD_lookupMeshDataId("uidOnCB"))<<endl;
      else
        ofs<<"-1 -1"<<endl;
    }

    EIter_delete(eIter);
  }  // end of edges
  			
  if (NbFaces>0)
  {	  
    int i=1;
    fIter = M_faceIter(mesh);
    while((face = FIter_next(fIter)))
    {
      gtype=GEN_type(face->getClassification());
      gid = GEN_id(face->getClassification()); 
      ofs << gid+1 << " " << gtype << " ";
      EN_setID(face,i++);
      int numEdges=F_numEdges(face);
      ofs << numEdges << " ";
      for (int j=0; j<numEdges ;j++)
      {
	edge = F_edge(face,j);
	int ID=EN_id(edge);
	if (!F_edgeDir(face,j)) ID=-ID;
	ofs << ID << " ";
      } 		
      ofs <<"0"<<endl; 
      if (face->getPClassification())
        ofs<<face->getPClassification()->getId()<<" "
	   <<face->getAttachedInt(MD_lookupMeshDataId("uidOnCB"))<<endl;
      else
        ofs<<"-1 -1"<<endl;
    }  // while face
    FIter_delete(fIter);
  }  // end of faces
  	
  if (NbRegions>0)
  {
    rIter = M_regionIter(mesh);
    while((region = RIter_next(rIter)))
    { 
      gEntity =(pGEntity)R_whatIn(region);
      gid = GEN_id(gEntity);  
      int numFaces=R_numFaces(region);
      ofs << gid+1 << " " << numFaces << " ";		
      for (int j=0; j<numFaces ;j++)
      {		  
	face = R_face(region,j);
	int ID=EN_id(face);
	if (!R_faceDir(region,j)) ID=-ID;
	ofs << ID << " ";
      } 		
      ofs << "0"<<endl;
    }
    RIter_delete(rIter);
  }
  ofs.close();
}

} /* end of namespace */ 

#endif
