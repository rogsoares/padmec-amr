/**************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*****************************************************************************/

#include <assert.h>
#include <stdio.h>
#include <iostream>
#include "mEntity.h"
#include "mException.h"
#include "mVertex.h"
#include "mEdge.h"
#include "mEntityContainer.h"
#include "mAOMD.h"
#include "mCommonBdry.h"
#ifdef PARALLEL
#include "ParUtil.h"
#endif

#include "modeler.h"

#include <stdlib.h>  
#include <math.h> 
#include <algorithm> 
#include <vector> 
#include <string> 

using std::cout;
using std::sort;
using std::set;
using std::list;
using std::string;
using std::vector;

namespace AOMD {

#if defined(DMUM) || defined(FLEXDB)
   mMesh* mEntity::g_mesh=0;
#endif

  // create an empty entity
  mEntity::mEntity()
  : theFastData(0),theClassification((pGEntity)0),
    theCommonBdry((mCommonBdry*)0),iD(0)
  {
#ifdef PARALLEL
    thePClassification = (pmEntity*)0;
#endif
    for(int i=0;i<4;i++)theAdjacencies[i] = (mAdjacencyContainer*)0;
  }
  // destructor
  mEntity::~mEntity()
  {
    for(int i=0;i<4;i++)
      {
	if(theAdjacencies[i])
	  delete theAdjacencies[i];
      }
    if(theFastData)delete theFastData;
  }

  double mEntity::gSize ()
  {
    double lmin;
    //  std::cout << e->size(1) << " edges\n";

    if(getType() == TRI)
      {
	Trellis_Util::mPoint p0 = ((mVertex*)get(0,0))->point();
	Trellis_Util::mPoint p1 = ((mVertex*)get(0,1))->point();
	Trellis_Util::mPoint p2 = ((mVertex*)get(0,2))->point();
	Trellis_Util::mVector v1(p1,p0);
	Trellis_Util::mVector v2(p2,p0);
	Trellis_Util::mVector v3(p2,p1);
	
	Trellis_Util::mVector v1xv2 = v1 % v2;

	double semi_perimeter = 0.5 * (v1.normValue() + v2.normValue() + v3.normValue());
	double area = v1xv2.normValue();

	return area / semi_perimeter;
	
      }

    if(getType() == TET)
      {
	Trellis_Util::mPoint p0 = ((mVertex*)get(0,0))->point();
	Trellis_Util::mPoint p1 = ((mVertex*)get(0,1))->point();
	Trellis_Util::mPoint p2 = ((mVertex*)get(0,2))->point();
	Trellis_Util::mPoint p3 = ((mVertex*)get(0,3))->point();
	Trellis_Util::mVector v1(p1,p0);
	Trellis_Util::mVector v2(p2,p0);
	Trellis_Util::mVector v3(p3,p0);
	Trellis_Util::mVector v4(p1,p2);
	Trellis_Util::mVector v5(p1,p3);
	Trellis_Util::mVector v1v2 = v1 % v2;
	Trellis_Util::mVector v1v3 = v1 % v3;
	Trellis_Util::mVector v2v3 = v2 % v3;
	Trellis_Util::mVector v4v5 = v4 % v5;
	double V = v1v2 * v3;
	double A1 = sqrt (v1v2 * v1v2);
	double A2 = sqrt (v1v3 * v1v3);
	double A3 = sqrt (v2v3 * v2v3);
	double A4 = sqrt (v4v5 * v4v5);
	return fabs(V) / (A1+A2+A3+A4);
      }

    for(int i=0;i<size(1);i++)
      {
	Trellis_Util::mPoint p1 = ((mEdge*)get(1,i))->vertex(0)->point();
	Trellis_Util::mPoint p2 = ((mEdge*)get(1,i))->vertex(1)->point();
	Trellis_Util::mVector v(p2,p1);
	double l = sqrt (v(0)*v(0) + v(1)*v(1) + v(2)*v(2));
	//      std :: cout << "edge " << i << " length " << l << "\n";
	if(!i)lmin = l;
	else lmin = (l<lmin)?l:lmin;
      }
    return lmin;
  }

// end of gEntity functions
//*****************************************

  int mEntity::getNbTemplates(int what) const
  {
    throw new mException (__LINE__,__FILE__,"no template in mEntity base class");
  }

  mEntity* mEntity::getTemplate(int,int,int)const 
  {
    throw new mException (__LINE__,__FILE__,"no template in mEntity base class");
  }

  mEntity * mEntity::find(mEntity*me)const
  {
    mEntity *ret;
    int dim = me->getLevel();
    if(theAdjacencies[dim])
      if(ret = theAdjacencies[dim]->find(me))return ret;
    return (mEntity *)0;
  }

  void mEntity::add(mEntity*me)
  {
    int dim = me->getLevel();
    if(!theAdjacencies[dim]) 
      theAdjacencies[dim] = new mAdjacencyContainer;
    theAdjacencies[dim]->add(me);
  }

  void mEntity::appendUnique(mEntity*me)
  {
    int dim = me->getLevel();
    if(!theAdjacencies[dim]) 
      theAdjacencies[dim] = new mAdjacencyContainer;
    theAdjacencies[dim]->appendUnique(me);
  }

  void mEntity::del(mEntity*me)
  {
    int dim = me->getLevel();
    if(theAdjacencies[dim])theAdjacencies[dim]->del(me);
  }

  void mEntity::classify(pGEntity g)
  {
    theClassification = g;
    if(parent())parent()->classify(g);
  }

  void mEntity::setCommonBdry(mCommonBdry* g)
  {
    theCommonBdry = g;
    if(parent())parent()->setCommonBdry(g);
  }

  pGEntity mEntity::getClassification() const
  {
    return theClassification;
  }

  mCommonBdry* mEntity::getCommonBdry() const
  {
    return theCommonBdry;
  }

  void mEntity::deleteAdjacencies(int what)
  {
    if(theAdjacencies[what])
      {
	delete theAdjacencies[what];
	theAdjacencies[what] = (mAdjacencyContainer*)0;
      }
  }

  mAdjacencyContainer::iter mEntity::begin(int what)
  {
    if(!theAdjacencies[what])throw new mException (__LINE__,__FILE__, "Adjacencies Not Created");
    return theAdjacencies[what]->begin();
  }

  mAdjacencyContainer::iter mEntity::end(int what)
  {
    if(!theAdjacencies[what])throw new mException (__LINE__,__FILE__, "Adjacencies Not Created");
    return theAdjacencies[what]->end();
  }

  // are two mesh entities equal ?
  bool mEntity::equal (mEntity *other) const
  {
    if(this == other)return true;
    if(getId() != other->getId())return false;
    int dim = getLevel();
    if(dim != other->getLevel())return false;
    if(dim == 0)return getId() == other->getId();
  
    if(dim == 1)
      {
	int v11 = get(0,0)->getId();
	int v12 = get(0,1)->getId();
	int v21 = other->get(0,0)->getId();
	int v22 = other->get(0,1)->getId();
	if(v11 == v21 && v12 == v22)return true;
	if(v11 == v22 && v12 == v21)return true;
	return false;
      }
  
    int v1[100],v2[100];
    int s1 = size(0);
    int s2 = other->size(0);
    if(s1 != s2)return false;
    int i;
    for(i=0;i<s1;i++)
      {
	v1[i]=get(0,i)->getId();
	v2[i]=other->get(0,i)->getId();
      }
    sort(v1,v1+s1);
    sort(v2,v2+s2);
    for(i=0 ; i<s1 ;i++)
      {
	if(v1[i] != v2[i])return false;
      }
    return true;
  }

  // compare two entities
  bool mEntity::lessthan (mEntity *other) const
  {
    /* first do some fast checks**/
    int dim = getLevel();
    int other_dim = other->getLevel();
    if(dim != other_dim)return dim < other_dim;
    int id = getId();
    int other_id =  other->getId();
    if(dim == 0)return id < other_id;
    if(id < other_id)return true;
    if(id > other_id)return false;
  
    /*then do the whole comparison on vertices*/
    std::vector<mVertex*> thisVertices;
    std::vector<mVertex*> otherVertices;

    {  for(int i=0;i<getNbTemplates(0);i++)thisVertices.push_back((mVertex*)get(0,i));}
    {  for(int i=0;i<other->getNbTemplates(0);i++)otherVertices.push_back((mVertex*)other->get(0,i));}
    if(thisVertices.size() < otherVertices.size())return true;
    if(thisVertices.size() > otherVertices.size())return false;
    std::sort(thisVertices.begin(),thisVertices.end());
    std::sort(otherVertices.begin(),otherVertices.end());
    for( int i=0;i<thisVertices.size();i++)
      {      
	int id1 = thisVertices[i]->getId();
	int id2 = otherVertices[i]->getId();
	if(id1 < id2)return true;
	if(id1 > id2)return false;
      }  
    return false;
  }


  void mEntity::print() const
  {
  }

  void mEntity::setParent (mEntity* e)
  {
    unsigned int x = AOMD_Util::Instance()->getParent();
    mAttachableEntity *ai = (mAttachableEntity *)getData(x);
    if(!ai)
      {
	ai = new mAttachableEntity;
	attachData(x,ai);
      }
    ai->e = e;
  }

  mEntity* mEntity::parent ()
  {
    unsigned int x = AOMD_Util::Instance()->getParent();
    mAttachableEntity *ai = (mAttachableEntity *)getData(x);
    if(!ai)return 0;
    return ai->e;
  }

  mEntity* mEntity::root () 
  {
    mEntity *p = parent();
    if(!p)return this;
    else return p->root();
  }

  void mEntity::deleteParent ()
  {
    unsigned int x = AOMD_Util::Instance()->getParent();
    mAttachableEntity *ai = (mAttachableEntity *)getData(x);
    if(!ai)return;
    deleteData(x);
  }

  void recur_get_leaves(mEntity * e, list<mEntity*> &leaves, int n)
  {
    for(int i=0;i<e->size(n);i++)
      {
	mEntity *sub = e->get(n,i);
	if(sub->isAdjacencyCreated(n))recur_get_leaves(sub,leaves,n);
	else leaves.push_back(sub);
      }
  }

  void mEntity::getLeaves(list<mEntity*> &leaves)
  {
    int n = getLevel();
    if (isAdjacencyCreated(n))recur_get_leaves(this,leaves,n);
    else leaves.push_back(this);
  }

  void recur_get_all(mEntity * e, list<mEntity*> &leaves, int n)
  {
    for(int i=0;i<e->size(n);i++)
      {
	mEntity *sub = e->get(n,i);
	leaves.push_back(sub);
	if(sub->isAdjacencyCreated(n))recur_get_all(sub,leaves,n);
      }
  }

  void mEntity::getAllSubTree(list<mEntity*> &leaves)
  {
    int n = getLevel();
    leaves.push_back(this);
    if (isAdjacencyCreated(n))recur_get_all(this,leaves,n);
  }


  /* 
     This function gets all sub-entities of all dimensions for the element. 
     I'm trying to make that efficient
  */

  void mEntity:: getAllEntitiesOfAllDimensions(std::set<mEntity*> &the_whole_family)
  {
    int n = getLevel();
    the_whole_family.insert(this);
    list<mEntity *> family;
    getAllSubTree(family);
  
    for(std::list<mEntity*>::iterator it = family.begin() ; it != family.end() ; ++it)
      {
	mEntity *e = *it;
	the_whole_family.insert(e);
	for(int dim = 1; dim<n ;dim++)
	  {
	    if(e->isAdjacencyCreated(dim))
	      {

		for(int j=0; j<e->size(dim);j++)
		  {
		    mEntity *sub = e->get(dim,j);
		    list<mEntity *> subfamily;
		    if(the_whole_family.find(sub) == the_whole_family.end())
		      {
			sub->getAllSubTree(subfamily);
			sub->getAllEntitiesOfAllDimensions (the_whole_family);
			for(std::list<mEntity*>::iterator it2 = subfamily.begin() ; it2 != subfamily.end() ; ++it2)
			  {
			    mEntity *sub_f = *it2;
			  
			    the_whole_family.insert(sub_f);
			    for(int k=0; k<sub_f->size(0);k++)
			      the_whole_family.insert(sub_f->get(0,k));
			  }		    
		      }
		  }
	      }
	  }
      }
  }

  void mEntity:: getAllEntitiesOfAllDimensions(std::set<mEntity*,EntityLessThanKey> &the_whole_family)
  {
    int n = getLevel();
    the_whole_family.insert(this);
    list<mEntity *> family;
    getAllSubTree(family);
  
    for(std::list<mEntity*>::iterator it = family.begin() ; it != family.end() ; ++it)
      {
	mEntity *e = *it;
	the_whole_family.insert(e);
	for(int dim = 1; dim<n ;dim++)
	  {
	    if(e->isAdjacencyCreated(dim))
	      {

		for(int j=0; j<e->size(dim);j++)
		  {
		    mEntity *sub = e->get(dim,j);
		    list<mEntity *> subfamily;
		    if(the_whole_family.find(sub) == the_whole_family.end())
		      {
			sub->getAllSubTree(subfamily);
			sub->getAllEntitiesOfAllDimensions (the_whole_family);
			for(std::list<mEntity*>::iterator it2 = subfamily.begin() ; it2 != subfamily.end() ; ++it2)
			  {
			    mEntity *sub_f = *it2;
			  
			    the_whole_family.insert(sub_f);
			    for(int k=0; k<sub_f->size(0);k++)
			      the_whole_family.insert(sub_f->get(0,k));
			  }		    
		      }
		  }
	      }
	  }
      }
  }


  void mEntity::getHigherOrderUpward (int dim, mAdjacencyContainer &ents) const
  {
    if(isAdjacencyCreated(dim))
      {
	for(int i=0;i<size(dim);i++)ents.appendUnique(get(dim,i));
      }
    else 
      {
	int myDim = getLevel();
	for(int DIM = myDim+1; DIM!=dim ,DIM <= 3; DIM++)
	  {
	    if(isAdjacencyCreated(DIM))
	      {
		for(int i=0;i<size(DIM);i++)get(DIM,i)->getHigherOrderUpward(dim,ents);
		break;
	      }
	  }
      }
  }

  /**
     compute use of an entity
  */

  int mEntity :: getUse ( mEntity *e ) const
  {
    if (getLevel() == 2 && e->getLevel() == 1)
      {
	mEdge *ed = (mEdge*)e;
	mVertex *v1 = ed->vertex(0);
	mVertex *v2 = ed->vertex(1);
	int nbVert = size(0);
	for(int i=0;i<nbVert;i++)
	  {
	    mVertex *vv1 = (mVertex*)get(0,i);
	    mVertex *vv2 = (mVertex*)get(0,(i+1)%nbVert);
	    if(vv1 == v1 && vv2 == v2)return 1;
	    if(vv1 == v2 && vv2 == v1)return 0;
	  }
	throw 1;
      }

    int tetfacedir [] = {1,0,0,1};
    int dim = e->getLevel();
    assert (dim < getLevel());

    mEntity *v1 = e->get (0,0);
    mEntity *v2 = e->get (0,1);

    for(int i=0 ; i< getNbTemplates (dim) ; i++)
      {
	if ( get(dim,i) == e )
	  {
	    mEntity *other = getTemplate(i, dim, 0);
	    for(int j=0; j<other->size(0);j++)
	      {
		if(other->get(0,j) == v1)
		  {
		    mEntity *vtest = other->get(0,(j+1)%other->size(0));
		    if(vtest == v2)
		      {
			if(other != get(dim,i))delete other;
			if(dim == 2)return ( 1 - tetfacedir[i] );
			return 1;
		      }
		    else
		      {
			if(other != get(dim,i))delete other;
			if(dim == 2)return ( tetfacedir[i] );
			return 0;
		      }
		  }
	      }
	    delete other;
	  }
      }
    throw 1;
  }

#ifdef TSTT_
  mEntity::mTopology mEntity::getTopo()
  {
    int mDim;
    mDim=getLevel();
    switch(mDim)
      {
      case 0:
	return POINT;
	break;
      case 1:
	return LINE_SEGMENT;
	break;
      case 2:
	if     (size(0) == 3) return TRIANGLE;
	else if (size(0) == 4) return QUADRILATERAL;
	else if (size(0) >= 5) return POLYGON;
	break;
      case 3:
	if      (size(0) == 4 && size(2) == 4) return TETRAHEDRON;
	else if (size(0) == 8 && size(2) == 6) return HEXAHEDRON;
	else if (size(0) == 6 && size(2) == 5) return PRISM_;
	else if (size(0) == 5 && size(2) == 5) return PYRAMID_;
	else if (size(0) > 8)                  return POLYHEDRON;
	break;
      default:
	return UNDEFINED;
      }
  }
#endif

string mEntity::getUid() const
  {

    char cuid[256];
    //int uid;
    std::vector<int> uids;
    switch(getType())
    {
      case VERTEX : 
	uids.push_back(getId());
	break;
      default: 
        for (int i=0; i<size(0);++i)
          uids.push_back(get(0,i)->getId());
	std::sort(uids.begin(), uids.end());
	break;
    }
    
    switch(getType())
      {
      case VERTEX : 
	sprintf (cuid,"V%d",uids[0]);
	break;
      case EDGE : 
	sprintf (cuid,"E%d_%d",uids[0],uids[1]);
	break;
      case TRI : 
	sprintf (cuid,"F%d_%d_%d",uids[0],uids[1],uids[2]);
	break;  
      case QUAD : 
	sprintf (cuid,"F%d_%d_%d_%d",uids[0],uids[1],uids[2],uids[3]);
	break;
      case TET : 
	sprintf (cuid,"R%d_%d_%d_%d",uids[0],uids[1],uids[2],uids[3]);
	break;
      case HEX : 
	sprintf (cuid,"R%d_%d_%d_%d_%d_%d_%d_%d",uids[0],uids[1],uids[2],uids[3],
  		 				 uids[4],uids[5],uids[6],uids[7]);
	break;
    }

    return string(cuid);
  }

}


