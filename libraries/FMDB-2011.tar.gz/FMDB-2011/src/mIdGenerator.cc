/**************************************************************************** 

   Copyright (C) 2004
   Rensselaer Polytechnic Institute

   This file is part of the Algorithm-Oriented Mesh Database (AOMD) written 
   and maintained by the Scientific Computation Research Center (SCOREC) at 
   Rensselaer Polytechnic Intitute, Troy, NY, USA.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the Rensselaer SCOREC Public License.

   This program is distributed in the hope that it will be useful, 
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   license text for more details.
   
   You should have received a copy of the Rensselaer SCOREC Public License
   along with this program; if not, write to Rensselaer Polytechnic Institure,
   110 8th Street, SCOREC, Troy, NY  12180, USA

*****************************************************************************/
#include <iostream>
#include "mIdGenerator.h"
#ifdef PARALLEL
#include "ParUtil.h"
#endif

namespace AOMD {

mIdGenerator::mIdGenerator()
{
#ifdef PARALLEL
  nbPE = ParUtil::Instance()->size();
  myPE = ParUtil::Instance()->rank()+1;
  maximumValue = myPE - nbPE;
#else
  maximumValue=0;
#endif
}
void mIdGenerator::addId(int Id){ Q.push(Id);}

int mIdGenerator::generateId()
{
#ifdef PARALLEL
  maximumValue += nbPE;
  return maximumValue;
#else
  return ++maximumValue; 
#endif
}

mIdGenerator::~mIdGenerator(){}
int mIdGenerator::getMaxValue() const
{
  return maximumValue;
}

void mIdGenerator::setMaxValue(int v)
{
  maximumValue = (maximumValue >v)?maximumValue:v;
}

#ifdef PARALLEL
void mIdGenerator::pmSetMaxValue(int v)
{ 
  maximumValue=v;
}
#endif

} // end of namespace
